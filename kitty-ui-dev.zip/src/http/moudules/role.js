import axios from '../axios'

/* 
 * 角色管理模块
 */

// 保存
export const save = (data) => {
        return axios({
            url: '/admin/role/save',
            method: 'post',
            data
        })
    }
    // 删除
export const batchDelete = (data) => {
        return axios({
            url: '/admin/role/delete/' + data,
            method: 'get',
        })
    }
    // 分页查询
export const findPage = (data) => {
    return axios({
        // pageRequest: { pageNum: 1, pageSize: 10 },
        url: '/admin/role/' + data.pageNum + "/" + data.pageSize + "?name=" + data.name,
        method: 'get',
        data
    })
}

// 查询全部
export const findAll = () => {
        return axios({
            url: '/admin/role/getAllRole',
            method: 'get'
        })
    }
    // 查询角色菜单集合
export const findRoleMenus = (params) => {
        return axios({
            url: '/admin/permission/toAssign/' + params,
            method: 'get',
        })
    }
    // 保存角色菜单集合
export const saveRoleMenus = (data) => {
    return axios({
        url: '/admin/permission/doAssign',
        method: 'post',
        data
    })
}
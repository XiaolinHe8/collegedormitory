import axios from '../axios'

/* 
 * 机构管理模块
 */
// 分页查询
export const findPage = (data) => {
    return axios({
        // pageRequest: { pageNum: 1, pageSize: 10 },
        url: '/cs/' + data.pageNum + "/" + data.pageSize + "?equipmentLocation=" + data.name,
        method: 'get',
        data
    })
}

export const deleteEquipment = (data) => {
        return axios({
            url: '/cs/equipment/delete/' + data,
            method: 'get',
        })
    }
    // 保存
export const save = (data) => {
        return axios({
            url: '/cs/equipment/update',
            method: 'post',
            data
        })
    }
    // 分配用户
export const equipmentAdduser = (data) => {
    return axios({
        url: '/cs/equipment/insertUser',
        method: 'post',
        data
    })
}

// 查询已经分配用户
export const selectEquipmentUser = (data) => {
    return axios({
        url: '/cs/equipment/selectUser/' + data,
        method: 'get',
    })
}
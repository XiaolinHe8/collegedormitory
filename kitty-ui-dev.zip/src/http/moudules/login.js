import axios from '../axios'

/* 
 * 系统登录模块
 */

// 登录
export const login = data => {
    return axios({
        url: 'login',
        method: 'post',
        data
    })
}

export const verityCode = date => {
    return axios({
        url: '/getCode/' + date,
        method: 'get',
    })
}

// 登出
export const logout = data => {
    return axios({
        url: 'logout',
        method: 'get'
    })
}
import axios from '../axios'
export const selectRecord = (data) => {
    return axios({
        url: '/cs/access/selectRecord?userId=' + data.userId + '&type=' + data.type + '&date=' + data.date,
        method: 'get',
    })
}
export const selectAccessAfter11 = (data) => {
    return axios({
        url: '/cs/access/selectAccessAfter11?date=' + data.date,
        method: 'get',
    })
}
export const selectNoAccess = (data) => {
    return axios({
        url: '/cs/access/selectNoAccess?date=' + data.date,
        method: 'get',
    })
}
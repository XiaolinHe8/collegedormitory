<template>
  <div style="width: 40%; margin: auto">
    <el-form
      :model="dataForm"
      label-width="80px"
      ref="dataForm"
      label-position="right"
    >
      <el-form-item label="ID" prop="userId">
        <el-input
          v-model="dataForm.userId"
          :disabled="true"
          auto-complete="off"
        ></el-input>
      </el-form-item>
      <el-form-item label="用户名" prop="username">
        <el-input v-model="dataForm.username" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input
          v-model="dataForm.password"
          type="password"
          auto-complete="off"
        ></el-input>
      </el-form-item>
      <el-form-item label="性别" prop="sex">
        <el-select
          v-model="dataForm.sex"
          placeholder="请选择"
          style="width: 100%"
          @change="showSex"
        >
          <el-option
            v-for="item in sex"
            :key="item.id"
            :label="item.msg"
            :value="item.id"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="学院" prop="userCollege">
        <el-select
          v-model="dataForm.userCollege"
          placeholder="请选择"
          style="width: 100%"
          @change="showClasses"
        >
          <el-option
            v-for="item in colleges"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="班级" prop="userClass">
        <el-select
          v-model="dataForm.userClass"
          placeholder="请选择"
          style="width: 100%"
          @change="selectClasses"
        >
          <el-option
            v-for="item in classes"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="有效时间" prop="effectiveTime">
        <el-date-picker
          v-model="dataForm.effectiveTime"
          format="yyyy-MM-dd HH:mm:ss"
          clearable
          style="width: 100%"
          type="datetime"
          placeholder="选择日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item label="身份" prop="type">
        <el-select
          v-model="dataForm.type"
          placeholder="请选择"
          style="width: 100%"
          @change="showType"
        >
          <el-option
            v-for="item in type"
            :key="item.id"
            :label="item.msg"
            :value="item.id"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="证件照" prop="photo">
        <el-upload
          class="avatar-uploader"
          :action="url"
          :show-file-list="true"
          :file-list="fileList"
          :on-success="handleAvatarSuccess"
          :before-upload="beforeAvatarUpload"
          :limit="1"
          :on-error="handleError"
        >
          <img v-if="imageUrl" :src="imageUrl" class="avatar" />
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
        </el-upload>
      </el-form-item>
    </el-form>
    <div>
      <el-button type="primary" :loading="load" @click="mySubmit"
        >提交</el-button
      >
    </div>
  </div>
</template>
<script>
import { baseUrl } from "@/utils/global";
export default {
  components: {},
  data() {
    return {
      photoLoad: false,
      load: false,
      imageFalg: false,
      url: "",
      imageUrl: "",
      fileList:[],
      colleges: [],
      classes: [],
      // 新增编辑界面数据
      dataForm: {},
      sex: [
        { id: 0, msg: "男" },
        { id: 1, msg: "女" },
      ],
      type: [
        { id: 0, msg: "正常" },
        { id: 1, msg: "黑名单" },
        { id: 2, msg: "临时访客" },
      ],
    };
  },
  methods: {
    mySubmit: function () {
      this.load = true;
      this.$api.user.save1(this.dataForm).then((res) => {
        this.load = false;
        if (res.code == 200) {
          this.$message("上传成功");
        } else {
          this.$message({
            message: "操作失败, " + res.msg,
            type: "error",
          });
        }
        this.findUserById();
      });
    },
    handleError: function () {
      this.$message("上传图片失败");
    },
    handleAvatarSuccess(res, file) {
      console.log("res")
      console.log(res)
      console.log("file")
      console.log(file)
      this.$message("上传图片成功");
      // this.imageUrl = URL.createObjectURL(file.raw);
      this.findUserById();
    },
    beforeAvatarUpload(file) {
      this.photoLoad = true;
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      this.url =
        baseUrl +
        "/cs/faceRecognition/register/" +
        sessionStorage.getItem("user");
      console.log("this.url");
      console.log(this.url);
      return isJPG && isLt2M;
    },
    selectClasses: function (data) {
      this.dataForm.userClass = data;
    },
    showClasses: function (data) {
      for (let index = 0; index < this.colleges.length; index++) {
        const element = this.colleges[index];
        if (element.id == data) {
          this.classes = element.classes;
          this.dataForm.userCollege = element.id;
        }
      }
      this.dataForm.userClass = "";
    },
    showType: function (data) {
      this.dataForm.type = data;
    },
    showSex: function (data) {
      this.dataForm.sex = data;
    },
    findUserById: async function () {
      await this.$api.user.getUserTarget().then((res) => {
        this.colleges = res.data.colleges;
        this.classes = this.colleges[0].classes;
      });
      await this.$api.user.findUserById().then((res) => {
        this.dataForm = res.data.user;
        this.imageUrl = this.dataForm.photoPath1;
        for (let index = 0; index < this.colleges.length; index++) {
          const element = this.colleges[index];
          if (this.dataForm.userCollege == element.id) {
            this.classes = element.classes;
          }
        }
      });
    },
  },
  mounted() {
    this.findUserById();
  },
};
</script>
<style scoped>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 50px;
  height: 50px;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>
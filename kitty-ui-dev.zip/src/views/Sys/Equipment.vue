<template>
  <div class="page-container">
    <!--工具栏-->
    <div
      class="toolbar"
      style="float: left; padding-top: 10px; padding-left: 15px"
    >
      <el-form :inline="true" :model="filters" :size="size">
        <el-form-item>
          <el-input v-model="filters.name" placeholder="设备地址"></el-input>
        </el-form-item>
        <el-form-item>
          <kt-button
            icon="fa fa-search"
            :label="$t('action.search')"
            perms="sys:equipment:view"
            type="primary"
            @click="findPage(null)"
          />
        </el-form-item>
        <!-- <el-form-item>
          <kt-button
            icon="fa fa-plus"
            :label="$t('action.add')"
            perms="sys:role:add"
            type="primary"
            @click="handleAdd"
          />
        </el-form-item> -->
      </el-form>
    </div>
    <!--表格内容栏-->
    <kt-table
      :height="220"
      permsEdit="sys:equipment:edit"
      permsDelete="sys:equipment:delete"
      :highlightCurrentRow="true"
      :stripe="false"
      :data="pageResult"
      :columns="columns"
      :showBatchDelete="false"
      @handleCurrentChange="handleRoleSelectChange"
      @findPage="findPage"
      @handleEdit="handleEdit"
      @handleDelete="handleDelete"
    >
    </kt-table>
    <!-- </el-col> -->
    <!--新增编辑界面-->
    <el-dialog
      :title="operation ? '新增' : '编辑'"
      width="40%"
      :visible.sync="dialogVisible"
      :close-on-click-modal="false"
    >
      <el-form
        :model="dataForm"
        label-width="80px"
        :rules="dataFormRules"
        ref="dataForm"
        :size="size"
      >
        <el-form-item label="ID" prop="id">
          <el-input
            v-model="dataForm.id"
            :disabled="!operation"
            auto-complete="off"
          ></el-input>
        </el-form-item>
        <!-- equipmentLocation: "",
        equipmentIp: "",
		equipmentSoftwareVersion: "",
        equipmentStatus: "", -->
        <el-form-item label="设备地点" prop="equipmentLocation">
          <el-input
            v-model="dataForm.equipmentLocation"
            auto-complete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="设备IP " prop="equipmentIp">
          <el-input
            v-model="dataForm.equipmentIp"
            auto-complete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="软件版本 " prop="equipmentSoftwareVersion">
          <el-input
            v-model="dataForm.equipmentSoftwareVersion"
            auto-complete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="设备状态 " prop="equipmentStatus">
          <!-- <el-input
            v-model="dataForm.equipmentStatus"
            auto-complete="off"
          ></el-input> -->
          <el-select
            v-model="dataForm.equipmentStatus"
            placeholder="请选择"
            style="width: 100%"
            @change="showSex"
          >
            <el-option
              v-for="item in status"
              :key="item.id"
              :label="item.msg"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button :size="size" @click.native="dialogVisible = false">{{
          $t("action.cancel")
        }}</el-button>
        <el-button
          :size="size"
          type="primary"
          @click.native="submitForm"
          :loading="editLoading"
          >{{ $t("action.submit") }}</el-button
        >
      </div>
    </el-dialog>
    <!--表格内容栏-->
    <kt-table
      :height="270"
      :data="pageUserResult"
      :columns="filterColumns"
      :showBatchAdd="true"
      :showOperation="false"
      :ownedUser="ownedUser"
      :ownedEquipment="ownedEquipment"
      @findPage="findUserPage"
      permsAdd="sys:equipmentUser:add"
      @handleAdd="handleAddUser"
      ref="myTable"
    >
    </kt-table>
  </div>
</template>

<script>
import KtTable from "@/views/Core/KtTable";
import KtButton from "@/views/Core/KtButton";
import TableTreeColumn from "@/views/Core/TableTreeColumn";
import { format } from "@/utils/datetime";
export default {
  components: {
    KtTable,
    KtButton,
    TableTreeColumn,
  },
  data() {
    return {
      size: "small",
      filters: {
        name: "",
      },
      ownedUser: [],
      ownedEquipment: "",
      columns: [
        { prop: "id", label: "ID", minWidth: 50 },
        { prop: "equipmentLocation", label: "设备地点", minWidth: 120 },
        { prop: "equipmentIp", label: "设备网址", minWidth: 120 },
        { prop: "equipmentSoftwareVersion", label: "软件版本", minWidth: 120 },
        { prop: "equipmentStatus", label: "设备状态", minWidth: 120 },
      ],
      filterColumns: [
        { prop: "userId", label: "ID", minWidth: 100 },
        { prop: "username", label: "用户名", minWidth: 60 },
        { prop: "sex", label: "性别", minWidth: 50 },
        { prop: "userCollege", label: "学院", minWidth: 80 },
        { prop: "userClass", label: "班级", minWidth: 80 },
        { prop: "type", label: "身份", minWidth: 50 },
      ],
      pageRequest: { pageNum: 1, pageSize: 10 },
      pageResult: {},
      pageUserResult: {},

      operation: false, // true:新增, false:编辑
      dialogVisible: false, // 新增编辑界面是否显示
      editLoading: false,
      dataFormRules: {
        name: [{ required: true, message: "请输入角色名", trigger: "blur" }],
      },
      status: [
        { id: "0", msg: "离线" },
        { id: "1", msg: "在线" },
      ],
      // 新增编辑界面数据
      dataForm: {
        id: 0,
        equipmentLocation: "",
        equipmentIp: "",
        equipmentSoftwareVersion: "",
        equipmentStatus: "",
      },
      selectRole: {},
      menuData: [],
      menuSelections: [],
      menuLoading: false,
      authLoading: false,
      checkAll: false,
      currentRoleMenus: [],
      defaultProps: {
        children: "children",
        label: "name",
      },
    };
  },
  methods: {
    handleAddUser: function (params) {
      let ques = {};
      let array = [];
      let array1 = [];
      ques.equipmentId = params.params.equipmentId;
      for (let index = 0; index < params.params.params.length; index++) {
        array[index] = params.params.params[index].id;
      }
      ques.userIds = array;
      for (let index = 0; index < this.pageUserResult.content.length; index++) {
        array1[index] = this.pageUserResult.content[index].userId;
      }
      ques.deleteUserIds = array1;
      this.$api.equipment.equipmentAdduser(ques).then((res) => {
        params != null ? params.callback(res) : "";
      });
    },
    findUserPage: function (data) {
      if (data !== null) {
        this.pageRequest = data.pageRequest;
      }
      this.pageRequest.columnFilters = {
        name: { name: "name", value: this.filters.name },
      };
      // username
      this.pageRequest.username = this.filters.name;
      this.$api.user
        .findPage(this.pageRequest)
        .then((res) => {
          if (res.code == 1000 && res.success == false) {
            return;
          }
          this.pageUserResult = res.data;
          for (
            let index = 0;
            index < this.pageUserResult.content.length;
            index++
          ) {
            this.pageUserResult.content[index].id =
              this.pageUserResult.content[index].userId;
          }
        })
        .then(data != null ? data.callback : "");
    },
    // 获取分页数据
    findPage: function (data) {
      if (data !== null) {
        this.pageRequest = data.pageRequest;
      }
      this.pageRequest.columnFilters = {
        name: { name: "name", value: this.filters.name },
      };
      this.pageRequest.name = this.filters.name;
      this.$api.equipment
        .findPage(this.pageRequest)
        .then((res) => {
          if (res.code == 1000 && res.success == false) {
            return;
          }
          this.pageResult = res.data;
          for (let index = 0; index < this.pageResult.content.length; index++) {
            this.pageResult.content[index].id =
              this.pageResult.content[index].equipmentId;
            if (this.pageResult.content[index].equipmentStatus == 0)
              this.pageResult.content[index].equipmentStatus = "离线";
            if (this.pageResult.content[index].equipmentStatus == 1)
              this.pageResult.content[index].equipmentStatus = "在线";
          }
          this.findTreeData();
        })
        .then(data != null ? data.callback : "");
    },
    // 批量删除
    handleDelete: function (data) {
      this.$api.equipment
        .deleteEquipment(data.params[0].id + "")
        .then(data.callback);
    },
    // 显示新增界面
    handleAdd: function () {
      this.dialogVisible = true;
      this.operation = true;
      this.dataForm = {
        id: 0,
        equipmentLocation: "",
        equipmentIp: "",
        equipmentSoftwareVersion: "",
        equipmentStatus: "",
      };
    },
    // 显示编辑界面
    handleEdit: function (params) {
      this.dialogVisible = true;
      this.operation = false;
      this.dataForm = Object.assign({}, params.row);
      if (this.dataForm.equipmentStatus == "离线")
        this.dataForm.equipmentStatus = "0";
      else {
        this.dataForm.equipmentStatus = "1";
      }
    },
    // 编辑
    submitForm: function () {
      this.$refs.dataForm.validate((valid) => {
        if (valid) {
          this.$confirm("确认提交吗？", "提示", {}).then(() => {
            this.editLoading = true;
            if (this.dataForm.id === 0) this.dataForm.equipmentId = null;
            else this.dataForm.equipmentId = this.dataForm.id;
            let params = Object.assign({}, this.dataForm);
            this.$api.equipment.save(params).then((res) => {
              if (res.code == 1000 && res.success == false) {
                this.editLoading = false;
                return;
              }
              this.editLoading = false;
              if (res.code == 200) {
                this.$message({ message: "操作成功", type: "success" });
                this.dialogVisible = false;
                this.$refs["dataForm"].resetFields();
              } else {
                this.$message({
                  message: "操作失败, " + res.msg,
                  type: "error",
                });
              }
              this.findPage(null);
            });
          });
        }
      });
    },
    // 获取数据
    findTreeData: function () {
      this.menuLoading = true;
      this.$api.menu.findMenuTree().then((res) => {
        if (res.code == 1000 && res.success == false) {
          this.menuLoading = false;
          return;
        }
        this.menuData = res.data.permissionList;
        this.menuLoading = false;
      });
    },
    // 角色选择改变监听
    handleRoleSelectChange(val) {
      if (val == null || val.val == null) {
        return;
      }
      this.selectRole = val.val;
      this.ownedEquipment = this.selectRole.equipmentId;
      this.$api.equipment
        .selectEquipmentUser(this.selectRole.equipmentId)
        .then((res) => {
          if (res.code == 1000 && res.success == false) {
          return;
        }
          this.ownedUser = res.data.equipmentUserInfos;
          let flag = true;
          for (let index = 0; index < this.ownedUser.length; index++) {
            const e = this.ownedUser[index];
            for (
              let index = 0;
              index < this.pageUserResult.content.length;
              index++
            ) {
              const e1 = this.pageUserResult.content[index];
              if (e1.userId == e.userId) {
                this.$refs.myTable.$refs.myElTable.toggleRowSelection(e1, true);
                flag = false;
              }
            }
          }
          if (flag) {
            this.$refs.myTable.$refs.myElTable.clearSelection();
          }
        });
    },
    // 树节点选择监听
    handleMenuCheckChange(data, check, subCheck) {
      if (check) {
        // 节点选中时同步选中父节点
        let parentId = data.parentId;
        this.$refs.menuTree.setChecked(parentId, true, false);
      } else {
        // 节点取消选中时同步取消选中子节点
        if (data.children != null) {
          data.children.forEach((element) => {
            this.$refs.menuTree.setChecked(element.id, false, false);
          });
        }
      }
    },
    // 重置选择
    resetSelection() {
      this.checkAll = false;
      this.$refs.menuTree.setCheckedNodes(this.currentRoleMenus);
    },
    // 全选操作
    handleCheckAll() {
      if (this.checkAll) {
        let allMenus = [];
        this.checkAllMenu(this.menuData, allMenus);
        this.$refs.menuTree.setCheckedNodes(allMenus);
      } else {
        this.$refs.menuTree.setCheckedNodes([]);
      }
    },
    // 递归全选
    checkAllMenu(menuData, allMenus) {
      menuData.forEach((menu) => {
        allMenus.push(menu);
        if (menu.children) {
          this.checkAllMenu(menu.children, allMenus);
        }
      });
    },
    // 角色菜单授权提交
    submitAuthForm() {
      let roleId = this.selectRole.id;
      if ("admin" == this.selectRole.name) {
        this.$message({
          message: "超级管理员拥有所有菜单权限，不允许修改！",
          type: "error",
        });
        return;
      }
      this.authLoading = true;
      let checkedNodes = this.$refs.menuTree.getCheckedNodes(false, true);
      let roleMenus = [];
      let params = {};
      params.roleId = roleId;
      for (let i = 0, len = checkedNodes.length; i < len; i++) {
        let roleMenu = { roleId: roleId, permissionId: checkedNodes[i].id };
        roleMenus.push(checkedNodes[i].id);
      }
      params.permissionIds = roleMenus;
      this.$api.role.saveRoleMenus(params).then((res) => {
        if (res.code == 200) {
          this.$message({ message: "操作成功", type: "success" });
        } else {
          this.$message({ message: "操作失败, " + res.msg, type: "error" });
        }
        this.authLoading = false;
      });
    },
    renderContent(h, { node, data, store }) {
      return (
        <div class="column-container">
          <span style="text-algin:center;margin-right:80px;">{data.name}</span>
          <span style="text-algin:center;margin-right:80px;">
            <el-tag
              type={data.type === 0 ? "" : data.type === 1 ? "success" : "info"}
              size="small"
            >
              {data.type === 0 ? "目录" : data.type === 1 ? "菜单" : "按钮"}
            </el-tag>
          </span>
          <span style="text-algin:center;margin-right:80px;">
            {" "}
            <i class={data.icon}></i>
          </span>
          <span style="text-algin:center;margin-right:80px;">
            {data.parentName ? data.parentName : "顶级菜单"}
          </span>
          <span style="text-algin:center;margin-right:80px;">
            {data.url ? data.url : "\t"}
          </span>
        </div>
      );
    },
    // 时间格式化
    dateFormat: function (row, column, cellValue, index) {
      return format(row[column.property]);
    },
  },
  mounted() {},
};
</script>
<style scoped>
.menu-container {
  margin-top: 10px;
}
.menu-header {
  padding-left: 8px;
  padding-bottom: 5px;
  text-align: left;
  font-size: 16px;
  color: rgb(20, 89, 121);
}
</style>
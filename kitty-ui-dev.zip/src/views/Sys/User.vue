<template>
  <div class="page-container">
    <!--工具栏-->
    <div
      class="toolbar"
      style="float: left; padding-top: 10px; padding-left: 15px"
    >
      <el-form :inline="true" :model="filters" :size="size">
        <el-form-item>
          <el-input v-model="filters.name" placeholder="用户名"></el-input>
        </el-form-item>
        <el-form-item>
          <kt-button
            icon="fa fa-search"
            :label="$t('action.search')"
            perms="sys:user:view"
            type="primary"
            @click="findPage(null)"
          />
        </el-form-item>
        <el-form-item>
          <kt-button
            icon="fa fa-plus"
            :label="$t('action.add')"
            perms="sys:user:add"
            type="primary"
            @click="handleAdd"
          />
        </el-form-item>
      </el-form>
    </div>
    <div
      class="toolbar"
      style="float: right; padding-top: 10px; padding-right: 15px"
    >
      <el-form :inline="true" :size="size">
        <el-form-item>
          <el-button-group>
            <el-tooltip content="刷新" placement="top">
              <el-button
                icon="fa fa-refresh"
                @click="findPage(null)"
              ></el-button>
            </el-tooltip>
            <el-tooltip content="列显示" placement="top">
              <el-button
                icon="fa fa-filter"
                @click="displayFilterColumnsDialog"
              ></el-button>
            </el-tooltip>
            <!-- <el-tooltip content="导出" placement="top">
					<el-button icon="fa fa-file-excel-o"></el-button>
				</el-tooltip> -->
          </el-button-group>
        </el-form-item>
      </el-form>
      <!--表格显示列界面-->
      <table-column-filter-dialog
        ref="tableColumnFilterDialog"
        :columns="columns"
        @handleFilterColumns="handleFilterColumns"
      >
      </table-column-filter-dialog>
    </div>
    <!--表格内容栏-->
    <kt-table
      :height="350"
      permsEdit="sys:user:edit"
      permsDelete="sys:user:delete"
      :data="pageResult"
      :columns="filterColumns"
      @findPage="findPage"
      @handleEdit="handleEdit"
      @handleDelete="handleDelete"
    >
    </kt-table>
    <!--新增编辑界面-->
    <el-dialog
      :title="operation ? '新增' : '编辑'"
      width="40%"
      :visible.sync="dialogVisible"
      :close-on-click-modal="false"
    >
      <el-form
        :model="dataForm"
        label-width="80px"
        :rules="dataFormRules"
        ref="dataForm"
        :size="size"
        label-position="right"
      >
        <el-form-item label="ID" prop="userId" v-if="operation">
          <el-input
            v-model="dataForm.userId"
            :disabled="!operation"
            auto-complete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="用户名" prop="username">
          <el-input v-model="dataForm.username" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="dataForm.password"
            type="password"
            auto-complete="off"
          ></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="sex">
          <!-- <el-input v-model="dataForm.sex" auto-complete="off"></el-input> -->
          <el-select
            v-model="dataForm.sex"
            placeholder="请选择"
            style="width: 100%"
            @change="showSex"
          >
            <el-option
              v-for="item in sex"
              :key="item.id"
              :label="item.msg"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="学院" prop="userCollege">
          <!-- <el-input
            v-model="dataForm.userCollege"
            auto-complete="off"
          ></el-input> -->
          <el-select
            v-model="dataForm.userCollege"
            placeholder="请选择"
            style="width: 100%"
            @change="showClasses"
          >
            <el-option
              v-for="item in colleges"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <!-- <el-form-item label="专业" prop="userMajor">
          <el-input v-model="dataForm.userMajor" auto-complete="off"></el-input>
        </el-form-item> -->
        <el-form-item label="班级" prop="userClass">
          <!-- <el-input v-model="dataForm.userClass" auto-complete="off"></el-input> -->
          <el-select
            v-model="dataForm.userClass"
            placeholder="请选择"
            style="width: 100%"
            @change="selectClasses"
          >
            <el-option
              v-for="item in classes"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="有效时间" prop="effectiveTime">
          <el-date-picker
            v-model="dataForm.effectiveTime"
            format="yyyy-MM-dd HH:mm:ss"
            clearable
            style="width: 100%"
            type="datetime"
            placeholder="选择日期"
          ></el-date-picker>
        </el-form-item>
        <el-form-item label="身份" prop="type">
          <!-- <el-input v-model="dataForm.type" auto-complete="off"></el-input> -->
          <el-select
            v-model="dataForm.type"
            placeholder="请选择"
            style="width: 100%"
            @change="showType"
          >
            <el-option
              v-for="item in type"
              :key="item.id"
              :label="item.msg"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="角色" prop="userRoles">
          <el-select
            v-model="dataForm.userRoles"
            multiple
            placeholder="请选择"
            style="width: 100%"
          >
            <el-option
              v-for="item in roles"
              :key="item.id"
              :label="item.roleName"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="证件照" prop="photo" v-if="imageFalg">
          <el-upload
            class="avatar-uploader"
            :action="url"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload"
            :on-error="handleError"
            :limit="1"
          >
            <img v-if="imageUrl" :src="imageUrl" class="avatar" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button :size="size" @click.native="dialogVisible = false">{{
          $t("action.cancel")
        }}</el-button>
        <el-button
          :size="size"
          type="primary"
          @click.native="submitForm"
          :loading="editLoading"
          >{{ $t("action.submit") }}</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import PopupTreeInput from "@/components/PopupTreeInput";
import KtTable from "@/views/Core/KtTable";
import KtButton from "@/views/Core/KtButton";
import TableColumnFilterDialog from "@/views/Core/TableColumnFilterDialog";
import { format } from "@/utils/datetime";
import { baseUrl } from "@/utils/global";
export default {
  components: {
    PopupTreeInput,
    KtTable,
    KtButton,
    TableColumnFilterDialog,
  },
  data() {
    return {
      imageFalg: false,
      url: "",
      imageUrl: "",
      size: "small",
      filters: {
        name: "",
      },
      sex: [
        { id: 0, msg: "男" },
        { id: 1, msg: "女" },
      ],
      type: [
        { id: 0, msg: "正常" },
        { id: 1, msg: "黑名单" },
        { id: 2, msg: "临时访客" },
      ],
      columns: [],
      filterColumns: [],
      pageRequest: { pageNum: 1, pageSize: 10 },
      pageResult: {},

      operation: false, // true:新增, false:编辑
      dialogVisible: false, // 新增编辑界面是否显示
      editLoading: false,
      dataFormRules: {
        name: [{ required: true, message: "请输入用户名", trigger: "blur" }],
      },
      colleges: [
        { id: "1", name: "软件学院" },
        { id: "2", name: "机械学院" },
      ],
      classes: [
        { id: "1", name: "软件工程1111班" },
        { id: "2", name: "软件工程2222班" },
      ],
      // 新增编辑界面数据
      dataForm: {
        userId: 0,
        username: "",
        password: "",
        sex: "",
        userCollege: "",
        // userMajor: "",
        userClass: "",
        effectiveTime: "",
        type: "",
        userRoles: [],
      },
      deptData: [],
      deptTreeProps: {
        label: "name",
        children: "children",
      },
      roles: [],
    };
  },
  methods: {
    handleError: function () {
      this.$message("上传图片失败");
    },
    handleAvatarSuccess(res, file) {
      this.imageUrl = URL.createObjectURL(file.raw);
      this.$message("上传图片成功")
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error("上传头像图片只能是 JPG格式!");
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    },
    selectClasses: function (data) {
      this.dataForm.userClass = data;
    },
    showClasses: function (data) {
      for (let index = 0; index < this.colleges.length; index++) {
        const element = this.colleges[index];
        if (element.id == data) {
          this.classes = element.classes;
          this.dataForm.userCollege = element.id;
        }
      }
      this.dataForm.userClass = "";
    },
    showType: function (data) {
      this.dataForm.type = data;
    },
    showSex: function (data) {
      this.dataForm.sex = data;
    },
    getUserTarget: function () {
      this.$api.user.getUserTarget().then((res) => {
        if (res.code == 1000 && res.success == false) {
          this.$message.error(res.message);
          return;
        }
        this.colleges = res.data.colleges;
        this.classes = this.colleges[0].classes;
      });
    },
    // 获取分页数据
    findPage: function (data) {
      if (data !== null) {
        this.pageRequest = data.pageRequest;
      }
      this.pageRequest.columnFilters = {
        name: { name: "name", value: this.filters.name },
      };
      // username
      this.pageRequest.username = this.filters.name;
      this.$api.user
        .findPage(this.pageRequest)
        .then((res) => {
          if (res.code == 1000 && res.success == false) {
            this.$message.error(res.message);
            return;
          }
          this.pageResult = res.data;
          for (let index = 0; index < this.pageResult.content.length; index++) {
            this.pageResult.content[index].id =
              this.pageResult.content[index].userId;
            if (this.pageResult.content[index].sex == "0")
              this.pageResult.content[index].sex = "男";
            else {
              this.pageResult.content[index].sex = "女";
            }
            if (this.pageResult.content[index].type == "0")
              this.pageResult.content[index].type = "正常";
            else if (this.pageResult.content[index].type == "1") {
              this.pageResult.content[index].type = "黑名单";
            } else {
              this.pageResult.content[index].type = "临时访客";
            }
          }
          this.findUserRoles();
        })
        .then(data != null ? data.callback : "");
    },
    // 加载用户角色信息
    findUserRoles: function () {
      this.$api.role.findAll().then((res) => {
        if (res.code == 1000 && res.success == false) {
          this.$message.error(res.message);
          return;
        }
        // 加载角色集合
        this.roles = res.data.roles;
      });
    },
    // 批量删除
    handleDelete: function (data) {
      let params = [];
      for (let index = 0; index < data.params.length; index++) {
        const element = data.params[index];
        params[index] = element.id;
      }
      this.$api.user
        .batchDelete(params)
        .then(data != null ? data.callback : "");
    },
    // 显示新增界面
    handleAdd: function () {
      this.imageFalg = false;
      this.dialogVisible = true;
      this.operation = true;
      this.dataForm = {
        userId: 0,
        username: "",
        password: "",
        sex: "",
        userCollege: "",
        // userMajor: "",
        userClass: "",
        effectiveTime: "",
        type: "",
        userRoles: [],
      };
    },
    // 显示编辑界面
    handleEdit: function (params) {
      this.imageFalg = true;
      this.dialogVisible = true;
      this.operation = false;
      this.dataForm = Object.assign({}, params.row);
      this.imageUrl = this.dataForm.photoPath1;
      this.url =
        baseUrl +
        "/cs/faceRecognition/register/" + this.dataForm.userId;
      if (this.dataForm.sex == "男") this.dataForm.sex = 0;
      else {
        this.dataForm.sex = 1;
      }
      if (this.dataForm.type == "正常") this.dataForm.type = 0;
      else if (this.dataForm.type == "黑名单") {
        this.dataForm.type = 1;
      } else {
        this.dataForm.type = 2;
      }
      let userRoles = [];
      for (let i = 0, len = params.row.userRoles.length; i < len; i++) {
        userRoles.push(params.row.userRoles[i].id);
      }
      this.dataForm.userRoles = userRoles;
      for (let index = 0; index < this.colleges.length; index++) {
        const element = this.colleges[index];
        if (element.name == this.dataForm.userCollege) {
          this.dataForm.userCollege = element.id;
          this.classes = element.classes;
          for (let i = 0; index < element.classes.length; i++) {
            if (this.dataForm.userClass == element.classes[i].name) {
              this.dataForm.userClass = element.classes[i].id;
            }
          }
        }
      }
    },
    // 编辑
    submitForm: function () {
      this.$refs.dataForm.validate((valid) => {
        if (valid) {
          this.$confirm("确认提交吗？", "提示", {}).then(() => {
            this.editLoading = true;
            let params = Object.assign({}, this.dataForm);
            let userRoles = [];
            for (let i = 0, len = params.userRoles.length; i < len; i++) {
              let userRole = {
                userId: params.userId,
                roleId: params.userRoles[i],
              };
              userRoles.push(userRole);
            }
            params.photoPath = null;
            params.faceFeature = null;
            params.paramsUserRoles = userRoles;
            params.userRoles = null;
            if (this.operation) {
              params.insertFlag = true;
            } else {
              params.insertFlag = false;
            }

            this.$api.user.save(params).then((res) => {
              this.editLoading = false;
              if (res.code == 200) {
                this.$message({ message: "操作成功", type: "success" });
                this.dialogVisible = false;
                this.$refs["dataForm"].resetFields();
              } else {
                this.$message({
                  message: "操作失败, " + res.msg,
                  type: "error",
                });
              }
              this.findPage(null);
            });
          });
        }
      });
    },

    // 菜单树选中
    deptTreeCurrentChangeHandle(data, node) {
      this.dataForm.deptId = data.id;
      this.dataForm.deptName = data.name;
    },
    // 时间格式化
    dateFormat: function (row, column, cellValue, index) {
      return format(row[column.property]);
    },
    // 处理表格列过滤显示
    displayFilterColumnsDialog: function () {
      this.$refs.tableColumnFilterDialog.setDialogVisible(true);
    },
    // 处理表格列过滤显示
    handleFilterColumns: function (data) {
      this.filterColumns = data.filterColumns;
      this.$refs.tableColumnFilterDialog.setDialogVisible(false);
    },
    // 处理表格列过滤显示
    initColumns: function () {
      this.columns = [
        { prop: "userId", label: "ID", minWidth: 100 },
        { prop: "username", label: "用户名", minWidth: 60 },
        { prop: "sex", label: "性别", minWidth: 50 },
        { prop: "userCollege", label: "学院", minWidth: 80 },
        // { prop: "userMajor", label: "专业", minWidth: 80 },
        { prop: "userClass", label: "班级", minWidth: 80 },
        {
          prop: "effectiveTime",
          label: "有效时间",
          minWidth: 80,
          formatter: this.dateFormat,
        },
        { prop: "type", label: "身份", minWidth: 50 },
        { prop: "roles", label: "拥有角色", minWidth: 70 },
        // {prop:"createBy", label:"创建人", minWidth:120},
        // {prop:"createTime", label:"创建时间", minWidth:120, formatter:this.dateFormat}
        // {prop:"lastUpdateBy", label:"更新人", minWidth:100},
        // {prop:"lastUpdateTime", label:"更新时间", minWidth:120, formatter:this.dateFormat}
      ];
      this.filterColumns = JSON.parse(JSON.stringify(this.columns));
    },
  },
  mounted() {
    this.initColumns();
    this.getUserTarget();
  },
};
</script>

<style scoped>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 50px;
  height: 50px;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>
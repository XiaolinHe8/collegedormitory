<template>
  <div class="page-container">
    <div>
      <label for="" style="font-size: 12px">开始日期</label>
      <el-date-picker
        style="font-size:12px;h width: 170px;"
        v-model="startDate"
        type="date"
        placeholder="选择日期"
        format="yyyy 年 MM 月 dd 日"
        value-format="yyyy-MM-dd"
      >
      </el-date-picker>
      <label for="" style="font-size: 12px">截止日期</label>
      <el-date-picker
        style="font-size: 12px; width: 170px"
        v-model="endDate"
        type="date"
        placeholder="选择日期"
        format="yyyy 年 MM 月 dd 日"
        value-format="yyyy-MM-dd"
      >
      </el-date-picker>
      <kt-button
        label="查询"
        perms="sys:record:view"
        size="10px"
        :disabled="false"
        type="info"
        @click="handleSelectRecord()"
      />
    </div>
    <div
      ref="container"
      style="height: 300px; width: 100%"
      v-loading="loading"
    ></div>
    <div style="height: 400px; width: 49%; padding: 5px; float: left">
      <h4>原始进出记录</h4>
      <template>
        <el-table :data="records0" style="width: 100%" height="80%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-form-item label="用户ID">
                  <span>{{ props.row.arUserId }}</span>
                </el-form-item>
                <el-form-item label="用户名">
                  <span>{{ props.row.username }}</span>
                </el-form-item>
                <el-form-item label="班级">
                  <span>{{ props.row.userClass }}</span>
                </el-form-item>
                <el-form-item label="设备ID">
                  <span>{{ props.row.arQuipmentId }}</span>
                </el-form-item>

                <el-form-item label="进入时间">
                  <span>{{ props.row.inTime }}</span>
                </el-form-item>
                <el-form-item label="离开时间">
                  <span>{{ props.row.outTime }}</span>
                </el-form-item>
                <el-form-item label="进入照片">
                  <el-image
                    :src="props.row.inPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>

                <el-form-item label="离开照片">
                  <el-image
                    :src="props.row.outPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>
                <el-form-item label="进入记录">
                  <span>{{ props.row.inRecord }}</span>
                </el-form-item>
                <el-form-item label="离开记录">
                  <span>{{ props.row.outRecord }}</span>
                </el-form-item>
                <el-form-item label="记录类型">
                  <span>{{ props.row.type }}</span>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column label="用户ID" prop="arUserId"> </el-table-column>
          <el-table-column label="用户名" prop="username"> </el-table-column>
          <el-table-column label="设备ID" prop="arQuipmentId">
          </el-table-column>
          <el-table-column label="进入时间" prop="inTime"> </el-table-column>
          <el-table-column label="离开时间" prop="outTime"> </el-table-column>
        </el-table>
      </template>
    </div>
    <div style="height: 400px; width: 49%; padding: 5px; float: right">
      <h4>非法进出记录</h4>
      <template>
        <el-table :data="records1" style="width: 100%" height="80%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-form-item label="用户ID">
                  <span>{{ props.row.arUserId }}</span>
                </el-form-item>
                <el-form-item label="用户名">
                  <span>{{ props.row.username }}</span>
                </el-form-item>
                <el-form-item label="班级">
                  <span>{{ props.row.userClass }}</span>
                </el-form-item>
                <el-form-item label="设备ID">
                  <span>{{ props.row.arQuipmentId }}</span>
                </el-form-item>

                <el-form-item label="进入时间">
                  <span>{{ props.row.inTime }}</span>
                </el-form-item>
                <el-form-item label="离开时间">
                  <span>{{ props.row.outTime }}</span>
                </el-form-item>
                <el-form-item label="进入照片">
                  <el-image
                    :src="props.row.inPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>

                <el-form-item label="离开照片">
                  <el-image
                    :src="props.row.outPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>
                <el-form-item label="进入记录">
                  <span>{{ props.row.inRecord }}</span>
                </el-form-item>
                <el-form-item label="离开记录">
                  <span>{{ props.row.outRecord }}</span>
                </el-form-item>
                <el-form-item label="记录类型">
                  <span>{{ props.row.type }}</span>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column label="用户ID" prop="arUserId"> </el-table-column>
          <el-table-column label="用户名" prop="username"> </el-table-column>
          <el-table-column label="设备ID" prop="arQuipmentId">
          </el-table-column>
          <el-table-column label="进入时间" prop="inTime"> </el-table-column>
          <el-table-column label="离开时间" prop="outTime"> </el-table-column>
        </el-table>
      </template>
    </div>
    <div style="height: 400px; width: 49%; padding: 5px; float: left">
      <h4>晚归进出记录</h4>
      <template>
        <el-table :data="records2" style="width: 100%" height="80%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-form-item label="用户ID">
                  <span>{{ props.row.arUserId }}</span>
                </el-form-item>
                <el-form-item label="用户名">
                  <span>{{ props.row.username }}</span>
                </el-form-item>
                <el-form-item label="班级">
                  <span>{{ props.row.userClass }}</span>
                </el-form-item>
                <el-form-item label="设备ID">
                  <span>{{ props.row.arQuipmentId }}</span>
                </el-form-item>

                <el-form-item label="进入时间">
                  <span>{{ props.row.inTime }}</span>
                </el-form-item>
                <el-form-item label="离开时间">
                  <span>{{ props.row.outTime }}</span>
                </el-form-item>
                <el-form-item label="进入照片">
                  <el-image
                    :src="props.row.inPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>

                <el-form-item label="离开照片">
                  <el-image
                    :src="props.row.outPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>
                <el-form-item label="进入记录">
                  <span>{{ props.row.inRecord }}</span>
                </el-form-item>
                <el-form-item label="离开记录">
                  <span>{{ props.row.outRecord }}</span>
                </el-form-item>
                <el-form-item label="记录类型">
                  <span>{{ props.row.type }}</span>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column label="用户ID" prop="arUserId"> </el-table-column>
          <el-table-column label="用户名" prop="username"> </el-table-column>
          <el-table-column label="设备ID" prop="arQuipmentId">
          </el-table-column>
          <el-table-column label="进入时间" prop="inTime"> </el-table-column>
          <el-table-column label="离开时间" prop="outTime"> </el-table-column>
        </el-table>
      </template>
    </div>
    <div style="height: 400px; width: 49%; padding: 5px; float: right">
      <h4>异常进出记录</h4>
      <template>
        <el-table :data="records3" style="width: 100%" height="80%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-form-item label="用户ID">
                  <span>{{ props.row.arUserId }}</span>
                </el-form-item>
                <el-form-item label="用户名">
                  <span>{{ props.row.username }}</span>
                </el-form-item>
                <el-form-item label="班级">
                  <span>{{ props.row.userClass }}</span>
                </el-form-item>
                <el-form-item label="设备ID">
                  <span>{{ props.row.arQuipmentId }}</span>
                </el-form-item>

                <el-form-item label="进入时间">
                  <span>{{ props.row.inTime }}</span>
                </el-form-item>
                <el-form-item label="离开时间">
                  <span>{{ props.row.outTime }}</span>
                </el-form-item>
                <el-form-item label="进入照片">
                  <el-image
                    :src="props.row.inPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>

                <el-form-item label="离开照片">
                  <el-image
                    :src="props.row.outPhotoPath"
                    style="width: 100px; height: 100px"
                  >
                    <div slot="placeholder" class="image-slot">
                      加载中<span class="dot">...</span>
                    </div>
                    <div slot="error" class="image-slot">
                      <i class="el-icon-picture-outline"></i>
                    </div>
                  </el-image>
                </el-form-item>
                <el-form-item label="进入记录">
                  <span>{{ props.row.inRecord }}</span>
                </el-form-item>
                <el-form-item label="离开记录">
                  <span>{{ props.row.outRecord }}</span>
                </el-form-item>
                <el-form-item label="记录类型">
                  <span>{{ props.row.type }}</span>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column label="用户ID" prop="arUserId"> </el-table-column>
          <el-table-column label="用户名" prop="username"> </el-table-column>
          <el-table-column label="设备ID" prop="arQuipmentId">
          </el-table-column>
          <el-table-column label="进入时间" prop="inTime"> </el-table-column>
          <el-table-column label="离开时间" prop="outTime"> </el-table-column>
        </el-table>
      </template>
    </div>
  </div>
</template>
    </div>
  </div>
</template>

<script>
import KtButton from "@/views/Core/KtButton";
import { format } from "@/utils/datetime";
const echarts = require("echarts");
export default {
  components: {
    KtButton,
  },
  data() {
    return {
      loading: false,
      startDate: "",
      endDate: "",
      // 分页信息
      pageRequest: {
        pageNum: 1,
        pageSize: 10,
      },
      records0: [],
      records1: [],
      records2: [],
      records3: [],
      bkRecords0: [],
      bkRecords1: [],
      bkRecords2: [],
      bkRecords3: [],
      myDateTime: [],
      dRecords0: [],
      dRecords1: [],
      dRecords2: [],
      dRecords3: [],
    };
  },
  methods: {
    init: function () {
      let today = new Date();
      this.endDate = this.formatDate(today);
      today.setDate(today.getDate() - 7);
      this.startDate = this.formatDate(today);
      this.handleSelectRecord();
    },
    handleSelectRecord: async function () {
      await this.getRecords();
      this.initEcharts(this.getOption());
    },
    formatDate: function (date) {
      let d = new Date(date),
        month = "" + (d.getMonth() + 1),
        day = "" + d.getDate(),
        year = d.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;

      return [year, month, day].join("-");
    },
    getRecords: async function () {
      let getInfoFlag = true;
      this.loading = true;
      let params = {};
      params.userId = null;
      let s = this.startDate.split("-");
      let e = this.endDate.split("-");
      let start = new Date(parseInt(s[0]), parseInt(s[1]) - 1, parseInt(s[2]));
      let end = new Date(parseInt(e[0]), parseInt(e[1]) - 1, parseInt(e[2]));
      this.myDateTime = [];
      this.myDateTime[0] = "时间";
      this.dRecords0 = [];
      this.dRecords0[0] = "原始进出记录";

      this.dRecords1 = [];
      this.dRecords1[0] = "非法进出记录";

      this.dRecords2 = [];
      this.dRecords2[0] = "晚归进出记录";

      this.dRecords3 = [];
      this.dRecords3[0] = "异常进出记录";
      for (let index = 0; start.getTime() <= end.getTime() && getInfoFlag; index++) {
        params.date = this.formatDate(start);
        this.myDateTime[index + 1] = params.date;
        params.type = 0;
        await this.$api.record.selectRecord(params).then((res) => {
          console.log(res)
          if (res.code == 1000 && res.success == false) {
            getInfoFlag = false;
            this.loading = false;
            return;
          }
          this.bkRecords0[index] = res.data.access_record;
          this.dRecords0[index + 1] = res.data.access_record.length;
          if (index == 0) this.records0 = this.bkRecords0[0];
        });
        if( !getInfoFlag)
          return;
        params.type = 1;
        await this.$api.record.selectRecord(params).then((res) => {
          if (res.code == 1000 && res.success == false) {
             getInfoFlag = false;
            this.loading = false;
            return;
          }
          this.bkRecords1[index] = res.data.access_record;
          this.dRecords1[index + 1] = res.data.access_record.length;
          if (index == 0) this.records1 = this.bkRecords1[0];
        });
        if( !getInfoFlag)
          return;
        await this.$api.record.selectAccessAfter11(params).then((res) => {
          if (res.code == 1000 && res.success == false) {
             getInfoFlag = false;
            this.loading = false;
            return;
          }
          this.bkRecords2[index] = res.data.accessRecords;
          this.dRecords2[index + 1] = res.data.accessRecords.length;
          if (index == 0) this.records2 = this.bkRecords2[0];
        });
        if( !getInfoFlag)
          return;
        await this.$api.record.selectNoAccess(params).then((res) => {
          if (res.code == 1000 && res.success == false) {
             getInfoFlag = false;
            this.loading = false;
            return;
          }
          let temp = [];
          temp.push.apply(temp, res.data.noData);
          temp.push.apply(temp, res.data.notOut);
          temp.push.apply(temp, res.data.notReturned);
          this.bkRecords3[index] = temp;
          this.dRecords3[index + 1] = temp.length;
          if (index == 0) this.records3 = this.bkRecords3[0];
        });
        start.setDate(start.getDate() + 1);
      }
      this.loading = false;
    },

    getOption: function () {
      let option = {
        legend: {},
        tooltip: {
          trigger: "axis",
          showContent: false,
        },
        dataset: {
          source: [
            this.myDateTime,
            this.dRecords0,
            this.dRecords1,
            this.dRecords2,
            this.dRecords3,
          ],
        },
        xAxis: { type: "category" },
        yAxis: { gridIndex: 0 },
        grid: { left: "50%" },
        series: [
          {
            type: "line",
            smooth: true,
            seriesLayoutBy: "row",
            emphasis: { focus: "series" },
          },
          {
            type: "line",
            smooth: true,
            seriesLayoutBy: "row",
            emphasis: { focus: "series" },
          },
          {
            type: "line",
            smooth: true,
            seriesLayoutBy: "row",
            emphasis: { focus: "series" },
          },
          {
            type: "line",
            smooth: true,
            seriesLayoutBy: "row",
            emphasis: { focus: "series" },
          },
          {
            type: "pie",
            id: "pie",
            radius: "30%",
            center: ["20%", "45%"],
            emphasis: {
              focus: "self",
            },
            label: {
              formatter: "{b}: {@2012} ({d}%)",
            },
            encode: {
              itemName: this.myDateTime[0],
              value: this.myDateTime[1],
              tooltip: this.myDateTime[1],
            },
          },
        ],
      };
      return option;
    },

    // 获取数据
    initEcharts: function (option) {
      let dom = this.$refs.container;
      let myChart = echarts.init(dom);
      const _this = this;
      myChart.on("updateAxisPointer", function (event) {
        const xAxisInfo = event.axesInfo[0];
        if (xAxisInfo) {
          _this.records0 = _this.bkRecords0[parseInt(xAxisInfo.value)];
          _this.records1 = _this.bkRecords1[parseInt(xAxisInfo.value)];
          _this.records2 = _this.bkRecords2[parseInt(xAxisInfo.value)];
          _this.records3 = _this.bkRecords3[parseInt(xAxisInfo.value)];
          const dimension = xAxisInfo.value + 1;
          myChart.setOption({
            series: {
              id: "pie",
              label: {
                formatter: "{b}: {@[" + dimension + "]} ({d}%)",
              },
              encode: {
                value: dimension,
                tooltip: dimension,
              },
            },
          });
        }
      });

      if (option && typeof option === "object") {
        myChart.setOption(option);
      }
    },
  },
  mounted() {
    this.init();
  },
};
</script>

<style scoped>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
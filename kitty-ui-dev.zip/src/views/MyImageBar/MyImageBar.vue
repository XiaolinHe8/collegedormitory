<template>
  <div class="absolute">
     <el-button
      type="success"
      :icon="icon"
      circle
      @click="showImage"
      style="float:left"
    ></el-button>
    <el-card :body-style="{ padding: '0px' }" v-if="show" style="width: 140px;height: 140px;">
      <img
        :src="url"
        class="image"
      />
    </el-card>
   
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      icon: "el-icon-caret-right",
      show: false,
      url:"",
    };
  },
  methods: {
    showImage: function () {
       this.$api.user.createRQCode().then((res) => {
         this.url = res.data.qrCode
      });

      this.show = !this.show;
      if (this.icon == "el-icon-caret-right") this.icon = "el-icon-caret-left";
      else this.icon = "el-icon-caret-right";
    },
  },
};
</script>
<style scoped>
.image {
  width: 100%;
  display: block;
}
.absolute {
  position: absolute;
  left: 0;
  bottom: 30px;
  width: 190px;height: 200px;
}
</style>

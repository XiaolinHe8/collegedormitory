package hxl.ncu.been;

import com.arcsoft.face.FaceInfo;
import com.arcsoft.face.toolkit.ImageInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.awt.image.BufferedImage;

@Data
@Accessors(chain = true)
@AllArgsConstructor
@NoArgsConstructor
public class MyFaceInfo {
    private ImageInfo imageInfo;
    private FaceInfo faceInfo;
    private int faceId;
    private BufferedImage bufferedImage;
}

package hxl.ncu.FaceRecognitionCS;

import com.arcsoft.face.EngineConfiguration;
import com.arcsoft.face.FaceEngine;
import com.arcsoft.face.FaceInfo;
import com.arcsoft.face.FunctionConfiguration;
import com.arcsoft.face.enums.DetectMode;
import com.arcsoft.face.enums.DetectOrient;
import com.arcsoft.face.enums.ErrorInfo;
import com.arcsoft.face.toolkit.ImageFactory;
import com.arcsoft.face.toolkit.ImageInfo;
import hxl.ncu.Configuration.AppProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FaceRecognition {
    private AppProperties appProperties;
    private FaceEngine faceEngine;
    public FaceEngine create(){
        FaceEngine faceEngine = new FaceEngine(appProperties.getSdkPath());
        int activeCode = faceEngine.activeOnline(appProperties.getAppId(), appProperties.getSdkKey());
        if (activeCode != ErrorInfo.MOK.getValue() && activeCode != ErrorInfo.MERR_ASF_ALREADY_ACTIVATED.getValue()) {
            throw new RuntimeException( "引擎激活失败" + activeCode);
        }
        int initCode = faceEngine.init(getConfig());
        if (initCode != ErrorInfo.MOK.getValue()) {
            throw new RuntimeException( "引擎激活失败" + activeCode);
        }
        this.faceEngine = faceEngine;
        return faceEngine;
    }
    public EngineConfiguration getConfig(){
        //引擎配置
        EngineConfiguration engineConfiguration = new EngineConfiguration();
        engineConfiguration.setDetectMode(DetectMode.ASF_DETECT_MODE_VIDEO);
        engineConfiguration.setDetectFaceOrientPriority(DetectOrient.ASF_OP_0_ONLY);
        engineConfiguration.setDetectFaceMaxNum(5);
        engineConfiguration.setDetectFaceScaleVal(16);
        //功能配置
        FunctionConfiguration functionConfiguration = new FunctionConfiguration();
        functionConfiguration.setSupportAge(false);
        functionConfiguration.setSupportFace3dAngle(false);
        functionConfiguration.setSupportFaceDetect(true);
        functionConfiguration.setSupportFaceRecognition(true);
        functionConfiguration.setSupportGender(false);
        functionConfiguration.setSupportLiveness(true);
        functionConfiguration.setSupportIRLiveness(true);
        engineConfiguration.setFunctionConfiguration(functionConfiguration);
        return engineConfiguration;
    }
    
    public List<FaceInfo> testing(File image){
        ImageInfo img = ImageFactory.getRGBData(image);
        return testing(img);
       
    }
    public List<FaceInfo> testing(ImageInfo img){
        //人脸检测得到人脸列表
        List<FaceInfo> faceInfoList = new ArrayList<FaceInfo>();
        //人脸检测
        int errorCode = faceEngine.detectFaces(img.getImageData(), img.getWidth(), img.getHeight(), img.getImageFormat(), faceInfoList);
        if (errorCode == 0) {
            return faceInfoList;
        } else {
            throw  new RuntimeException("人脸检测失败，errorCode：" + errorCode);
        }
    }
}

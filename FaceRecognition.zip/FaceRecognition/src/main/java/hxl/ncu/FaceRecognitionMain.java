package hxl.ncu;


import hxl.ncu.MyMainThread.MyMainThread;



public class FaceRecognitionMain {
    public static void main(String[] args) {
        MyMainThread myMainThread = new MyMainThread();
        myMainThread.main();
    }
}

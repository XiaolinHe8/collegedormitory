package hxl.ncu.utils;

import java.net.URL;

public class opencvLibUtil {
    public static void getOpencv(String Path){
        URL url = ClassLoader.getSystemResource("lib/opencv_java440.dll");
        System.load(url.getPath());
    }
}

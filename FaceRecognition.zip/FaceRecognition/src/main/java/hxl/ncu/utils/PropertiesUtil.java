package hxl.ncu.utils;

import hxl.ncu.Configuration.AppProperties;

import java.io.*;
import java.util.Properties;

public class PropertiesUtil {
    public static AppProperties getAppProperties(String path){
//        "src/main/resources/face.properties"
        File file = new File(path);
        AppProperties appProperties = new AppProperties();
        Properties properties = new Properties();
        try {
            InputStream in = new FileInputStream(file);
            properties.load(in);
            String sdkPath = properties.getProperty("sdkPath");
            String appId = properties.getProperty("appId");
            String sdkKey = properties.getProperty("sdkKey");
            String equipmentId = properties.getProperty("equipmentId");
            String equipmentLocation = properties.getProperty("equipmentLocation");
            String equipmentSoftwareVersion = properties.getProperty("equipmentSoftwareVersion");
            Boolean inFlag = Boolean.parseBoolean( properties.getProperty("in"));
            String imagePath = properties.getProperty("imagePath");
            appProperties.setSdkPath(sdkPath).setAppId(appId)
                    .setSdkKey(sdkKey).setEquipmentId(equipmentId)
            .setEquipmentLocation(equipmentLocation).setEquipmentSoftwareVersion(equipmentSoftwareVersion)
            .setIn(inFlag).setImagePath(imagePath);
            in.close();
        } catch (FileNotFoundException e) {
           throw new RuntimeException("读取文件错误");
        } catch (IOException e) {
            throw new RuntimeException("读取文件错误1");
        }
        return appProperties;
    }
    public static void writeAppProperties(AppProperties appProperties,String path){
        Properties properties = new Properties();
        properties.setProperty("sdkPath",appProperties.getSdkPath());
        properties.setProperty("appId",appProperties.getAppId());
        properties.setProperty("sdkKey",appProperties.getSdkKey());
        properties.setProperty("equipmentId",appProperties.getEquipmentId());
        properties.setProperty("equipmentLocation",appProperties.getEquipmentLocation());
        properties.setProperty("equipmentSoftwareVersion",appProperties.getEquipmentSoftwareVersion());
        properties.setProperty("in",appProperties.isIn()+"");
        properties.setProperty("imagePath",appProperties.getImagePath());
        File file = new File(path);
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            properties.store(fileOutputStream,null);
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

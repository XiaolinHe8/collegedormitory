package hxl.ncu.MyRecognitionThread;

import cn.hutool.core.util.IdUtil;
import cn.hutool.http.HttpRequest;
import com.alibaba.fastjson.JSONObject;
import com.arcsoft.face.FaceEngine;
import com.arcsoft.face.FaceFeature;
import com.arcsoft.face.FaceInfo;
import com.arcsoft.face.toolkit.ImageInfo;
import hxl.ncu.Configuration.AppProperties;
import hxl.ncu.been.MyFaceInfo;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class MyRecognitionThread {
    // 创建一个固定数量的线程池
   private ExecutorService executor = Executors.newFixedThreadPool(5);
   private BlockingQueue<MyFaceInfo> queue = null;
   private FaceEngine faceEngine = null;
   private AppProperties appProperties;
    
    public MyRecognitionThread(BlockingQueue<MyFaceInfo> queue, FaceEngine faceEngine, AppProperties appProperties) {
        this.queue = queue;
        this.faceEngine = faceEngine;
        this.appProperties = appProperties;
    }
    
    public void run(){
       executor.execute(new Runnable() {
           @Override
           public void run() {
               String url = "http://localhost:8222/cs/faceRecognition/testing?equipmentId="+appProperties.getEquipmentId();
               MyFaceInfo take = null;
               try {
                   take = queue.take();
               } catch (InterruptedException e) {
                   e.printStackTrace();
               }
               FaceFeature faceFeature = new FaceFeature();
               ImageInfo imageInfo = take.getImageInfo();
               FaceInfo faceInfo = take.getFaceInfo();
               int errorCode = faceEngine.extractFaceFeature(imageInfo.getImageData(),
                       imageInfo.getWidth(), imageInfo.getHeight(), imageInfo.getImageFormat(),
                       faceInfo, faceFeature);
               System.out.println("faceId："+ take.getFaceId());
               System.out.println("特征值大小：" + faceFeature.getFeatureData().length);
               System.out.println("特征值：" + faceFeature.getFeatureData());
               HashMap<String, byte[]> map = new HashMap<>();
               map.put("faceFeature",faceFeature.getFeatureData());
               JSONObject jsonObject = null;
               int code = 0;
               boolean success = true;
               do{
                   if(code == 1000){
                       try {
                           Thread.sleep(1000);
                       } catch (InterruptedException e) {
                           e.printStackTrace();
                       }
                   }
                   String post = HttpRequest.post(url)
                           .header("Content-Type", "application/json;charset=UTF-8")
                           .body(JSONObject.toJSONString(map))
                           .execute().body();
                   jsonObject = JSONObject.parseObject(post);
                   code = Integer.parseInt(jsonObject.get("code").toString());
                   success = Boolean.parseBoolean(jsonObject.get("success").toString());
               }while (code == 1000 && !success);
               
               Object data = jsonObject.get("data");
               JSONObject object = JSONObject.parseObject(JSONObject.toJSONString(data));
               String userId =(String) object.get("userInfo");
               Integer type  =(Integer) object.get("type");
               System.out.println("userId="+userId+" type="+type);
               if(userId == null || "".equals(userId))
                   userId = "-1";
               url = "http://localhost:8222/cs/access/inAndOut?userId=p1&equipmentId=p2" +
                       "&in=p3&type=p4";
               String replace = url.replace("p1", userId).replace("p2", appProperties.getEquipmentId())
                       .replace("p4", type + "").replace("p3", appProperties.isIn() + "");
               System.out.println("url="+replace);
               BufferedImage bufferedImage = take.getBufferedImage();
               String fileName =  IdUtil.simpleUUID();
               File mkdir = new File(appProperties.getImagePath());
               if (!mkdir.exists()) {
                   mkdir.mkdirs();
               }
               File file = new File(appProperties.getImagePath() + "/" + fileName + ".jpg");
               try {
                   ImageIO.write(bufferedImage,"jpg",file);
               } catch (IOException e) {
                   e.printStackTrace();
               }
               code = 0;
               do{
                   if(code == 1000){
                       try {
                           Thread.sleep(1000);
                       } catch (InterruptedException e) {
                           e.printStackTrace();
                       }
                   }
                   String res = HttpRequest.post(replace)
                           .form("file", file)
                           .timeout(50000)
                           .execute().body();
                   System.out.println("res====="+res);
                   jsonObject = JSONObject.parseObject(res);
                   code = Integer.parseInt(jsonObject.get("code").toString());
                   success = Boolean.parseBoolean(jsonObject.get("success").toString());
               }while (code == 1000 && !success);
              
           }
       });
   }
   
   public void shutdown(){
        executor.shutdown();
   }
}

package hxl.ncu.Configuration;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class AppProperties {
    private String sdkPath="";
    private String appId = "";
    private String sdkKey= "";
    private String equipmentId = "";
    private String equipmentLocation="";
    private String equipmentSoftwareVersion="";
    private boolean in=true;
    private String imagePath = null;
}

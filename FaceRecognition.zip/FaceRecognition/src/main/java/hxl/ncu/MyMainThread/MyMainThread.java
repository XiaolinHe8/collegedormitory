package hxl.ncu.MyMainThread;

import cn.hutool.http.Header;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSONObject;
import com.arcsoft.face.FaceEngine;
import com.arcsoft.face.FaceInfo;
import com.arcsoft.face.Rect;
import com.arcsoft.face.toolkit.ImageFactory;
import com.arcsoft.face.toolkit.ImageInfo;
import hxl.ncu.Configuration.AppProperties;
import hxl.ncu.FaceRecognitionCS.FaceRecognition;
import hxl.ncu.MyRecognitionThread.MyRecognitionThread;
import hxl.ncu.been.MyFaceInfo;
import hxl.ncu.utils.PropertiesUtil;
import lombok.Data;
import org.bytedeco.javacv.*;
import org.bytedeco.opencv.opencv_core.Mat;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


@Data
public class MyMainThread {
    //当前trackID
    private int currentTrackId = 0;
    //前一帧的trackID列表
    private List<Integer> formerTrackIdList = new ArrayList<>();
    //当前帧的trackID列表
    private List<Integer> currentTrackIdList = new ArrayList<>();
    //前一帧的人脸框列表
    private List<FaceInfo> formerFaceRectList = new ArrayList<>();
    
    private BlockingQueue<MyFaceInfo> queue = new ArrayBlockingQueue<>(50);
    
    OpenCVFrameConverter.ToIplImage converter = new OpenCVFrameConverter.ToIplImage();
    public void main(){
        try {
            AppProperties appProperties = PropertiesUtil.getAppProperties("src/main/resources/face.properties");
            if(appProperties.getEquipmentId() == null || "".equals(appProperties.getEquipmentId())){
                String register = register(appProperties);
                appProperties.setEquipmentId(register);
                PropertiesUtil.writeAppProperties(appProperties,"src/main/resources/face.properties");
            }
            deleteImage(appProperties);
            heartbeatDetection(appProperties.getEquipmentId());
            FaceRecognition faceRecognition = new FaceRecognition(appProperties,null);
            FaceEngine faceEngine = faceRecognition.create();
            MyRecognitionThread thread = new MyRecognitionThread(queue,faceEngine,appProperties);
            OpenCVFrameGrabber openCVFrameGrabber = new OpenCVFrameGrabber(0);
            openCVFrameGrabber.start();
            CanvasFrame canvas = new CanvasFrame("摄像头");
            canvas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            canvas.setAlwaysOnTop(true);
            while(true){
                if(!canvas.isDisplayable()){//窗口是否关闭
                    openCVFrameGrabber.stop();//停止抓取
                    System.exit(2);//退出
                    break;
                }
                Frame grab = openCVFrameGrabber.grab();
                Mat mat = converter.convertToMat(openCVFrameGrabber.grabFrame());
                BufferedImage bufferedImage = mat2BufImg(mat);
                ImageInfo imageInfo = ImageFactory.bufferedImage2ImageInfo(bufferedImage);
                List<FaceInfo> cur = faceRecognition.testing(imageInfo);
                refreshTrackId(cur,imageInfo,bufferedImage);
                for (int i = 0; i < queue.size(); i++) {
                    thread.run();
                }
                canvas.showImage(grab);//获取摄像头图像并放到窗口上显示， 这里的Frame frame=grabber.grab(); frame是一帧视频图像
//                Thread.sleep(200);//50毫秒刷新一次图像
            }
            thread.shutdown();
        }catch (Exception e){
            System.out.println(e);
        }
       
    }
    
    
    
    
    private void refreshTrackId(List<FaceInfo> ftFaceList,ImageInfo img,BufferedImage bufferedImage) throws InterruptedException {
        currentTrackIdList.clear();
        //每项预先填充-1
        for (int i = 0; i < ftFaceList.size(); i++) {
            currentTrackIdList.add(-1);
        }
        //前一次无人脸现在有人脸，填充新增TrackId
        if (formerTrackIdList.size() == 0) {
            for (int i = 0; i < ftFaceList.size(); i++) {
                currentTrackIdList.set(i, ++currentTrackId);
                queue.put(new MyFaceInfo().setFaceInfo(ftFaceList.get(i))
                  .setImageInfo(img).setFaceId(currentTrackIdList.get(i)).setBufferedImage(bufferedImage));
            }
        }
        else {
            //前后都有人脸,对于每一个人脸框
            for (int i = 0; i < ftFaceList.size(); i++) {
                //遍历上一次人脸框
                int minDistance = Integer.MAX_VALUE;
                int minDistanceIndex = -1;
                for (int j = 0; j < formerFaceRectList.size(); j++) {
                    //获取最近的人脸框距离以及人脸框下标
                    int distance = getDistance(formerFaceRectList.get(j).getRect(), ftFaceList.get(i).getRect());
                    if (distance < minDistance) {
                        minDistance = distance;
                        minDistanceIndex = j;
                    }
                }
                //若这两个Rect距离小于两者最大人脸框宽度的1/4，认为是同一个人脸
                if (minDistanceIndex != -1 && minDistance < (
                        Math.max(ftFaceList.get(i).getRect().getRight()-ftFaceList.get(i).getRect().getLeft()
                                , formerFaceRectList.get(minDistanceIndex).getRect().getRight()- formerFaceRectList.get(minDistanceIndex).getRect().getLeft() ) >> 2)) {
                    currentTrackIdList.set(i, formerTrackIdList.get(minDistanceIndex));
                }
            }
        }
        //上一次人脸框不存在此人脸，增加trackID并分配
        for (int i = 0; i < currentTrackIdList.size(); i++) {
            if (currentTrackIdList.get(i) == -1) {
                currentTrackIdList.set(i, ++currentTrackId);
                queue.put(new MyFaceInfo().setFaceInfo(ftFaceList.get(i))
                        .setImageInfo(img).setFaceId(currentTrackIdList.get(i)).setBufferedImage(bufferedImage));
            }
        }
        formerTrackIdList.clear();
        formerFaceRectList.clear();
        for (int i = 0; i < ftFaceList.size(); i++) {
            formerFaceRectList.add(ftFaceList.get(i));
            formerTrackIdList.add(currentTrackIdList.get(i));
        }
    }
    
    private  int getDistance(Rect rect1, Rect rect2) {
        int r1Cx = (rect1.getLeft() + rect1.getRight())/2;
        int r1Cy = (rect1.getBottom() + rect1.getTop())/2;
        int r2Cx = (rect2.getLeft() + rect2.getRight())/2;
        int r2Cy = (rect2.getBottom() + rect2.getTop())/2;
        return (int) Math.sqrt(Math.pow(r1Cy - r2Cy, 2) + Math.pow(r1Cx - r2Cx, 2));
    }
    
    public  BufferedImage mat2BufImg (Mat matrix) {
//        Mat tempMat=new Mat();
//        cvtColor(matrix,tempMat,COLOR_BGRA2RGBA);//先要转bgra->rgba
        OpenCVFrameConverter.ToMat openCVConverter = new OpenCVFrameConverter.ToMat();
        Java2DFrameConverter java2DConverter = new Java2DFrameConverter();
        return java2DConverter.convert(openCVConverter.convert(matrix));
    }
    
    
    public String register(AppProperties appProperties){
        HashMap<String, Object> paramMap = new HashMap<>();
        paramMap.put("equipmentLocation", appProperties.getEquipmentLocation());
        paramMap.put("equipmentSoftwareVersion",appProperties.getEquipmentSoftwareVersion());
        try {
            paramMap.put("equipmentIp",InetAddress.getLocalHost());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        paramMap.put("equipmentStatus",0);
        String url = "http://localhost:8222/cs/equipment/insert";
        String json = JSONObject.toJSONString(paramMap);
        String post = HttpRequest.post(url)
                .header("Content-Type", "application/json;charset=UTF-8")
                .body(json)
                .execute().body();
        JSONObject jsonObject = JSONObject.parseObject(post);
        Object data = jsonObject.get("data");
        JSONObject object = JSONObject.parseObject(JSONObject.toJSONString(data));
        Object result = object.get("result");
        object = JSONObject.parseObject(JSONObject.toJSONString(result));
        String equipmentId =(String) object.get("equipmentId");
        
        return equipmentId;
    }
    public void heartbeatDetection(String id){
       String url = "http://localhost:8222/cs/equipment/heartbeat?equipmentId="+id;
        
    
        java.util.Timer timer = new java.util.Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                String get = HttpRequest.get(url)
                        .header("Content-Type", "application/json;charset=UTF-8")
                        .execute().body();
            }
        }, 1000, 2000);
    }
    
    public void deleteImage(AppProperties appProperties){
        java.util.Timer timer = new java.util.Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                File file = new File(appProperties.getImagePath());
                if(file.exists()){
                    String[] list = file.list();
                    for (String s : list) {
                        new File(file,s).delete();
                    }
                    file.delete();
                }
            }
        }, 1000*60*60*24, 1000*60*60*24);
    }
}

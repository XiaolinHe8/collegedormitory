package ncu.hxl.common.myEnum;


public interface ErrorCode {


     Integer getCode();

     String getDesc();

     String getDescCN();

}

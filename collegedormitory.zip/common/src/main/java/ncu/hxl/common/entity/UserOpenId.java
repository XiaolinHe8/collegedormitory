package ncu.hxl.common.entity;

import lombok.Data;

import java.util.List;

//{
//        "total":2,
//        "count":2,
//        "data":{
//        "openid":["OPENID1","OPENID2"]},
//        "next_openid":"NEXT_OPENID"
//        }
@Data
public class UserOpenId {
    private Integer total;
    private Integer count;
    private UserOpenIdData data;
    private String next_openid;
    
    
    @Data
    public class UserOpenIdData{
        private List<String> openid;
    }
}

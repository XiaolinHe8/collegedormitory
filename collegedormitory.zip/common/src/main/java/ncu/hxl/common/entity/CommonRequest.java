package ncu.hxl.common.entity;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class CommonRequest<T> {
    MultipartFile file;
    T data;
}

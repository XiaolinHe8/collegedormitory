package ncu.hxl.common.util;

import cn.hutool.core.util.IdUtil;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.common.myEnum.ErrorCodeEnum;
import ncu.hxl.common.rpc.BusinessException;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageUtil {
    public static CommonResult isLegalImage(MultipartFile file,Integer size){
        try {
            if(file.isEmpty()) {
                return CommonResult.error().setMessage("请正确上传图片");
            }
            //检查文件大小
            if(file.getSize() > size) {
                return CommonResult.error().setMessage("请上传"+size/1024.0/1024.0+"M以内的图片");
            }
            //检查是否是图片
            BufferedImage bi = ImageIO.read(file.getInputStream());
            if(bi == null){
                return CommonResult.error().setMessage("上传的文件不是图片");
            }
        } catch (IOException e) {
            throw new BusinessException(ErrorCodeEnum.FAIL,"请按照规定上传图片");
        }
        return CommonResult.ok();
    }
    
    public static void deleteImage(String photoPath){
        File origin = new File(photoPath);
            if(origin.exists()) {
                origin.delete();
            }
    }
    
    public static String insertImage(MultipartFile file,String photoPath){
        String result = null;
        String fileName =  IdUtil.simpleUUID();
        File mkdir = new File(photoPath);
        if (!mkdir.exists()) {
            mkdir.mkdirs();
        }
        String originalFileName = file.getOriginalFilename();
        File photo = new File(mkdir, fileName+originalFileName.substring(originalFileName.lastIndexOf(".")));
        try {
            file.transferTo(photo);
        } catch (IOException e) {
            throw new BusinessException(ErrorCodeEnum.FAIL,"图片保存错误");
        }
        result = photo.getAbsolutePath();
        return result;
    }
}

package ncu.hxl.common.util;



import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ncu.hxl.common.entity.DataEntity;
import ncu.hxl.common.entity.UserOpenId;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class WXUtil {
    
    public static String getToken(){
        //授予形式
        String grant_type = "client_credential";
        String appid = "wx285d149423f04ddb";
        String secret = "206330038457fe00acba294691ce6c83";
        //接口地址拼接参数
        String path = "https://api.weixin.qq.com/cgi-bin/token?grant_type="+grant_type+"&appid="+appid+"&secret="+secret;
        JSONObject tokenJson = JSONObject.parseObject(HttpUtil.get(path));
//        System.out.println(tokenJson+"==================");
        String token = tokenJson.get("access_token").toString();
        
        return token;
    }
    
    public static UserOpenId getUser(String token,String nextOpenId){
        if(token == null || "".equals(token))
            return null;
        String path = "https://api.weixin.qq.com/cgi-bin/user/get?access_token="+token;
        if(nextOpenId != null && !"".equals(nextOpenId))
            path+="&"+"next_openid="+nextOpenId;
        String result = HttpUtil.get(path);
        try {
            return new ObjectMapper().readValue(result, UserOpenId.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    
    /***
     * 发送消息
     * @param token
     */
    public static void SendWeChatMsg(String token,String toUser,String templateId,String toUrl,Map<String,Object> data){
        //接口地址
        String path = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token="+token;
        
        //整体参数map
        Map<String, Object> paramMap = new HashMap<String, Object>();
        //点击消息跳转相关参数map
        Map<String, String> miniprogramMap = new HashMap<String, String>();
        
        miniprogramMap.put("appid","");
        miniprogramMap.put("pagepath","");
        
        
        paramMap.put("touser", toUser);
        paramMap.put("template_id", templateId);
        paramMap.put("url", toUrl);
        paramMap.put("miniprogram", miniprogramMap);
        paramMap.put("data", data);
        String jsonString = JSONObject.toJSONString(paramMap);
        System.out.println("================"+jsonString);
        String post = HttpUtil.post(path, jsonString);
        System.out.println("======================Wechat============"+post);
    
    }
    
    public static String createMenu(String token){
        String path = " https://api.weixin.qq.com/cgi-bin/menu/create?access_token="+token;
        String json=" {\n" +
                "     \"button\":[\n" +
                "     {\t\n" +
                "          \"type\":\"click\",\n" +
                "          \"name\":\"今日歌曲\",\n" +
                "          \"key\":\"V1001_TODAY_MUSIC\"\n" +
                "      },\n" +
                "      {\n" +
                "           \"name\":\"菜单\",\n" +
                "           \"sub_button\":[\n" +
                "           {\t\n" +
                "               \"type\":\"view\",\n" +
                "               \"name\":\"搜索\",\n" +
                "               \"url\":\"http://www.soso.com/\"\n" +
                "            },\n" +
                "            {\n" +
                "               \"type\":\"click\",\n" +
                "               \"name\":\"赞一下我们\",\n" +
                "               \"key\":\"V1001_GOOD\"\n" +
                "            }]\n" +
                "       }]\n" +
                " }";
        return HttpUtil.post(path,json);
    }
    
    public static String createQRCode(String token,String sceneId,Integer time){
        String path = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token="+token;
        if(time == null)
             time = 604800;
        String json="{\"expire_seconds\":"+ time+", \"action_name\": \"QR_STR_SCENE\", \"action_info\": {\"scene\": {\"scene_str\": \""+sceneId+"\"}}}";
        JSONObject jsonObject = JSONObject.parseObject(HttpUtil.post(path, json));
        String ticket =(String) jsonObject.get("ticket");
        if(ticket== null || "".equals(ticket))
            return null;
        try {
            String QRCodePath = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket="+ URLEncoder.encode(ticket,"UTF-8");
            return QRCodePath;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return  null;
    }
    
   
    
}

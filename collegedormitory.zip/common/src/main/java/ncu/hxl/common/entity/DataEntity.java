package ncu.hxl.common.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class DataEntity<T> {
    private List<T> value;
    private String color;
}

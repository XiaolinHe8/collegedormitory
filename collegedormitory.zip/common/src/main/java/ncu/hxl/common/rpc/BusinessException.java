package ncu.hxl.common.rpc;

import lombok.Data;
import ncu.hxl.common.myEnum.ErrorCode;


@Data
public class BusinessException extends RuntimeException {
    private ErrorCode errorCode;
    private String msg;
    private String msgCN;
    

    public BusinessException(ErrorCode errorCode) {
        super(errorCode.getDesc());
        this.errorCode = errorCode;
        this.msg= errorCode.getDesc();
        this.msgCN=errorCode.getDescCN();
    }

    public BusinessException(ErrorCode errorCode, String msg) {
        super(errorCode.getDesc());
        this.errorCode = errorCode;
        this.msg = msg;
        this.msgCN=msg;
    }

    public BusinessException(Throwable cause, ErrorCode errorCode) {
        super(cause);
        this.errorCode = errorCode;
        this.msg= errorCode.getDesc();
        this.msgCN=errorCode.getDescCN();
    }


    public BusinessException(Throwable cause, ErrorCode errorCode, String msg) {
        super(cause);
        this.errorCode = errorCode;
        this.msg = msg;
        this.msgCN=msg;
    }
    
}

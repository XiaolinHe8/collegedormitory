package ncu.hxl.faceRecognition.been;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

@Data
@Accessors(chain = true)
public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @TableId
    private String userId;
    private String username;
    private String password;
    private String userCollege;
    private String userClass;
    private String photoPath;
    private String photoPath1;
    private byte[] faceFeature;
    private Integer sex;
    private Integer type;
    private Date effectiveTime;
    @TableField(fill = FieldFill.INSERT)
    private Date createDate;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifiedDate;
    
    
    @TableField(exist = false)
    private Float similar;
    
}

package ncu.hxl.faceRecognition.controller;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import lombok.AllArgsConstructor;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognition.been.Face;
import ncu.hxl.faceRecognition.been.User;
import ncu.hxl.faceRecognition.configuration.AppProperties;
import ncu.hxl.faceRecognition.myHandler.FaceRecognitionFallback;
import ncu.hxl.faceRecognition.myHandler.FaceRecognitionHandler;
import ncu.hxl.faceRecognition.server.impl.FaceEngineServiceImpl;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;


@RestController
@RefreshScope
@AllArgsConstructor
public class FaceRecognitionController {
    
    private FaceEngineServiceImpl faceEngineService;
    private AppProperties appProperties;
    
    
    @PostMapping("/faceRecognition/select")
    @SentinelResource(value = "select",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "select",fallbackClass = FaceRecognitionFallback.class,fallback = "select")
    public CommonResult select(String param,Integer type){
        if(type == null)
            return CommonResult.error().message("请输入查询类型");
        CommonResult commonResult = CommonResult.ok();
        if(type == 1){
            commonResult = faceEngineService.selectById(param);
        }
        if(type == 2) {
            commonResult = faceEngineService.selectByType(param);
        }
        if(type == 3) {
            commonResult = faceEngineService.selectAll();
        }
        return commonResult;
    }
    
    @GetMapping("/faceRecognition/delete/{userId}")
    @SentinelResource(value = "delete",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "delete",fallbackClass = FaceRecognitionFallback.class,fallback = "delete")
    public CommonResult delete(@PathVariable("userId") String userId){
        return faceEngineService.delete(userId);
    }
    
    
    @PostMapping(value = "/faceRecognition/register/{userId}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @SentinelResource(value = "register",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "register",fallbackClass = FaceRecognitionFallback.class,fallback = "register")
    public CommonResult register(@RequestPart("file") MultipartFile file,@PathVariable("userId") String userId){
        User user = new User();
        user.setUserId(userId);
        CommonResult commonResult = faceEngineService.saveFaceFeature(file, user);
        return commonResult;
    }
    
    
    
    @PostMapping("/faceRecognition/testing")
    @SentinelResource(value = "testing",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "testing",fallbackClass = FaceRecognitionFallback.class,fallback = "testing")
    public CommonResult testing(@RequestBody Face face){
        CommonResult result =CommonResult.ok();
        User userInfo = faceEngineService.IDRecognition(face.getFaceFeature());
        result.data("userInfo",userInfo);
        return result;
    }
    

    
    
}

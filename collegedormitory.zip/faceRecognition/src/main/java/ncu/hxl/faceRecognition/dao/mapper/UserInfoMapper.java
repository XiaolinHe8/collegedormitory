package ncu.hxl.faceRecognition.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.faceRecognition.been.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserInfoMapper extends BaseMapper<User> {
}

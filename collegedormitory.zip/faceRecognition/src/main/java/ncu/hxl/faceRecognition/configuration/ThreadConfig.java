package ncu.hxl.faceRecognition.configuration;

import com.arcsoft.face.EngineConfiguration;
import com.arcsoft.face.FaceEngine;
import com.arcsoft.face.FunctionConfiguration;
import com.arcsoft.face.enums.DetectMode;
import com.arcsoft.face.enums.DetectOrient;
import lombok.RequiredArgsConstructor;
import ncu.hxl.faceRecognition.Factory.FaceEngineFactory;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.time.Duration;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
@RequiredArgsConstructor
public class ThreadConfig {
//    @Value("${config.arcface-sdk.sdk-lib-path}")
//    public String sdkLibPath;
//    @Value("${config.arcface-sdk.app-id}")
//    public String appId;
//
//    @Value("${config.arcface-sdk.sdk-key}")
//    public String sdkKey;
//
//    @Value("${config.arcface-sdk.detect-pool-size}")
//    public Integer detectPooSize = 6;
//
//    @Value("${config.arcface-sdk.compare-pool-size}")
//    public Integer comparePoolSize = 5;
//
//    @Value("${config.arcface-sdk.compare-thread-size}")
//    public Integer compareThreadSize = 8;
    
    private final AppProperties appProperties;
    
    
    @Bean(name = "faceThreadExecutor")
    public TaskExecutor faceThreadExecutor(){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        // 设置核心线程数
        executor.setCorePoolSize(appProperties.getFaceRecognitionConfig().getCompareThreadSize());
        // 设置最大线程数
        executor.setMaxPoolSize(12);
        // 设置队列容量
        executor.setQueueCapacity(20);
        // 设置线程活跃时间（秒）
        executor.setKeepAliveSeconds(60);
        // 设置默认线程名称
        executor.setThreadNamePrefix("faceThread-");
        // 设置拒绝策略
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        // 等待所有任务结束后再关闭线程池
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.initialize();
        return executor;
    }
    
    @Bean(name="faceEngineGeneralPool")
    public GenericObjectPool<FaceEngine> faceEngineGeneralPool(){
        GenericObjectPoolConfig detectPoolConfig = new GenericObjectPoolConfig();
        detectPoolConfig.setMaxIdle(appProperties.getFaceRecognitionConfig().getDetectPoolSize());
        detectPoolConfig.setMaxTotal(appProperties.getFaceRecognitionConfig().getDetectPoolSize());
        detectPoolConfig.setMinIdle(appProperties.getFaceRecognitionConfig().getDetectPoolSize());
        detectPoolConfig.setMaxWait(Duration.ofSeconds(20));
        detectPoolConfig.setLifo(false);
        detectPoolConfig.setJmxEnabled(false);
        EngineConfiguration detectCfg = new EngineConfiguration();
        FunctionConfiguration detectFunctionCfg = new FunctionConfiguration();
        detectFunctionCfg.setSupportFaceDetect(true);//开启人脸检测功能
        detectFunctionCfg.setSupportFaceRecognition(true);//开启人脸识别功能
        detectCfg.setFunctionConfiguration(detectFunctionCfg);
        detectCfg.setDetectMode(DetectMode.ASF_DETECT_MODE_IMAGE);//图片检测模式，如果是连续帧的视频流图片，那么改成VIDEO模式
        detectCfg.setDetectFaceOrientPriority(DetectOrient.ASF_OP_0_ONLY);//人脸旋转角度
        return new GenericObjectPool(new FaceEngineFactory(appProperties.getFaceRecognitionConfig().getSdkPath(),
                appProperties.getFaceRecognitionConfig().getAppId(),
                appProperties.getFaceRecognitionConfig().getSdkKey(),
                null, detectCfg), detectPoolConfig);//底层库算法对象池
    }
    
    @Bean(name="faceEngineComparePool")
    public GenericObjectPool<FaceEngine> faceEngineComparePool(){
        GenericObjectPoolConfig comparePoolConfig = new GenericObjectPoolConfig();
        comparePoolConfig.setMaxIdle(appProperties.getFaceRecognitionConfig().getComparePoolSize());
        comparePoolConfig.setMaxTotal(appProperties.getFaceRecognitionConfig().getComparePoolSize());
        comparePoolConfig.setMinIdle(appProperties.getFaceRecognitionConfig().getComparePoolSize());
        comparePoolConfig.setMaxWait(Duration.ofSeconds(20));
        comparePoolConfig.setLifo(false);
        comparePoolConfig.setJmxEnabled(false);
        EngineConfiguration compareCfg = new EngineConfiguration();
        FunctionConfiguration compareFunctionCfg = new FunctionConfiguration();
        compareFunctionCfg.setSupportFaceRecognition(true);//开启人脸识别功能
        compareCfg.setFunctionConfiguration(compareFunctionCfg);
        compareCfg.setDetectMode(DetectMode.ASF_DETECT_MODE_VIDEO);//VIDEO模式
        compareCfg.setDetectFaceOrientPriority(DetectOrient.ASF_OP_0_ONLY);//人脸旋转角度
        return new GenericObjectPool(new FaceEngineFactory(appProperties.getFaceRecognitionConfig().getSdkPath(),
                appProperties.getFaceRecognitionConfig().getAppId(),
                appProperties.getFaceRecognitionConfig().getSdkKey(),
                null, compareCfg), comparePoolConfig);//底层库算法对象池
    }
    
    
    
}

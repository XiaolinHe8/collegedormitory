package ncu.hxl.faceRecognition.server;


import com.arcsoft.face.FaceInfo;
import com.arcsoft.face.toolkit.ImageInfo;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognition.been.User;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


public interface FaceEngineService {

    List<FaceInfo> detectFaces(ImageInfo imageInfo);
    

    byte[] extractFaceFeature(ImageInfo imageInfo,FaceInfo faceInfo);
    
    User IDRecognition(byte[] faceFeature);
    List<User> faceRecognition(byte[] faceFeature, List<User> userInfoList, float passRate);
    
    CommonResult saveFaceFeature(MultipartFile file, User userInfo);
    
    CommonResult delete(String userId);
    
    CommonResult selectById(String userId);
    
    CommonResult selectByType(String type);
    
    CommonResult selectAll();




}

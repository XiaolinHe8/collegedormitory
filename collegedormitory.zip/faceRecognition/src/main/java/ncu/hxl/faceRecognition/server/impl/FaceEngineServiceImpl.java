package ncu.hxl.faceRecognition.server.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.convert.Convert;
import cn.hutool.core.util.IdUtil;
import com.arcsoft.face.*;
import com.arcsoft.face.toolkit.ImageFactory;
import com.arcsoft.face.toolkit.ImageInfo;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognition.been.User;
import ncu.hxl.common.myEnum.ErrorCodeEnum;
import ncu.hxl.common.rpc.BusinessException;
import ncu.hxl.common.util.RedisUtil;
import ncu.hxl.faceRecognition.configuration.AppProperties;
import ncu.hxl.faceRecognition.dao.mapper.UserInfoMapper;
import ncu.hxl.faceRecognition.server.FaceEngineService;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;


@Service
@Slf4j
public class FaceEngineServiceImpl implements FaceEngineService {

    public final static Logger logger = LoggerFactory.getLogger(FaceEngineServiceImpl.class);
    
    private AppProperties appProperties;
    
    private  String redisKey = "faceList";
    
    private UserInfoMapper userInfoMapper;
    
    private TaskExecutor faceThreadExecutor;
    
    //通用人脸识别引擎池,用于人脸注册
    private GenericObjectPool<FaceEngine> faceEngineGeneralPool;
    
    //人脸比对引擎池，用于人脸识别
    private GenericObjectPool<FaceEngine> faceEngineComparePool;

    private RedisUtil myRedisUtil;
    
    
    
    
    public FaceEngineServiceImpl(AppProperties appProperties, UserInfoMapper userInfoMapper, TaskExecutor faceThreadExecutor, GenericObjectPool<FaceEngine> faceEngineGeneralPool, GenericObjectPool<FaceEngine> faceEngineComparePool, RedisUtil myRedisUtil) {
        this.appProperties = appProperties;
        this.userInfoMapper = userInfoMapper;
        this.faceThreadExecutor = faceThreadExecutor;
        this.faceEngineGeneralPool = faceEngineGeneralPool;
        this.faceEngineComparePool = faceEngineComparePool;
        this.myRedisUtil = myRedisUtil;
    }
    
    
    
    
    @Override
    public CommonResult delete(String userId) {
        User userInfo = userInfoMapper.selectById(userId);
        File file = new File(userInfo.getPhotoPath());
        if(file.exists()) file.delete();
        myRedisUtil.hdel(redisKey,userInfo);
        int i = userInfoMapper.deleteById(userId);
        return CommonResult.ok();
    }
    
    @Override
    public CommonResult selectById(String userId) {
        User userInfo = userInfoMapper.selectById(userId);
        return CommonResult.ok().data("userInfo",userInfo);
    }
    
    @Override
    public CommonResult selectByType(String type) {
        List<User> userInfos = userInfoMapper.selectList(new QueryWrapper<User>().eq("type", type));
        return CommonResult.ok().data("userInfo",userInfos);
    }
    
    @Override
    public CommonResult selectAll() {
        List<User> userInfos = userInfoMapper.selectList(null);
        return CommonResult.ok().data("userInfo",userInfos);
    }
    
    /**
    * @param file，UserInfo
    * 从证件照中提取人脸特征并保存到数据库中
     */
    @Override
    public CommonResult saveFaceFeature(MultipartFile file, User userInfo) {
        ImageInfo imageInfo = null;
        try {
            if(file.isEmpty()) {
                return CommonResult.error().setMessage("请正确上传图片");
            }
            //检查文件大小
            if(file.getSize() > appProperties.getFaceRecognitionConfig().getFileSize()) {
                return CommonResult.error().setMessage("请上传"+appProperties.getFaceRecognitionConfig().getFileSize()/1024.0/1024.0+"M以内的图片");
            }
            //检查是否是图片
            BufferedImage bi = ImageIO.read(file.getInputStream());
            if(bi == null){
                return CommonResult.error().setMessage("上传的文件不是图片");
            }
            imageInfo = ImageFactory.getRGBData(file.getBytes());
        } catch (IOException e) {
            throw new BusinessException(ErrorCodeEnum.FAIL,"请按照规定上传图片");
        }
        List<FaceInfo> faceInfos = detectFaces(imageInfo);
        if(faceInfos == null || faceInfos.size() != 1)
            return CommonResult.error().setMessage("请按照规定上传证件照");
        byte[] faceFeature = extractFaceFeature(imageInfo, faceInfos.get(0));
        if(faceFeature == null)
            return CommonResult.error().setMessage("请按照规定上传证件照");
        userInfo.setFaceFeature(faceFeature);
        if(userInfo.getPhotoPath() != null && !"".equals(userInfo.getPhotoPath())){
            File origin = new File(userInfo.getPhotoPath());
            if(origin.exists()){
                origin.delete();
            }
        }
        String fileName =  IdUtil.simpleUUID();
        File mkdir = new File(appProperties.getFaceRecognitionConfig().getImageSavePath());
        if (!mkdir.exists()) {
            mkdir.mkdirs();
        }
        String originalFileName = file.getOriginalFilename();
        File photo = new File(mkdir, fileName+originalFileName.substring(originalFileName.lastIndexOf(".")));
        userInfo.setPhotoPath(photo.getAbsolutePath());
        try {
            file.transferTo(photo);
        } catch (IOException e) {
            throw new BusinessException(ErrorCodeEnum.FAIL,"图片保存错误");
        }
        if(userInfo.getType() == null || userInfo.getType() < 0 && userInfo.getType()>2)
            userInfo.setType(0);
    
        String s = ChangePhotoPath(userInfo.getPhotoPath());
        userInfo.setPhotoPath1(s);
        userInfoMapper.updateById(userInfo);
        
        myRedisUtil.lSet(redisKey,userInfo,60*120);
        return CommonResult.ok().setMessage("上传图片成功").data(userInfo.getUserId(),userInfo);
    }
    
    
    
    
    /**
     * @param imageInfo
     * @return List
     * 从证件照中提取检测人脸列表
     */
    @Override
    public List<FaceInfo> detectFaces(ImageInfo imageInfo) {

        FaceEngine faceEngine = null;
        try {
            faceEngine = faceEngineGeneralPool.borrowObject();
            if (faceEngine == null) {
                throw new BusinessException(ErrorCodeEnum.FAIL, "获取引擎失败");
            }

            //人脸检测得到人脸列表
            List<FaceInfo> faceInfoList = new ArrayList<FaceInfo>();
            //人脸检测
            int errorCode = faceEngine.detectFaces(imageInfo.getImageData(), imageInfo.getWidth(), imageInfo.getHeight(), imageInfo.getImageFormat(), faceInfoList);
            if (errorCode == 0) {
                return faceInfoList;
            } else {
                log.error("人脸检测失败，errorCode：" + errorCode);
            }

        } catch (Exception e) {
            log.error("", e);
        } finally {
            if (faceEngine != null) {
                //释放引擎对象
                faceEngineGeneralPool.returnObject(faceEngine);
            }
        }

        return null;

    }



    /**
     * 获取人脸特征
     *
     * @param imageInfo
     * @return byte[]
     */
    @Override
    public byte[] extractFaceFeature(ImageInfo imageInfo, FaceInfo faceInfo) {

        FaceEngine faceEngine = null;
        try {
            faceEngine = faceEngineGeneralPool.borrowObject();
            if (faceEngine == null) {
                throw new BusinessException(ErrorCodeEnum.FAIL, "获取引擎失败");
            }

            FaceFeature faceFeature = new FaceFeature();
            //提取人脸特征
            int errorCode = faceEngine.extractFaceFeature(imageInfo.getImageData(), imageInfo.getWidth(), imageInfo.getHeight(), imageInfo.getImageFormat(), faceInfo, faceFeature);
            if (errorCode == 0) {
                return faceFeature.getFeatureData();
            } else {
                log.error("特征提取失败，errorCode：" + errorCode);
            }

        } catch (Exception e) {
            log.error("", e);
        } finally {
            if (faceEngine != null) {
                //释放引擎对象
                faceEngineGeneralPool.returnObject(faceEngine);
            }
        }

        return null;

    }
    
  
    
    
    public User IDRecognition(byte[] faceFeature){
        User result = null;
        List<User> userList = null;
        List<User> userInfos = null;
        List<Serializable> objects = myRedisUtil.lGet(redisKey, 0, -1);
        if(objects != null && !objects.isEmpty()){
            userList = Convert.toList(User.class,objects.toArray());
            userInfos = faceRecognition(faceFeature, userList, appProperties.getFaceRecognitionConfig().getPassRate());
        }
        else if(userInfos == null || userInfos.isEmpty()){
            userList = userInfoMapper.selectList(null);
            userInfos = faceRecognition(faceFeature, userList, appProperties.getFaceRecognitionConfig().getPassRate());
        }
        if(userInfos != null && !userInfos.isEmpty()){
            myRedisUtil.lSet(redisKey,userInfos.get(0),60*120);
            result = userInfos.get(0);
        }
        return result;
        
    }
    
    
    /**
     * 获取人脸特征比对
     *
     * @return List<UserInfo>
     */
    @Override
    public List<User> faceRecognition(byte[] faceFeature, List<User> userInfoList, float passRate) {
        List<User> resultUserInfoList = Lists.newLinkedList();//识别到的人脸列表

        FaceFeature targetFaceFeature = new FaceFeature();
        targetFaceFeature.setFeatureData(faceFeature);

        List<List<User>> faceUserInfoPartList = Lists.partition(userInfoList, 1000);//分成1000一组，多线程处理
        CompletionService<List<User>> completionService = new ExecutorCompletionService(faceThreadExecutor);
        for (List<User> part : faceUserInfoPartList) {
            completionService.submit(new CompareFaceTask(part, targetFaceFeature, passRate));
        }
        for (int i = 0; i < faceUserInfoPartList.size(); i++) {
            List<User> faceUserInfoList = null;
            try {
                faceUserInfoList = completionService.take().get();
               
            } catch (InterruptedException | ExecutionException e) {
            }
            if (CollectionUtil.isNotEmpty(faceUserInfoList)) {
                resultUserInfoList.addAll(faceUserInfoList);
                
            }
        }
        resultUserInfoList.sort((h1, h2) -> h2.getSimilar().compareTo(h1.getSimilar()));//从大到小排序
        return resultUserInfoList;
    }





    private class CompareFaceTask implements Callable<List<User>> {

        private List<User> userInfoList;
        private FaceFeature targetFaceFeature;
        private float passRate;


        public CompareFaceTask(List<User> userInfoList, FaceFeature targetFaceFeature, float passRate) {
            this.userInfoList = userInfoList;
            this.targetFaceFeature = targetFaceFeature;
            this.passRate = passRate;
        }

        @Override
        public List<User> call() throws Exception {
            FaceEngine faceEngine = null;
            List<User> resultUserInfoList = Lists.newLinkedList();//识别到的人脸列表
            try {
                faceEngine = faceEngineComparePool.borrowObject();
                for (User userInfo : userInfoList) {
                    FaceFeature sourceFaceFeature = new FaceFeature();
                    sourceFaceFeature.setFeatureData(userInfo.getFaceFeature());
                    FaceSimilar faceSimilar = new FaceSimilar();
                    faceEngine.compareFaceFeature(targetFaceFeature, sourceFaceFeature, faceSimilar);
                    
                    if (faceSimilar.getScore() > passRate) {//相似值大于配置预期，加入到识别到人脸的列表
                        userInfo.setSimilar(faceSimilar.getScore());
                        resultUserInfoList.add(userInfo);
                    }
                }
            } catch (Exception e) {
                logger.error("", e);
            } finally {
                if (faceEngine != null) {
                    faceEngineComparePool.returnObject(faceEngine);
                }
            }

            return resultUserInfoList;
        }

    }
    
    private String ChangePhotoPath(String origin){
        AppProperties.FaceRecognitionConfig config = appProperties.getFaceRecognitionConfig();
        if(origin == null || "".equals(origin))
            return null;
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = requestAttributes.getRequest();
        String localAddr = request.getLocalAddr();
        int serverPort = request.getServerPort();
        File file = new File(origin);
        String name = file.getName();
        return  "http://"+localAddr +":"+serverPort+ config.getSelectImage()+"/"+name;
    }
}

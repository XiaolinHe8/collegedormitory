package ncu.hxl.faceRecognition.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "face-recognition-config")
public class AppProperties {

    @Setter
    @Getter
    private FaceRecognitionConfig faceRecognitionConfig = new FaceRecognitionConfig();
    @Getter
    @Setter
    public static class FaceRecognitionConfig{
        private String sdkPath = "E:/arcsoft_lib";
        private String appId = "GNuMURUPPoiJiaPZpSZd7V3Kz6gtF9Yf2tSzqtj2zt5o";
        private String sdkKey = "hHrxM8qqp9ts3HhiwTTxmvFE1QamgJaGHUEmVEqQ1Lc";
        private Integer detectPoolSize = 5;
        private Integer comparePoolSize = 6;
        private Integer compareThreadSize = 8;
        private float PassRate = 0.82f;
        private Long fileSize = 2097152L;
        private String imageSavePath = "F:/image";
        private String selectImage="/photo";
        
    }
}

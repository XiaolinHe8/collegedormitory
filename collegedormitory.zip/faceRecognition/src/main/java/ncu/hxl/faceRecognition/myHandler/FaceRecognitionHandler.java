package ncu.hxl.faceRecognition.myHandler;


import com.alibaba.csp.sentinel.slots.block.BlockException;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognition.been.Face;
import org.springframework.web.multipart.MultipartFile;

public class FaceRecognitionHandler {
    
    public static CommonResult select(String param, Integer type, BlockException blockException){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult delete( String userId, BlockException blockException){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult register(MultipartFile file, String userId, BlockException blockException){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult testing(Face face, BlockException blockException){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
}

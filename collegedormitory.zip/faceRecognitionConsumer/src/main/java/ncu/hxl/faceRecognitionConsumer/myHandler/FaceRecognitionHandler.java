package ncu.hxl.faceRecognitionConsumer.myHandler;

import com.alibaba.csp.sentinel.slots.block.BlockException;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognitionConsumer.been.UserInfo;

public class FaceRecognitionHandler {
    
    public static CommonResult register(BlockException blockException){
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(900);
    
    }
    public static CommonResult testing(BlockException blockException){
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(900);
    }
    public static CommonResult test(BlockException blockException){
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(900);
    }
}

package ncu.hxl.faceRecognitionConsumer.service.impl;

import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognitionConsumer.been.UserInfo;
import ncu.hxl.faceRecognitionConsumer.service.FaceRecognitionService;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FaceRecognitionServiceImpl implements FaceRecognitionService {
    @Override
    public CommonResult register(MultipartFile file, UserInfo userInfo) {
        return  CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(801);
    }
    
    @Override
    public CommonResult testing(byte[] faceFeature) {
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(801);
    }
    
    @Override
    public CommonResult test(UserInfo userInfo) {
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(801);
    }
}

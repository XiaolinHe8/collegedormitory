package ncu.hxl.faceRecognitionConsumer.service;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognitionConsumer.been.UserInfo;
import ncu.hxl.faceRecognitionConsumer.service.impl.FaceRecognitionServiceImpl;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@FeignClient(value = "face-recognition",fallback = FaceRecognitionServiceImpl.class)
public interface FaceRecognitionService {
    @PostMapping("/faceRecognition/register")
    public CommonResult register(MultipartFile file, UserInfo userInfo);
    
    @PostMapping("/faceRecognition/testing")
    public CommonResult testing(@RequestParam(name = "faceFeature") byte[] faceFeature);
   
   
    @PostMapping("/faceRecognition/test")
    public CommonResult test(@RequestBody UserInfo userInfo);
}

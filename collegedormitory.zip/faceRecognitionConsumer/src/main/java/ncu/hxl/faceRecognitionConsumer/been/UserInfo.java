package ncu.hxl.faceRecognitionConsumer.been;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

@Data
@Accessors(chain = true)
public class UserInfo implements Serializable {
    private String userId;
    private String userName;
    private String userMajor;
    private String userCollege;
    private String userClass;
    private String photoPath;
    private String faceId;
    private byte[] faceFeature;
    private Date createTime;
    private Date updateTime;
    private Integer sex;
    
    private Float similar;
    
}

package ncu.hxl.faceRecognitionConsumer.contoller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognitionConsumer.been.UserInfo;
import ncu.hxl.faceRecognitionConsumer.myHandler.FaceRecognitionFallback;
import ncu.hxl.faceRecognitionConsumer.myHandler.FaceRecognitionHandler;
import ncu.hxl.faceRecognitionConsumer.service.FaceRecognitionService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;


@RestController
public class FaceRecognitionConsumerController {
    @Resource
    private FaceRecognitionService faceRecognitionService;
    
    @PostMapping("/faceRecognition/register")
    @SentinelResource(value = "register",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "register",fallbackClass = FaceRecognitionFallback.class,fallback = "register")
    public CommonResult register(MultipartFile file, UserInfo userInfo){
        return faceRecognitionService.register(file,userInfo);
    }
    
    @PostMapping("/faceRecognition/register1")
    @SentinelResource(value = "register",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "register",fallbackClass = FaceRecognitionFallback.class,fallback = "register")
    public CommonResult register1( MultipartFile file, UserInfo userInfo){
        return faceRecognitionService.register(file,userInfo);
    }
    
    @PostMapping("/faceRecognition/testing")
    @SentinelResource(value = "testing",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "testing",fallbackClass = FaceRecognitionFallback.class,fallback = "testing")
    public CommonResult testing(@RequestParam(name = "faceFeature") byte[] faceFeature){
        return faceRecognitionService.testing(faceFeature);
    }
    
    @SentinelResource(value = "test",blockHandlerClass = FaceRecognitionHandler.class,
            blockHandler = "test",fallbackClass = FaceRecognitionFallback.class,fallback = "test")
    @GetMapping("/faceRecognition/test")
    public CommonResult test(UserInfo userInfo){
        System.out.println(userInfo);
        return  faceRecognitionService.test(userInfo);
    }
    
}

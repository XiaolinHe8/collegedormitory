package ncu.hxl.faceRecognitionConsumer.myHandler;

import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.faceRecognitionConsumer.been.UserInfo;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

public class FaceRecognitionFallback {
    public CommonResult register(@RequestBody MultipartFile file, UserInfo userInfo){
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(900);
    }
    
    public CommonResult testing(@RequestParam(name = "faceFeature") byte[] faceFeature){
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(900);
    }
    public CommonResult test(UserInfo userInfo){
        return CommonResult.error().message("faceRecognitionConsumer服务器繁忙，请稍后再试").setCode(900);
    }
}

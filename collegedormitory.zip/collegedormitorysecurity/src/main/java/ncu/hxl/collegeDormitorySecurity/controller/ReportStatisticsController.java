package ncu.hxl.collegeDormitorySecurity.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.fastjson.JSON;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.entity.record.AccessRecord;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.collegeDormitorySecurity.service.PermissionService;
import ncu.hxl.collegeDormitorySecurity.service.UserService;
import ncu.hxl.collegeDormitorySecurity.service.reportStatistics.ReportStatisticsService;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.*;

@AllArgsConstructor
@RestController
@RequestMapping("/cs")
public class ReportStatisticsController {
    private ReportStatisticsService reportStatisticsService;
    private UserService userService;
    private RedisTemplate<String, Serializable> redisTemplate;
    private PermissionService permissionService;
    @PostMapping(value = "access/inAndOut",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "inAndOut",fallbackClass = FaceRecognitionFallback.class,
            fallback = "inAndOut")
    public CommonResult inAndOut(
            @RequestParam("userId") String userId,
            @RequestParam("equipmentId")String equipmentId,
            @RequestParam("file") MultipartFile file,
            @RequestParam("in")Boolean in,
            @RequestParam("type")Integer type){
        CommonResult commonResult = reportStatisticsService.inAndOut(userId, equipmentId, file, in, type);
        return commonResult;
    }
    @GetMapping("/access/selectRecord")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectRecord",fallbackClass = FaceRecognitionFallback.class,
            fallback = "selectRecord")
    public CommonResult selectRecord(@RequestParam(value = "userId") String userId
            , @RequestParam(value = "type")Integer type,
                                     @RequestParam(value = "date") @DateTimeFormat(pattern="yyyy-MM-dd") Date  date){
        
        CommonResult commonResult = reportStatisticsService.selectRecord(userId, type, date);
        if(commonResult.getCode() == 1000 && !commonResult.getSuccess())
            return commonResult;
        String string = JSON.toJSONString(commonResult.getData().get("access_record"));
        List<AccessRecord> access_record = JSON.parseArray(string, AccessRecord.class);
        for (int i = 0; i < access_record.size(); i++) {
            User user = userService.getById(access_record.get(i).getArUserId());
            if(user != null)
               access_record.get(i).setUsername(user.getUsername())
                       .setUserClass(user.getUserClass()).setCollege(user.getUserCollege());
        }
       
        dataMaster(access_record);
      
       return commonResult.data("access_record",access_record);
    };
    
    @GetMapping("/access/selectAccessAfter11")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectAccessAfter11",fallbackClass = FaceRecognitionFallback.class,
            fallback = "selectAccessAfter11")
    public CommonResult selectAccessAfter11(@RequestParam(value = "date") @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        CommonResult commonResult = reportStatisticsService.selectAccessAfter11(date);
        if(commonResult.getCode() == 1000 && !commonResult.getSuccess())
            return commonResult;
        String string = JSON.toJSONString(commonResult.getData().get("accessRecords"));
        List<AccessRecord> access_record = JSON.parseArray(string, AccessRecord.class);
        for (int i = 0; i < access_record.size(); i++) {
            User user = userService.getById(access_record.get(i).getArUserId());
            if(user != null)
                access_record.get(i).setUsername(user.getUsername())
                        .setUserClass(user.getUserClass()).setCollege(user.getUserCollege());
        }
        
        dataMaster(access_record);
        return commonResult.data("accessRecords",access_record);
    }
    
    @GetMapping("/access/selectNoAccess")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectNoAccess",fallbackClass = FaceRecognitionFallback.class,
            fallback = "selectNoAccess")
    public CommonResult selectNoAccess(@RequestParam(value = "date") @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        CommonResult commonResult = reportStatisticsService.selectNoAccess(date);
        if(commonResult.getCode() == 1000 && !commonResult.getSuccess())
            return commonResult;
        List<String> access_record =(List<String>)commonResult.getData().get("notReturned");
        ArrayList<AccessRecord> accessRecords1 = new ArrayList<>(access_record.size());
        for (int i = 0; i < access_record.size(); i++) {
            User user = userService.getById(access_record.get(i));
            if(user != null)
                accessRecords1.add(new AccessRecord().setUsername(user.getUsername())
                        .setUserClass(user.getUserClass())
                        .setArUserId(user.getUserId())
                        .setCollege(user.getUserCollege()));
        }
        dataMaster(accessRecords1);
        List<String> access_record1 =(List<String>)commonResult.getData().get("notOut");
        ArrayList<AccessRecord> accessRecords2 = new ArrayList<>(access_record1.size());
        for (int i = 0; i < access_record1.size(); i++) {
            User user = userService.getById(access_record1.get(i));
            if(user != null)
                accessRecords2.add(new AccessRecord().setUsername(user.getUsername())
                        .setUserClass(user.getUserClass())
                        .setArUserId(user.getUserId())
                        .setCollege(user.getUserCollege()));
        }
        dataMaster(accessRecords2);
        List<String> strings =(List<String>)commonResult.getData().get("noData");

        ArrayList<AccessRecord> accessRecords = new ArrayList<>(strings.size());
        for (int i = 0; i < strings.size(); i++) {
            User user = userService.getById(strings.get(i));
            if(user != null)
                accessRecords.add(new AccessRecord().setUsername(user.getUsername())
                   .setUserClass(user.getUserClass())
           .setArUserId(user.getUserId())
                        .setCollege(user.getUserCollege()));
        }
        dataMaster(accessRecords);
        return commonResult.data("notOut",accessRecords2).data("notReturned",accessRecords1).data("noData",accessRecords);
    }
    
    @GetMapping("access/getQrCode")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "createRQCode",fallbackClass = FaceRecognitionFallback.class,
            fallback = "createRQCode")
    public CommonResult  createRQCode(){
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Integer permission = getPermission(username);
        return reportStatisticsService.createRQCode(username,permission);
    }
    
    @GetMapping("access/wx")
    public String  wx(@RequestParam("signature") String signature,
                      @RequestParam("timestamp") String timestamp,
                      @RequestParam("nonce") String nonce,
                      @RequestParam("echostr") String echostr){
        return reportStatisticsService.wx(signature,timestamp,nonce,echostr);
    }
    
    @PostMapping("access/wx")
    public String  wx(@RequestBody String msg){
        return reportStatisticsService.wx(msg);
    }
    
    private Integer getPermission(String username){
        int flag = 3;
        List<String> permissionValueList = (List<String>)redisTemplate.opsForValue().get(username);
      
        if(permissionValueList != null){
            for(String permissionValue : permissionValueList) {
                if("sys:data:headmaster".equals(permissionValue)){
                    flag = 0;
                }else if("sys:data:dean".equals(permissionValue)){
                    flag = 1;
                }else  if("sys:data:admin".equals(permissionValue)){
                    flag = 2;
                }
            }
        }
        return  flag;
    }
    
    private void dataMaster(List<AccessRecord> list){
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userService.getById(username);
        if(user != null){
            Iterator<AccessRecord> iterator = list.iterator();
            Integer permission = getPermission(username);
            while(iterator.hasNext()){
                AccessRecord next = iterator.next();
                if(permission == 0){
                    if(next.getUserClass().equals(user.getUserClass()))
                        iterator.remove();
                }
                if(permission == 1){
                    if(next.getCollege().equals(user.getUserCollege()))
                        iterator.remove();
                }
                if(permission == 3){
                    if(!next.getArUserId().equals(user.getUserId()) )
                        iterator.remove();
                }
            }
        }
    }
}

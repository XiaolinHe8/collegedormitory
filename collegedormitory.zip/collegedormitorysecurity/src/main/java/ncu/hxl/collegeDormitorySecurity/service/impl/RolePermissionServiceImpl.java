package ncu.hxl.collegeDormitorySecurity.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import ncu.hxl.collegeDormitorySecurity.entity.RolePermission;
import ncu.hxl.collegeDormitorySecurity.mapper.RolePermissionMapper;
import ncu.hxl.collegeDormitorySecurity.service.RolePermissionService;
import org.springframework.stereotype.Service;

@Service
public class RolePermissionServiceImpl extends ServiceImpl<RolePermissionMapper, RolePermission> implements RolePermissionService {

}

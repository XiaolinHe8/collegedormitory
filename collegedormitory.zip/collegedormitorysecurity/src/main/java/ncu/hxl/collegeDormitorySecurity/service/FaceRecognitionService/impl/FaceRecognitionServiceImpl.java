package ncu.hxl.collegeDormitorySecurity.service.FaceRecognitionService.impl;

import ncu.hxl.collegeDormitorySecurity.entity.FaceRecognition.Face;
import ncu.hxl.collegeDormitorySecurity.service.FaceRecognitionService.FaceRecognitionService;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FaceRecognitionServiceImpl implements FaceRecognitionService {
    @Override
    public CommonResult delete(String userId) {
        return  CommonResult.error().message("服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult register(MultipartFile file, String userId) {
        return  CommonResult.error().message("服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult testing( Face face) {
        return  CommonResult.error().message("服务繁忙，请稍后再试").setCode(1000);
    }
}

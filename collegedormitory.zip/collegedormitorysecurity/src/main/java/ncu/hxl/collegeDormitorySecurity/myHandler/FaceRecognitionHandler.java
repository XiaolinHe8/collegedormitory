package ncu.hxl.collegeDormitorySecurity.myHandler;



import com.alibaba.csp.sentinel.slots.block.BlockException;
import ncu.hxl.collegeDormitorySecurity.entity.FaceRecognition.Face;
import ncu.hxl.collegeDormitorySecurity.entity.ReceiveRolePermission;
import ncu.hxl.collegeDormitorySecurity.entity.Role;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.Equipment;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser1;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;


public class FaceRecognitionHandler {
    
    public static CommonResult insertEquipmentInfo(Equipment equipment, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    public static CommonResult getVerificationCode(String date, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    public static CommonResult index(Long page, Long limit, User userQueryVo, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult save(User user, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult delete(String[] userIds, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getUserTarget(BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getUserById(BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult save1(User user, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    public static CommonResult index(Long page, Long limit, String name, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getRole(BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getAllRole(BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult save(Role role, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    
    public static CommonResult inAndOut(String userId, String equipmentId, MultipartFile file, Boolean in, Integer type, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectRecord(String userId, Integer type, Date date, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectAccessAfter11(Date date, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectNoAccess(Date date, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult createRQCode(BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    
    public static CommonResult doAssign(ReceiveRolePermission receiveRolePermission, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult toAssign(String roleId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    
    public static CommonResult info(BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getMenu(Integer type, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    
    public static CommonResult delete(String userId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult register(MultipartFile file, String userId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult testing(String equipmentId, Face face, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult updateEquipmentInfo(Equipment equipment, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult deleteEquipmentInfo(String equipmentId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult selectEquipmentInfo(Long page, Long limit, String equipmentLocation, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult deleteEquipmentUserInfo(InsertUser insertUser, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult insertEquipmentUserInfo(InsertUser1 insertUser1, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult selectEquipmentUserInfo(String equipmentId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
}

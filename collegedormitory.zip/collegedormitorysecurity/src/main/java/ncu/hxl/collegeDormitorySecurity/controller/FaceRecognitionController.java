package ncu.hxl.collegeDormitorySecurity.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.fastjson.JSON;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.FaceRecognition.Face;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.EquipmentUserInfo;
import ncu.hxl.collegeDormitorySecurity.entity.record.AccessRecord;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.collegeDormitorySecurity.service.EquipmentService.EquipmentService;
import ncu.hxl.collegeDormitorySecurity.service.FaceRecognitionService.FaceRecognitionService;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/cs")
public class FaceRecognitionController {
    private FaceRecognitionService faceRecognitionService;
    private EquipmentService equipmentService;
    
    @GetMapping("/faceRecognition/delete/{userId}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "delete",fallbackClass = FaceRecognitionFallback.class,
            fallback = "delete")
    public CommonResult delete(@PathVariable("userId") String userId){
        return faceRecognitionService.delete(userId);
    }
    
    
    @PostMapping(value = "/faceRecognition/register/{userId}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "register"
            ,fallbackClass = FaceRecognitionFallback.class,fallback = "register")
    public CommonResult register(@RequestParam("file") MultipartFile file, @PathVariable("userId") String userId){
      
        return  faceRecognitionService.register(file,userId);
        
    }
    @PostMapping("/faceRecognition/testing")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "testing"
            ,fallbackClass = FaceRecognitionFallback.class,fallback = "testing")
    public CommonResult testing(@RequestParam("equipmentId")String equipmentId,@RequestBody Face face){
      
        int type = 0;
        CommonResult commonResult = faceRecognitionService.testing(face);
        if(commonResult.getCode() == 1000 && !commonResult.getSuccess())
            return commonResult;
        String user = JSON.toJSONString( commonResult.getData().get("userInfo"));
        User userInfo =  JSON.parseObject(user, User.class);
        if(userInfo == null )
            return commonResult.data("type",-1).data("userInfo",null);
        if(userInfo.getType() == 1){
            type = 1;//黑名单
            return  commonResult.data("type",type).data("userInfo",userInfo.getUserId());
        }
        else if(userInfo.getType() == 2){
            Date effectiveTime = userInfo.getEffectiveTime();
            if(effectiveTime.getTime() < new Date().getTime()){
                type = 2;//临时访客且时间过期
                return  commonResult.data("type",type).data("userInfo",userInfo.getUserId());
            }else type = 0;
        }
        CommonResult commonResult1 = equipmentService.selectEquipmentUserInfo(equipmentId);
        if(commonResult1.getCode() == 1000 && !commonResult1.getSuccess())
            return commonResult1;
        String string = JSON.toJSONString(commonResult1.getData().get("EquipmentUserInfo"));
        List<EquipmentUserInfo> equipmentUserInfo = JSON.parseArray(string, EquipmentUserInfo.class);
        if(equipmentUserInfo == null || equipmentUserInfo.size() == 0)
            return commonResult.data("type",3).data("userInfo",userInfo.getUserId());;
        type = 3;
        for (EquipmentUserInfo info : equipmentUserInfo) {
            if(info.getUserId().equals(userInfo.getUserId())){
                type = 0;
            }
        }
        commonResult.data("type",type).data("userInfo",userInfo.getUserId());;
      
        return commonResult;
    }
}

package ncu.hxl.collegeDormitorySecurity.service;

import com.baomidou.mybatisplus.extension.service.IService;
import ncu.hxl.collegeDormitorySecurity.entity.User;



public interface UserService extends IService<User> {

    // 从数据库中取出用户信息
    User selectByUsername(String username);
}

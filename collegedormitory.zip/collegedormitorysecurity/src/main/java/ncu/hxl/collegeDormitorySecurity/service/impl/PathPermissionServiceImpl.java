package ncu.hxl.collegeDormitorySecurity.service.impl;

import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import ncu.hxl.collegeDormitorySecurity.mapper.PathPermissionMapper;
import ncu.hxl.collegeDormitorySecurity.service.PathPermissionService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class PathPermissionServiceImpl implements PathPermissionService {
    private PathPermissionMapper pathPermissionMapper;
    @Override
    public List<Permission> selectPermissionByPath(String path) {
        List<Permission> permissions = pathPermissionMapper.selectPermissionByPath(path);
        return permissions;
    }
}

package ncu.hxl.collegeDormitorySecurity.service.FaceRecognitionService;

import ncu.hxl.collegeDormitorySecurity.entity.FaceRecognition.Face;
import ncu.hxl.collegeDormitorySecurity.service.FaceRecognitionService.impl.FaceRecognitionServiceImpl;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Component
@FeignClient(value = "face-recognition",fallback = FaceRecognitionServiceImpl.class)
public interface FaceRecognitionService {
    @GetMapping("/faceRecognition/delete/{userId}")
    public CommonResult delete(@PathVariable("userId") String userId);
    
    
    @PostMapping(value = "/faceRecognition/register/{userId}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public CommonResult register(@RequestPart("file") MultipartFile file, @PathVariable("userId") String userId);
    
    @PostMapping("/faceRecognition/testing")
    public CommonResult testing(@RequestBody Face face);
}

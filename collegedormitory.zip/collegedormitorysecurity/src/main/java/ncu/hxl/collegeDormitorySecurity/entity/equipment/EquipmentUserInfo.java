package ncu.hxl.collegeDormitorySecurity.entity.equipment;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class EquipmentUserInfo {
    private String equipmentUserId;
    private String equipmentId;
    private String userId;
    
    
    
}

package ncu.hxl.collegeDormitorySecurity;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = {"ncu.hxl"})
@MapperScan("ncu.hxl.collegeDormitorySecurity.mapper")
@EnableFeignClients
public class CollegeDormitorySecurity {
    public static void main(String[] args) {
        SpringApplication.run(CollegeDormitorySecurity.class, args);
    }
}

package ncu.hxl.collegeDormitorySecurity.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.configuration.AppProperties;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.common.util.RedisUtil;
import ncu.hxl.common.util.VerifyCode;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.awt.image.BufferedImage;

@RestController
@AllArgsConstructor
public class VerificationCodeController {
    private AppProperties appProperties;
    private RedisUtil redisUtil;
    @GetMapping("/getCode/{date}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getVerificationCode",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getVerificationCode")
    public CommonResult getVerificationCode(@PathVariable String date){
        VerifyCode verifyCode = new VerifyCode();
        BufferedImage image = verifyCode.getImage();
        verifyCode.outputImage(image,date,appProperties.getUploadFolder());
        redisUtil.set(verifyCode.getText(),date,1*60);
        return CommonResult.ok().data("code",appProperties.getStaticAccessPath()+"/"+date+".jpg");
    }
}

package ncu.hxl.collegeDormitorySecurity.entity;


import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("user")

public class User implements Serializable {
    public User() {
    }
    
    private static final long serialVersionUID = 1L;
    
    @TableId
    private String userId;
    private String username;
    private String password;
    private String userCollege;
    private String userClass;
    private String photoPath;
    private String photoPath1;
    private byte[] faceFeature;
    private Integer sex;
    private Integer type;
    private Date effectiveTime;
    
    @TableField(fill = FieldFill.INSERT)
    private Date createDate;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifiedDate;
    
    @TableField(exist = false)
    private String roles;
    
    
    @TableField(exist = false)
    private List<UserRole> paramsUserRoles;
    
    @TableField(exist = false)
    private List<Role> userRoles;
    
    @TableField(exist = false)
    private boolean insertFlag =false;
    
}

package ncu.hxl.collegeDormitorySecurity.service.impl;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import ncu.hxl.collegeDormitorySecurity.entity.RolePermission;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.helper.MemuHelper;
import ncu.hxl.collegeDormitorySecurity.helper.PermissionHelper;
import ncu.hxl.collegeDormitorySecurity.mapper.PermissionMapper;
import ncu.hxl.collegeDormitorySecurity.service.PermissionService;
import ncu.hxl.collegeDormitorySecurity.service.RolePermissionService;
import ncu.hxl.collegeDormitorySecurity.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
@AllArgsConstructor
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements PermissionService {

    
    private RolePermissionService rolePermissionService;
    
    
    private UserService userService;

    //给角色分配权限
    @Override
    public void saveRolePermissionRealtionShip(String roleId, String[] permissionIds) {
        rolePermissionService.remove(new QueryWrapper<RolePermission>().eq("role_id", roleId));
        List<RolePermission> rolePermissionList = new ArrayList<>();
        for(String permissionId : permissionIds) {
            if(StringUtils.isEmpty(permissionId)) continue;
      
            RolePermission rolePermission = new RolePermission();
            rolePermission.setRoleId(roleId);
            rolePermission.setPermissionId(permissionId);
            rolePermissionList.add(rolePermission);
        }
        rolePermissionService.saveBatch(rolePermissionList);
    }



    //根据用户id获取用户菜单
    @Override
    public List<String> selectPermissionValueByUserId(String id) {

        List<String> selectPermissionValueList = null;
        if(this.isSysAdmin(id)) {
            //如果是系统管理员，获取所有权限
            selectPermissionValueList = baseMapper.selectAllPermissionValue();
        } else {
            selectPermissionValueList = baseMapper.selectPermissionValueByUserId(id);
        }
        return selectPermissionValueList;
    }

    @Override
    public List<Permission> selectPermissionByUserId(String userId,Integer type) {
        List<Permission> selectPermissionList = null;
        QueryWrapper<Permission> wrapper = new QueryWrapper<>();
        
        if(this.isSysAdmin(userId)) {
            //如果是超级管理员，获取所有菜单
            selectPermissionList = baseMapper.selectList(null);
        } else {
            selectPermissionList = baseMapper.selectPermissionByUserId(userId);
        }
        if(type == null || type == 0 || type == 1){
            Iterator<Permission> iterator = selectPermissionList.iterator();
            while (iterator.hasNext()){
                Permission next = iterator.next();
                if(next.getType() == 2)
                    iterator.remove();
            }
        }else if(type == 2){
            Iterator<Permission> iterator = selectPermissionList.iterator();
            while (iterator.hasNext()){
                Permission next = iterator.next();
                if(next.getType() != 2)
                    iterator.remove();
            }
        }
        List<Permission> permissionList = PermissionHelper.bulid(selectPermissionList);
        return permissionList;
    }

    /**
     * 判断用户是否系统管理员
     * @param userId
     * @return
     */
    private boolean isSysAdmin(String userId) {
        User user = userService.getById(userId);

        if(null != user && "admin".equals(user.getUsername())) {
            return true;
        }
        return false;
    }
    
    @Override
    public List<Permission> selectOwnPermissionByRoleId(String roleId) {
        List<Permission> allPermissionList = baseMapper.selectList(new QueryWrapper<Permission>().orderByAsc("CAST(id AS SIGNED)"));
    
        //根据角色id获取角色权限
        List<RolePermission> rolePermissionList = rolePermissionService.list(new QueryWrapper<RolePermission>().eq("role_id",roleId));
        for (int i = 0; i < allPermissionList.size(); i++) {
            Permission permission = allPermissionList.get(i);
            for (int m = 0; m < rolePermissionList.size(); m++) {
                RolePermission rolePermission = rolePermissionList.get(m);
                if(rolePermission.getPermissionId().equals(permission.getId())) {
                    permission.setSelect(true);
                }
            }
        }
        Iterator<Permission> iterator = allPermissionList.iterator();
        while (iterator.hasNext()){
            Permission next = iterator.next();
            if(!next.isSelect())
                iterator.remove();
        }
        return allPermissionList;
    }
}

package ncu.hxl.collegeDormitorySecurity.myHandler;


import ncu.hxl.collegeDormitorySecurity.entity.FaceRecognition.Face;
import ncu.hxl.collegeDormitorySecurity.entity.ReceiveRolePermission;
import ncu.hxl.collegeDormitorySecurity.entity.Role;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.Equipment;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser1;

import ncu.hxl.common.entity.CommonResult;


import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

public class FaceRecognitionFallback  {
    public static CommonResult insertEquipmentInfo(Equipment equipment) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    
    public static CommonResult getVerificationCode(String date) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    
    public static CommonResult index(Long page, Long limit, User userQueryVo) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult save(User user) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult delete(String[] userIds) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getUserTarget() {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getUserById() {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult save1(User user) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    
    public static CommonResult index(Long page, Long limit, String name) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getRole() {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getAllRole() {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult save(Role role) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    
    
    public static CommonResult inAndOut(String userId, String equipmentId, MultipartFile file, Boolean in, Integer type) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectRecord(String userId, Integer type, Date date) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectAccessAfter11(Date date) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectNoAccess(Date date) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult createRQCode() {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    
    
    public static CommonResult doAssign(ReceiveRolePermission receiveRolePermission) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult toAssign(String roleId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    
    
    public static CommonResult info() {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult getMenu(Integer type) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    
    
    public static CommonResult delete(String userId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult register(MultipartFile file, String userId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult testing(String equipmentId, Face face) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    public static CommonResult updateEquipmentInfo(Equipment equipment) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    public static CommonResult deleteEquipmentInfo(String equipmentId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }

    public static CommonResult selectEquipmentInfo(Long page, Long limit, String equipmentLocation) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    public static CommonResult deleteEquipmentUserInfo(InsertUser insertUser) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    public static CommonResult insertEquipmentUserInfo(InsertUser1 insertUser1) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    public static CommonResult selectEquipmentUserInfo(String equipmentId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
}

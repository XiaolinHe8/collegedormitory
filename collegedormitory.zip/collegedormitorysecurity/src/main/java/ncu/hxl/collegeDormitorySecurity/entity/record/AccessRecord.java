package ncu.hxl.collegeDormitorySecurity.entity.record;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class AccessRecord {
    
    private String arId;
    private String arUserId;
    private Integer inRecord;
    private Integer outRecord;
    private Date inTime;
    private Date outTime;
    private String arQuipmentId;
    private Integer type;
    private String inPhotoPath;
    private String outPhotoPath;
    private String username;
    private String userClass;
    private String college;
}
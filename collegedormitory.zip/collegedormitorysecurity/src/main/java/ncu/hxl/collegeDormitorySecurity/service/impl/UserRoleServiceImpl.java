package ncu.hxl.collegeDormitorySecurity.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import ncu.hxl.collegeDormitorySecurity.entity.UserRole;
import ncu.hxl.collegeDormitorySecurity.mapper.UserRoleMapper;
import ncu.hxl.collegeDormitorySecurity.service.UserRoleService;
import org.springframework.stereotype.Service;

@Service
public class UserRoleServiceImpl extends ServiceImpl<UserRoleMapper, UserRole> implements UserRoleService {

}

package ncu.hxl.collegeDormitorySecurity.service;


import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.IService;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;


import java.util.List;

public interface PermissionService extends IService<Permission> {
    //给角色分配权限
    void saveRolePermissionRealtionShip(String roleId, String[] permissionId);
    //根据用户id获取用户菜单
    List<String> selectPermissionValueByUserId(String id);
    
    List<Permission> selectPermissionByUserId(String id,Integer type);


    List<Permission> selectOwnPermissionByRoleId(String roleId);

}

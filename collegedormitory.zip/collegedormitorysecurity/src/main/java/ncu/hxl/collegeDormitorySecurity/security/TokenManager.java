package ncu.hxl.collegeDormitorySecurity.security;

import io.jsonwebtoken.CompressionCodecs;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import ncu.hxl.collegeDormitorySecurity.configuration.AppProperties;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
//@AllArgsConstructor
public class TokenManager {
    
    private AppProperties appProperties;
    
    public TokenManager(AppProperties appProperties) {
        this.appProperties = appProperties;
    
    }
    
    //1 使用jwt根据用户名生成token
    public String createToken(String username) {
        String token = Jwts.builder().setSubject(username)
                .setExpiration(new Date(System.currentTimeMillis()+appProperties.getTokenEcpiration()))
                .signWith(SignatureAlgorithm.HS512, appProperties.getTokenSignKey()).compressWith(CompressionCodecs.GZIP).compact();
        return token;
    }
    //2 根据token字符串得到用户信息
    public String getUserInfoFromToken(String token) {
        String userinfo = Jwts.parser().setSigningKey(appProperties.getTokenSignKey()).parseClaimsJws(token).getBody().getSubject();
        return userinfo;
    }
    //3 删除token
    public void removeToken(String token) { }
}

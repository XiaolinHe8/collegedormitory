package ncu.hxl.collegeDormitorySecurity.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.collegeDormitorySecurity.entity.RolePermission;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RolePermissionMapper extends BaseMapper<RolePermission> {

}

package ncu.hxl.collegeDormitorySecurity.entity.equipment;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@NoArgsConstructor
public class InsertUser1 {
    private String equipmentId;
    private List<String> userIds;
    private List<String> deleteUserIds;
}

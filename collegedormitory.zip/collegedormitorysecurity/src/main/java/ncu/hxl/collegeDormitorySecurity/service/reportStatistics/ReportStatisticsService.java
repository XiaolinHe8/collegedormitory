package ncu.hxl.collegeDormitorySecurity.service.reportStatistics;

import ncu.hxl.collegeDormitorySecurity.service.reportStatistics.impl.ReportStatisticsServiceImpl;
import ncu.hxl.common.entity.CommonResult;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.Date;

@Component
@FeignClient(value = "reportStatistics",fallback = ReportStatisticsServiceImpl.class)
public interface ReportStatisticsService {
    @GetMapping("access/selectRecord")
    public CommonResult selectRecord(@RequestParam(value = "userId") String userId
            , @RequestParam(value = "type")Integer type,
                                     @RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date);
    
    @GetMapping("access/selectAccessAfter11")
    public CommonResult selectAccessAfter11(@RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date);
    
    @GetMapping("access/selectNoAccess")
    public CommonResult selectNoAccess(@RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date);
    
    @PostMapping(value = "access/inAndOut",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public CommonResult inAndOut(
            @RequestParam("userId") String userId,
            @RequestParam("equipmentId")String equipmentId,
            @RequestPart("file") MultipartFile file,
            @RequestParam("in")Boolean in,
            @RequestParam("type")Integer type);
    
    @GetMapping("access/getQrCode")
    public CommonResult  createRQCode(@RequestParam("userId")String userId,@RequestParam("type") Integer type);
    
    @GetMapping("access/wx")
    public String  wx(@RequestParam("signature") String signature,
                      @RequestParam("timestamp") String timestamp,
                      @RequestParam("nonce") String nonce,
                      @RequestParam("echostr") String echostr);
    
    @PostMapping("access/wx")
    public String  wx(@RequestBody String msg);
}

package ncu.hxl.collegeDormitorySecurity.entity.equipment;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class Equipment {
    private String equipmentId;
    private String equipmentLocation;
    private String equipmentIp;
    private String equipmentSoftwareVersion;
    private Integer equipmentStatus;
}

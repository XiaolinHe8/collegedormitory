package ncu.hxl.collegeDormitorySecurity.service;


import com.baomidou.mybatisplus.extension.service.IService;
import ncu.hxl.collegeDormitorySecurity.entity.UserRole;



public interface UserRoleService extends IService<UserRole> {

}

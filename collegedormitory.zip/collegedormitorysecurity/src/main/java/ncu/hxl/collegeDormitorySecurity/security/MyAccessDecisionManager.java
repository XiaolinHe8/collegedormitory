package ncu.hxl.collegeDormitorySecurity.security;

import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

@Component
public class MyAccessDecisionManager  implements AccessDecisionManager {
    @Override
    public void decide(Authentication authentication, Object o, Collection<ConfigAttribute> collection)
            throws AccessDeniedException, InsufficientAuthenticationException {
        Iterator<ConfigAttribute> iterator = collection.iterator();
        //当前请求需要的权限
        ArrayList<String> nes = new ArrayList<>();
        //当前用户所具有的权限
        ArrayList<String> cur = new ArrayList<>();
        while (iterator.hasNext()) {
            ConfigAttribute ca = iterator.next();
            String needRole = ca.getAttribute();
            nes.add(needRole);
        }
        if(nes.size() == 0)
            return;
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        for (GrantedAuthority authority : authorities) {
            cur.add(authority.getAuthority());
        }
        System.out.println("==============nes============"+nes);
        System.out.println("==============cur============"+cur);
        if(nes.size()<=cur.size()){
            for (String ne : nes) {
                if(!cur.contains(ne))
                    throw new AccessDeniedException("权限不足!");
            }
            return;
        }
        throw new AccessDeniedException("权限不足!");
    }
    
    @Override
    public boolean supports(ConfigAttribute configAttribute) {
        return true;
    }
    
    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}

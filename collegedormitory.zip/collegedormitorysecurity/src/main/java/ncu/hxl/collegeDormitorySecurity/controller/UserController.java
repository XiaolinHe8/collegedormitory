package ncu.hxl.collegeDormitorySecurity.controller;


import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.configuration.AppProperties;
import ncu.hxl.collegeDormitorySecurity.entity.*;
import ncu.hxl.collegeDormitorySecurity.entity.Class;
import ncu.hxl.collegeDormitorySecurity.mapper.ClassMapper;
import ncu.hxl.collegeDormitorySecurity.mapper.CollegeMapper;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.collegeDormitorySecurity.service.UserRoleService;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.collegeDormitorySecurity.service.RoleService;
import ncu.hxl.collegeDormitorySecurity.service.UserService;
import ncu.hxl.common.util.RedisUtil;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.*;

@RestController
@RequestMapping("/admin/user")
@AllArgsConstructor
public class UserController {


    private UserService userService;
    
    private RoleService roleService;
    
    private UserRoleService userRoleService;
    private ClassMapper classMapper;
    private CollegeMapper collegeMapper;
    
    @GetMapping("{page}/{limit}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "index",fallbackClass = FaceRecognitionFallback.class,
            fallback = "index")
    public CommonResult index(@PathVariable Long page, @PathVariable Long limit, User userQueryVo) {
        Page<User> pageParam = new Page<>(page, limit);
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        if(!StringUtils.isEmpty(userQueryVo.getUsername())) {
            wrapper.like("username",userQueryVo.getUsername());
        }

        IPage<User> pageModel = userService.page(pageParam, wrapper);
        List<User> records = pageModel.getRecords();
        for (int i = 0; i < records.size(); i++) {
            List<Role> roles = roleService.selectRoleByUserId(records.get(i).getUserId());
            records.get(i).setUserRoles(roles);
            ArrayList<String> strings = new ArrayList<>();
            for (Role role : roles) {
                strings.add(role.getId()+"_"+role.getRoleName()+",");
            }
            Class aClass = classMapper.selectById(records.get(i).getUserClass());
            records.get(i).setUserClass(aClass.getName());
            College college = collegeMapper.selectById(records.get(i).getUserCollege());
            records.get(i).setUserCollege(college.getName());
            records.get(i).setRoles(strings.toString());
            records.get(i).setPassword(null);
            
        }
        return CommonResult.ok().data("content",records).data("totalSize", pageModel.getTotal());
    }
    
    @PostMapping("save")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "save",fallbackClass = FaceRecognitionFallback.class,
            fallback = "save")
    public CommonResult save(@RequestBody User user) {
        if("admin".equals(user.getUserId())){
            return CommonResult.error().message("管理员用户，不允许修改");
        }
        if(user.getPassword()!=null &&!"".equals(user.getPassword()))
            user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        if(user.isInsertFlag()){
            user.setPhotoPath("");
            user.setFaceFeature(new byte[10]);
            userService.save(user);
        }else {
            user.setPhotoPath(null);
            user.setPhotoPath1(null);
            user.setFaceFeature(null);
            userService.updateById(user);
            userRoleService.remove(new QueryWrapper<UserRole>().eq("user_id",user.getUserId()));
        }
        userRoleService.saveBatch(user.getParamsUserRoles());
        return CommonResult.ok();
    }
    
    @PostMapping("/delete")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "delete",fallbackClass = FaceRecognitionFallback.class,
            fallback = "delete")
    public CommonResult delete(@RequestBody String[] userIds) {
        boolean flag = false;
        if(userIds == null)
            return CommonResult.error();
        for (String userId : userIds) {
            if("admin".equals(userId)){
                flag = true;
                continue;
            }
            User userInfo = userService.getById(userId);
            File file = new File(userInfo.getPhotoPath());
            if(file.exists()) file.delete();
            userService.removeById(userId);
            userRoleService.remove(new QueryWrapper<UserRole>().eq("user_id",userId));
        }
        if (flag)
            return CommonResult.error().message("管理员用户，不允许修改");
        return CommonResult.ok();
    }
    @GetMapping("/getUserTarget")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getUserTarget",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getUserTarget")
    public CommonResult getUserTarget() {
        List<College> colleges = collegeMapper.selectList(null);
        for (int i = 0; i < colleges.size(); i++) {
            List<Class> aClasses = classMapper.selectList(new QueryWrapper<Class>().eq("college_id", colleges.get(i).getId()));
            colleges.get(i).setClasses(aClasses);
    
        }
        return CommonResult.ok().data("colleges",colleges);
    }
    
    @GetMapping("/getUserById")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getUserById",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getUserById")
    public CommonResult getUserById() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User byId = userService.getById(username);
        byId.setPassword(null);
        return CommonResult.ok().data("user",byId);
    }
    
    @PostMapping("save1")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "save1",fallbackClass = FaceRecognitionFallback.class,
            fallback = "save1")
    public CommonResult save1(@RequestBody User user) {
        if("admin".equals(user.getUserId())){
            return CommonResult.error().message("管理员用户，不允许修改");
        }
        if(user.getPassword()!=null &&!"".equals(user.getPassword()))
            user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        user.setPhotoPath(null);
        user.setPhotoPath1(null);
        user.setFaceFeature(null);
        userService.updateById(user);
        return CommonResult.ok();
    }
}


package ncu.hxl.collegeDormitorySecurity.controller;


import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.ReceiveRolePermission;
import ncu.hxl.collegeDormitorySecurity.entity.Role;
import ncu.hxl.collegeDormitorySecurity.entity.RolePermission;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.collegeDormitorySecurity.service.RolePermissionService;
import ncu.hxl.collegeDormitorySecurity.service.RoleService;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import ncu.hxl.collegeDormitorySecurity.service.PermissionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/permission")
@AllArgsConstructor
//@CrossOrigin
public class PermissionController {

    
    private PermissionService permissionService;
    private RoleService roleService;
    
    @PostMapping("/doAssign")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "doAssign",fallbackClass = FaceRecognitionFallback.class,
            fallback = "doAssign")
    public CommonResult doAssign(@RequestBody ReceiveRolePermission receiveRolePermission) {
       if(receiveRolePermission == null || receiveRolePermission.getRoleId()== null
       || receiveRolePermission.getPermissionIds()==null || receiveRolePermission.getPermissionIds().length == 0)
           return CommonResult.error();
        String roleId = receiveRolePermission.getRoleId();
        Role byId = roleService.getById(roleId);
        if("admin".equals(byId.getRoleName()))
            return CommonResult.error().message("管理员权限，不能修改");
        String[] permissionIds = receiveRolePermission.getPermissionIds();
        permissionService.saveRolePermissionRealtionShip(roleId,permissionIds);
        return CommonResult.ok();
    }
    
    @GetMapping("toAssign/{roleId}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "toAssign",fallbackClass = FaceRecognitionFallback.class,
            fallback = "toAssign")
    public CommonResult toAssign(@PathVariable String roleId) {
        if(roleId == null || "".equals(roleId))
            return CommonResult.error();
        List<Permission> permissions = permissionService.selectOwnPermissionByRoleId(roleId);
        return CommonResult.ok().data("permissionList", permissions);
    }

}


package ncu.hxl.collegeDormitorySecurity.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


@Mapper
public interface PermissionMapper extends BaseMapper<Permission> {


    List<String> selectPermissionValueByUserId(String id);

    List<String> selectAllPermissionValue();

    List<Permission> selectPermissionByUserId(String userId);
}

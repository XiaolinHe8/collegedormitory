package ncu.hxl.collegeDormitorySecurity.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.collegeDormitorySecurity.service.IndexService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/index")
@AllArgsConstructor
public class IndexController {
    
    private IndexService indexService;

    /**
     * 根据token获取用户信息
     */
    @GetMapping("info")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getMenu",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getMenu")
    public CommonResult info(){
        //获取当前登录用户用户名
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        Map<String, Object> userInfo = indexService.getUserInfo(username);
        return CommonResult.ok().data(userInfo);
    }

    /**
     * 获取菜单
     * @return CommonResult
     */
    @GetMapping("menu/{type}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getMenu",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getMenu")
    public CommonResult getMenu(@PathVariable Integer type){
        //获取当前登录用户用户名
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        List<Permission> permissionList = indexService.getMenu(username,type);
        return CommonResult.ok().data("permissionList", permissionList);
    }
    

}

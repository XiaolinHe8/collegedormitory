package ncu.hxl.collegeDormitorySecurity.service.reportStatistics.impl;

import ncu.hxl.collegeDormitorySecurity.service.reportStatistics.ReportStatisticsService;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

@Component
public class ReportStatisticsServiceImpl implements ReportStatisticsService {
    @Override
    @GetMapping("access/selectRecord")
    public CommonResult selectRecord(@RequestParam(value = "userId") String userId
            , @RequestParam(value = "type")Integer type,
                                     @RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        return  CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    @Override
    @GetMapping("access/selectAccessAfter11")
    public CommonResult selectAccessAfter11(@RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        return  CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    @Override
    @GetMapping("access/selectNoAccess")
    public CommonResult selectNoAccess(@RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        return  CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult inAndOut(String userId, String equipmentId, MultipartFile file, Boolean in, Integer type) {
        return  CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    @GetMapping("access/getQrCode")
    public CommonResult  createRQCode(@RequestParam("userId")String userId,@RequestParam("type") Integer type){
        return  CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public String wx(String signature, String timestamp, String nonce, String echostr) {
        return "服务器繁忙，请稍后再试";
    }
    
    @Override
    public String wx(String msg) {
        return "服务器繁忙，请稍后再试";
    }
}

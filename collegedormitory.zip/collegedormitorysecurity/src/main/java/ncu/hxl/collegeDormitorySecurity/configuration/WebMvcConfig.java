package ncu.hxl.collegeDormitorySecurity.configuration;

import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;


@Configuration
@AllArgsConstructor
public class WebMvcConfig extends WebMvcConfigurerAdapter {
    
   
    private AppProperties fileUploadProperteis;
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(fileUploadProperteis.getStaticAccessPath()+"/**").addResourceLocations("file:" + fileUploadProperteis.getUploadFolder() + "/");
    }
    
}

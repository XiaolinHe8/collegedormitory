package ncu.hxl.collegeDormitorySecurity.controller;


import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.*;
import ncu.hxl.collegeDormitorySecurity.mapper.RoleMapper;
import ncu.hxl.collegeDormitorySecurity.mapper.RolePermissionMapper;
import ncu.hxl.collegeDormitorySecurity.mapper.UserMapper;
import ncu.hxl.collegeDormitorySecurity.mapper.UserRoleMapper;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.collegeDormitorySecurity.service.PermissionService;
import ncu.hxl.collegeDormitorySecurity.service.RolePermissionService;
import ncu.hxl.collegeDormitorySecurity.service.UserService;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.collegeDormitorySecurity.service.RoleService;
import ncu.hxl.common.util.RedisUtil;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/admin/role")
@AllArgsConstructor
public class RoleController {
    
    private RoleService roleService;
    private RoleMapper roleMapper;
    private RolePermissionService rolePermissionService;
    @GetMapping("{page}/{limit}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "index",fallbackClass = FaceRecognitionFallback.class,
            fallback = "index")
    public CommonResult index(@PathVariable Long page, @PathVariable Long limit,@RequestParam String name) {
        QueryWrapper<Role> wrapper = new QueryWrapper<>();
        if(name != null && !"".equals(name) && !"undefined".equals(name)){
            wrapper.like("role_name",name);
        }
        Page<Role> pageParam = new Page<>(page, limit);
        roleMapper.selectPage(pageParam,wrapper);
        return CommonResult.ok().data("content", pageParam.getRecords()).data("totalSize", pageParam.getTotal());
    }
    
    @GetMapping("getRole")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getRole",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getRole")
    public CommonResult getRole() {
        List<Role> roles = roleMapper.selectRoleAndPermission();
        return CommonResult.ok().data("roles", roles);
    }
    
    @GetMapping("getAllRole")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "getAllRole",fallbackClass = FaceRecognitionFallback.class,
            fallback = "getAllRole")
    public CommonResult getAllRole() {
        List<Role> roles = roleMapper.selectList(null);
        return CommonResult.ok().data("roles", roles);
    }
    
    @PostMapping("save")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "save",fallbackClass = FaceRecognitionFallback.class,
            fallback = "save")
    public CommonResult save(@RequestBody Role role) {
        if(role.getId() != null){
            Role byId = roleService.getById(role.getId());
            if(byId.getRoleName() != null && "admin".equals(byId.getRoleName())){
                return CommonResult.error().message("管理员角色，不允许修改");
            }
            roleService.updateById(role);
        }
        else{
            if(role.getRoleName() != null && "admin".equals(role.getRoleName())){
                return CommonResult.error().message("管理员角色，不允许修改");
            }
            roleService.save(role);
        }
        
        return CommonResult.ok();
    }
    
    
    @GetMapping("/delete/{id}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "delete",fallbackClass = FaceRecognitionFallback.class,
            fallback = "delete")
    public CommonResult delete(@PathVariable("id")  String id) {
        roleService.removeById(id);
        rolePermissionService.remove(new QueryWrapper<RolePermission>().eq("role_id",id));
        return CommonResult.ok();
    }
}


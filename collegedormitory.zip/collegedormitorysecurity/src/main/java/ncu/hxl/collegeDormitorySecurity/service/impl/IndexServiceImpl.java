package ncu.hxl.collegeDormitorySecurity.service.impl;

import com.alibaba.fastjson.JSONObject;

import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import ncu.hxl.collegeDormitorySecurity.entity.Role;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.service.IndexService;
import ncu.hxl.collegeDormitorySecurity.service.PermissionService;
import ncu.hxl.collegeDormitorySecurity.service.RoleService;
import ncu.hxl.collegeDormitorySecurity.service.UserService;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class IndexServiceImpl implements IndexService {

  
    private UserService userService;


    private RoleService roleService;


    private PermissionService permissionService;


    private RedisTemplate redisTemplate;

    /**
     * 根据用户名获取用户登录信息
     *
     * @param username
     * @return
     */
    public Map<String, Object> getUserInfo(String username) {
        Map<String, Object> result = new HashMap<>();
        User user = userService.selectByUsername(username);
        if (null == user) {
            throw new RuntimeException();
        }
        //根据用户id获取角色
        List<Role> roleList = roleService.selectRoleByUserId(user.getUserId());
        List<String> roleNameList = roleList.stream().map(item -> item.getRoleName()).collect(Collectors.toList());
        if(roleNameList.size() == 0) {
            roleNameList.add("");
        }

        //根据用户id获取操作权限值
        List<String> permissionValueList = permissionService.selectPermissionValueByUserId(user.getUserId());
        redisTemplate.opsForValue().set(username, permissionValueList,30, TimeUnit.SECONDS);

        result.put("userId",user.getUserId());
        result.put("name", user.getUsername());
        result.put("avatar",user.getPhotoPath1());
        result.put("roles", roleNameList);
        result.put("permissionValueList", permissionValueList);
        return result;
    }

    /**
     * 根据用户名获取动态菜单
     * @param username
     * @return
     */
    public List<Permission> getMenu(String username,Integer type) {
        User user = userService.selectByUsername(username);

        //根据用户id获取用户菜单权限
        List<Permission> permissionList = permissionService.selectPermissionByUserId(user.getUserId(),type);
        return permissionList;
    }


}

package ncu.hxl.collegeDormitorySecurity.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.collegeDormitorySecurity.entity.PathPermission;
import ncu.hxl.collegeDormitorySecurity.entity.Permission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PathPermissionMapper  extends BaseMapper<PathPermission> {
    
    @Select("select * from permission p where p.id in (select permission_id from path_permission where path=#{path})")
    public List<Permission> selectPermissionByPath(@Param("path") String path);
}

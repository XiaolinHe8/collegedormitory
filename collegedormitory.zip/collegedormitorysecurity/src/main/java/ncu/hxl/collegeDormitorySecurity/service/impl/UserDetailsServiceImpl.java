package ncu.hxl.collegeDormitorySecurity.service.impl;

import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.LoginUser;
import ncu.hxl.collegeDormitorySecurity.entity.SecurityUser;
import ncu.hxl.collegeDormitorySecurity.entity.User;
import ncu.hxl.collegeDormitorySecurity.service.PermissionService;
import ncu.hxl.collegeDormitorySecurity.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userDetailsService")
@AllArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
    
    private UserService userService;
    
    private PermissionService permissionService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //根据用户名查询数据
        User user = userService.selectByUsername(username);
        //判断
        if(user == null) {
            throw new UsernameNotFoundException("用户不存在");
        }
        LoginUser curUser = new LoginUser();
        BeanUtils.copyProperties(user,curUser);
        curUser.setUsername(user.getUserId());
        //根据用户查询用户权限列表
        List<String> permissionValueList = permissionService.selectPermissionValueByUserId(user.getUserId());
        SecurityUser securityUser = new SecurityUser();
        securityUser.setCurrentUserInfo(curUser);
        securityUser.setPermissionValueList(permissionValueList);
        return securityUser;
    }
}

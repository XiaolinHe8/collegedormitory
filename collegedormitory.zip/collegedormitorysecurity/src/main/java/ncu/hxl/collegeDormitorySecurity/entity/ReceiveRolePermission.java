package ncu.hxl.collegeDormitorySecurity.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReceiveRolePermission {
    private String roleId;
    private String[] permissionIds;
}

package ncu.hxl.collegeDormitorySecurity.entity.equipment;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class InsertUser {
    private String equipmentId;
    private List<String> userIds;
}

package ncu.hxl.collegeDormitorySecurity.service.EquipmentService;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.Equipment;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.EquipmentUserInfo;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser;
import ncu.hxl.collegeDormitorySecurity.service.EquipmentService.impl.EquipmentServiceImpl;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Component
@FeignClient(value = "equipment",fallback = EquipmentServiceImpl.class)
public interface EquipmentService {
    @PostMapping("/equipment/insert")
    public CommonResult insertEquipmentInfo(@RequestBody Equipment equipment);
    
    @PostMapping("/equipment/update")
    public CommonResult updateEquipmentInfo(@RequestBody Equipment equipment);
    
    @GetMapping("/equipment/delete/{equipmentId}")
    public CommonResult deleteEquipmentInfo(@PathVariable(value = "equipmentId") String equipmentId);
    @GetMapping("{page}/{limit}")
    public CommonResult selectEquipmentInfo(@PathVariable(value = "page") Long page, @PathVariable(value = "limit") Long limit
            ,@RequestParam("equipmentLocation") String equipmentLocation);
    @PostMapping("/equipment/insertUser")
    public CommonResult insertEquipmentUserInfo(@RequestBody InsertUser insertUser) ;
    @PostMapping("/equipment/updateUser")
    public CommonResult updateEquipmentUserInfo(@RequestBody EquipmentUserInfo equipmentUserInfo);
    
    @PostMapping("/equipment/deleteUser")
    public CommonResult deleteEquipmentUserInfo(@RequestBody InsertUser insertUser);
    @GetMapping("/equipment/selectUser/{equipmentId}")
    public CommonResult selectEquipmentUserInfo(@PathVariable(value = "equipmentId") String equipmentId);
    
    @GetMapping("/equipment/selectUser1")
    public CommonResult selectEquipmentUserInfoByUserId(String userId);
    
    @GetMapping("/equipment/heartbeat")
    public void heartbeatDetection(@RequestParam("equipmentId") String equipmentId);
}

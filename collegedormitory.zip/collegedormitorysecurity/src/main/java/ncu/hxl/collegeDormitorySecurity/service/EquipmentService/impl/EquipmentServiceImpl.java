package ncu.hxl.collegeDormitorySecurity.service.EquipmentService.impl;

import ncu.hxl.collegeDormitorySecurity.entity.equipment.Equipment;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.EquipmentUserInfo;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser;
import ncu.hxl.collegeDormitorySecurity.service.EquipmentService.EquipmentService;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Component
public class EquipmentServiceImpl implements EquipmentService {
    @Override
    public CommonResult insertEquipmentInfo(Equipment equipment) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult updateEquipmentInfo(Equipment equipment) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    @GetMapping("/equipment/delete/{equipmentId}")
    public CommonResult deleteEquipmentInfo(@PathVariable(value = "equipmentId") String equipmentId) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    @GetMapping("{page}/{limit}")
    public CommonResult selectEquipmentInfo(@PathVariable(value = "page") Long page, @PathVariable(value = "limit") Long limit,
                                            @RequestParam("equipmentLocation") String equipmentLocation){
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult insertEquipmentUserInfo(InsertUser insertUser) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult updateEquipmentUserInfo(EquipmentUserInfo equipmentUserInfo) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    @PostMapping("/equipment/deleteUser")
    public CommonResult deleteEquipmentUserInfo(@RequestBody InsertUser insertUser){
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    @GetMapping("/equipment/selectUser/{equipmentId}")
    public CommonResult selectEquipmentUserInfo(@PathVariable(value = "equipmentId") String equipmentId) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public CommonResult selectEquipmentUserInfoByUserId(String userId) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    @Override
    public void heartbeatDetection(String equipmentId) {
        return;
    }
}

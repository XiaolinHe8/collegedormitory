package ncu.hxl.collegeDormitorySecurity.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.Equipment;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser;
import ncu.hxl.collegeDormitorySecurity.entity.equipment.InsertUser1;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionFallback;
import ncu.hxl.collegeDormitorySecurity.myHandler.FaceRecognitionHandler;
import ncu.hxl.collegeDormitorySecurity.service.EquipmentService.EquipmentService;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.web.bind.annotation.*;


@RestController
@AllArgsConstructor
@RequestMapping("/cs")
public class EquipmentController {
    private EquipmentService equipmentService;
    
    @PostMapping("/equipment/insert")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "insertEquipmentInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "insertEquipmentInfo")
    public CommonResult insertEquipmentInfo(@RequestBody Equipment equipment){
        return equipmentService.insertEquipmentInfo(equipment);
    }
    
    @PostMapping("/equipment/update")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "updateEquipmentInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "updateEquipmentInfo")
    public CommonResult updateEquipmentInfo(@RequestBody Equipment equipment){
        return equipmentService.updateEquipmentInfo(equipment);
    }

    @GetMapping("/equipment/delete/{equipmentId}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "deleteEquipmentInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "deleteEquipmentInfo")
    public CommonResult deleteEquipmentInfo(@PathVariable(value = "equipmentId") String equipmentId){
       return equipmentService.deleteEquipmentInfo(equipmentId);
    }
    @GetMapping("{page}/{limit}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectEquipmentInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "selectEquipmentInfo")
    public CommonResult selectEquipmentInfo(@PathVariable(value = "page") Long page, @PathVariable(value = "limit") Long limit,
                                            @RequestParam("equipmentLocation") String equipmentLocation){
        return equipmentService.selectEquipmentInfo(page,limit,equipmentLocation);
    }
    
    
    @PostMapping("/equipment/deleteUser")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "deleteEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "deleteEquipmentUserInfo")
    public CommonResult deleteEquipmentUserInfo(@RequestBody InsertUser insertUser){
        return equipmentService.deleteEquipmentUserInfo(insertUser);
    }
    @PostMapping("/equipment/insertUser")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "insertEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "insertEquipmentUserInfo")
    public CommonResult insertEquipmentUserInfo(@RequestBody InsertUser1 insertUser1){
        InsertUser insertUser = new InsertUser();
        insertUser.setUserIds(insertUser1.getDeleteUserIds());
        insertUser.setEquipmentId(insertUser1.getEquipmentId());
        equipmentService.deleteEquipmentUserInfo(insertUser);
        insertUser.setUserIds(insertUser1.getUserIds());
        return equipmentService.insertEquipmentUserInfo(insertUser);
    }
    @GetMapping("/equipment/selectUser/{equipmentId}")
    @SentinelResource(value = "global",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "selectEquipmentUserInfo")
    public CommonResult selectEquipmentUserInfo(@PathVariable(value = "equipmentId") String equipmentId){
       return equipmentService.selectEquipmentUserInfo(equipmentId);
    }
    
    @GetMapping("/equipment/heartbeat")
    public void heartbeatDetection(@RequestParam("equipmentId") String equipmentId){
        equipmentService.heartbeatDetection(equipmentId);
    }
}

package ncu.hxl.collegeDormitorySecurity.service;

import ncu.hxl.collegeDormitorySecurity.entity.Permission;

import java.util.List;

public interface PathPermissionService {
    List<Permission> selectPermissionByPath(String path);
}

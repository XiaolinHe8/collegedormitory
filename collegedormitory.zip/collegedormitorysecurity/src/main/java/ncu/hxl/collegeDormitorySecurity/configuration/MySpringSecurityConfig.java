package ncu.hxl.collegeDormitorySecurity.configuration;

import lombok.AllArgsConstructor;
import ncu.hxl.collegeDormitorySecurity.filter.TokenAuthFilter;
import ncu.hxl.collegeDormitorySecurity.filter.TokenLoginFilter;
import ncu.hxl.collegeDormitorySecurity.security.*;
import ncu.hxl.common.util.RedisUtil;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.io.Serializable;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@AllArgsConstructor
public class MySpringSecurityConfig extends WebSecurityConfigurerAdapter {
    private TokenManager tokenManager;
    private RedisTemplate<String, Serializable> redisTemplate;
    private UserDetailsService userDetailsService;
    private MySessionInformationExpiredStrategy sessionInformationExpiredStrategy;
    
    //访问决策管理器
    private MyAccessDecisionManager accessDecisionManager;
    
    //实现权限拦截
    private MyFilterInvocationSecurityMetadataSource securityMetadataSource;
    
    private MyAbstractSecurityInterceptorFilter securityInterceptor;
    
    private MyAccessDeniedHandler accessDeniedHandler;
    private AppProperties appProperties;
    
    
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
       
        auth.userDetailsService(userDetailsService).passwordEncoder(new BCryptPasswordEncoder());
    }
    
    //不认证的路径
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/cs/access/inAndOut","/cs/equipment/testing","/cs/equipment/heartbeat","/cs/equipment/insert","/cs/faceRecognition/register/*","/error","/getCode/*",appProperties.getStaticAccessPath()+"/*","/cs/access/wx");
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
       
        http.exceptionHandling()
                .accessDeniedHandler(accessDeniedHandler)//权限不足处理去
                .authenticationEntryPoint(new UnauthEntryPoint())//匿名访问,处理异常
                .and()
                .csrf().disable()
                .authorizeRequests()
                .anyRequest().authenticated()
                .withObjectPostProcessor(new ObjectPostProcessor<FilterSecurityInterceptor>() {
                    @Override
                    public <O extends FilterSecurityInterceptor> O postProcess(O o) {
                        o.setAccessDecisionManager(accessDecisionManager);//决策管理器
                        o.setSecurityMetadataSource(securityMetadataSource);//安全元数据源
                        return o;
                    }
                })
                .and()
                .logout().logoutUrl("/logout").permitAll()//退出路径
                .addLogoutHandler(new TokenLogoutHandler(tokenManager,redisTemplate))
                .deleteCookies("JSESSIONID")
                .and()
                .addFilterAt(new TokenLoginFilter(authenticationManager(), tokenManager, redisTemplate), UsernamePasswordAuthenticationFilter.class)
                .addFilterAt(new TokenAuthFilter(authenticationManager(), tokenManager, redisTemplate), BasicAuthenticationFilter.class).httpBasic()
                .and().sessionManagement().
                maximumSessions(1).//同一账号同时登录最大用户数
                expiredSessionStrategy(sessionInformationExpiredStrategy);;//登录失败处理逻辑;
        
        
        http.addFilterBefore(securityInterceptor, FilterSecurityInterceptor.class);
    }
    

    
    
}
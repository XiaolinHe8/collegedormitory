package ncu.hxl.collegeDormitorySecurity.security;

import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.common.util.ResponseUtil;
import org.springframework.security.web.session.SessionInformationExpiredEvent;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import java.io.IOException;

@Component
public class MySessionInformationExpiredStrategy implements SessionInformationExpiredStrategy {
    @Override
    public void onExpiredSessionDetected(SessionInformationExpiredEvent sessionInformationExpiredEvent) throws IOException, ServletException {
      
        ResponseUtil.out( sessionInformationExpiredEvent.getResponse(), CommonResult.error().message("账号在异地登录"));
    }
}

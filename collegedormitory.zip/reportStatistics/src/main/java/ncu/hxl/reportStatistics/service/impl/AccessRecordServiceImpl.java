package ncu.hxl.reportStatistics.service.impl;

import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.AllArgsConstructor;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.common.entity.UserOpenId;
import ncu.hxl.common.util.ImageUtil;
import ncu.hxl.common.util.RedisUtil;
import ncu.hxl.common.util.WXUtil;
import ncu.hxl.reportStatistics.been.AccessRecord;
import ncu.hxl.reportStatistics.been.Class;
import ncu.hxl.reportStatistics.been.College;
import ncu.hxl.reportStatistics.been.User;
import ncu.hxl.reportStatistics.been.WxUser;
import ncu.hxl.reportStatistics.configuration.AppProperties;
import ncu.hxl.reportStatistics.dao.mapper.*;
import ncu.hxl.reportStatistics.service.AccessRecordService;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@AllArgsConstructor
@EnableScheduling
public class AccessRecordServiceImpl implements AccessRecordService {
    private AccessRecordMapper accessRecordMapper;
    private AppProperties appProperties;
    private RedisUtil redisUtil;
    private WxUserMapper wxUserMapper;
    private UserMapper userMapper;
    private ClassMapper classMapper;
    private CollegeMapper collegeMapper;
    
    @Override
    public CommonResult inAndOutRecord(String userId, String equipmentId, MultipartFile file,boolean in,Integer type) {
        CommonResult result = null;
        String path = null;
        if(type == 0){
            path = appProperties.getPhotoPath();
        }else
            path = appProperties.getVideoPath();
        String imagePath = ImageUtil.insertImage(file, path);
        AccessRecord accessRecord = new AccessRecord().setType(type);
        accessRecord = in ? accessRecord.setInRecord(1).setInTime(new Date()).setInPhotoPath(imagePath)
                : accessRecord.setOutTime(new Date()).setOutRecord(1).setOutPhotoPath(imagePath);
        String arId =(String) redisUtil.get(userId);
        if(arId == null || "".equals(arId)){
            accessRecord.setArUserId(userId).setArQuipmentId(equipmentId);
            if( accessRecordMapper.insert(accessRecord) > 0)
                result = CommonResult.ok().data("accessRecord",accessRecord);
            redisUtil.set(userId,accessRecord.getArId());
        }else {
            redisUtil.del(userId);
            accessRecord.setArId(arId);
            if( accessRecordMapper.updateById(accessRecord) > 0)
                result = CommonResult.ok().data("accessRecord",accessRecord);
            
        }
        return result;
    }
    
   
    
    @Override
    public CommonResult selectRecord(String userId,Integer type,Date date) {
        CommonResult result = CommonResult.ok();
        List<AccessRecord> ar_user_id = null;
        HashMap<String, Object> m = new HashMap<>();
        QueryWrapper<AccessRecord> wrapper = new QueryWrapper<>();
        if(userId != null && !"".equals(userId) && !"undefined".equals(userId) &&!"null".equals(userId))
            m.put("ar_user_id",userId);
        if(type !=  null && type == 0)
            m.put("type",type);
        wrapper.allEq(m);
        if(type !=  null && type != 0){
            ArrayList<Integer> objects = new ArrayList<>();
            objects.add(1);
            objects.add(2);
            objects.add(3);
            objects.add(-1);
            wrapper.in("type",objects);
            
        }
        
        if(date != null && !"null".equals(date)){
            String tom = DateUtil.format(date, "yyyy-MM-dd");
            Date begin = DateUtil.parse(tom+" 00:00:00","yyyy-MM-dd HH:mm:ss");
            Date end = DateUtil.parse(tom+" 23:59:59","yyyy-MM-dd HH:mm:ss");
            wrapper.between(("in_time"), begin, end).or().between(("out_time"), begin, end);
        }
        ar_user_id = accessRecordMapper
                    .selectList(wrapper);
        for (int i = 0; i < ar_user_id.size(); i++) {
            ar_user_id.get(i).setInPhotoPath(ChangePhotoPath( ar_user_id.get(i).getInPhotoPath(),type == 0));
            ar_user_id.get(i).setOutPhotoPath(ChangePhotoPath( ar_user_id.get(i).getOutPhotoPath(),type == 0));
        }
        System.out.println("==================access_record"+ar_user_id);
        result.data("access_record",ar_user_id);
        return result;
    }
    

    
    @Scheduled(cron = "0 0 6 * * ?")
//    @Scheduled(fixedDelay = 10000)
    @Async
    @Override
    public CommonResult selectAccessAfter11() {
        CommonResult result = selectAccessAfter11(null,new Date());
        List<AccessRecord> accessRecords =( List<AccessRecord>) result.getData().get("accessRecords");
        ArrayList<String> wechatResult = getUserId(accessRecords);
        if(wechatResult!= null && wechatResult.size() != 0){
            List<User> users = userMapper.selectList(new QueryWrapper<User>().in("user_id", wechatResult));
            sendWxMsg(users,accessRecords,"晚归名单");
        }
        System.out.println("=======================selectAccessAfter11"+accessRecords);
        return result;
    }
    
    @Override
    public CommonResult selectAccessAfter11(String userId,Date date) {
        QueryWrapper<AccessRecord> wrapper = new QueryWrapper<>();
        if(userId != null && !"".equals(userId))
            wrapper.eq("ar_user_id",userId);
        CommonResult result = CommonResult.ok();
        String today = DateUtil.format(date, "yyyy-MM-dd");
        String tom = DateUtil.format(DateUtil.offsetDay(date,1), "yyyy-MM-dd");
        Date begin = DateUtil.parse(today+" 23:00:00","yyyy-MM-dd HH:mm:ss");
        Date end = DateUtil.parse(tom+" 06:00:00","yyyy-MM-dd HH:mm:ss");
        List<AccessRecord> accessRecords = accessRecordMapper.selectList(
                wrapper.between(("in_time"), begin, end));
        for (int i = 0; i < accessRecords.size(); i++) {
            accessRecords.get(i).setInPhotoPath(ChangePhotoPath( accessRecords.get(i).getInPhotoPath(),true));
            accessRecords.get(i).setOutPhotoPath(ChangePhotoPath( accessRecords.get(i).getOutPhotoPath(),true));
        }
        result.data("accessRecords",accessRecords);
        return result;
    }
//        @Scheduled(fixedDelay = 10000)
    @Scheduled(cron = "0 0 22 ? * 1")
    @Async
    @Override
    public CommonResult selectNoAccess() {
        Date endOfWeek = new Date();
        CommonResult commonResult = selectNoAccess(endOfWeek);
        List<String> notOut = (List<String>)commonResult.getData().get("notOut");
        List<String> notReturned = (List<String>)commonResult.getData().get("notReturned");
        List<String> noData = (List<String>)commonResult.getData().get("noData");
        if(notOut != null && notOut.size() != 0){
            List<User> usersNotOut = userMapper.selectList(new QueryWrapper<User>().in("user_id", notOut));
            sendWxMsg(usersNotOut,null,"一周未出名单");
        }
        
        if(notReturned != null && notReturned.size() != 0){
            List<User> usersNotReturned = userMapper.selectList(new QueryWrapper<User>().in("user_id", notReturned));
            sendWxMsg(usersNotReturned,null,"一周未归名单");
        }
        
        if(noData != null && noData.size() != 0){
            List<User> usersNoData = userMapper.selectList(new QueryWrapper<User>().in("user_id", noData));
            sendWxMsg(usersNoData,null,"一周无数据名单");
        }
      
      
        return commonResult;
    }
    
    @Override
    public CommonResult selectNoAccess(Date endOfWeek) {
        Date beginOfWeek = DateUtil.offsetDay(endOfWeek, -6);
        List<String> accessRecords = accessRecordMapper.selectNoAccessOut(beginOfWeek,endOfWeek);
        List<String> accessRecords1 = accessRecordMapper.selectNoAccessIn(beginOfWeek,endOfWeek);
        List<String> strings = accessRecordMapper.selectNoAccess(beginOfWeek, endOfWeek);
        return CommonResult.ok().data("notOut",accessRecords).data("notReturned",accessRecords1).data("noData",strings);
    }
    
    
    
    private ArrayList<String> getUserId(List<AccessRecord> accessRecords){
        ArrayList<String> wechatResult = new ArrayList<>();
        for (AccessRecord accessRecord : accessRecords) {
            wechatResult.add(accessRecord.getArUserId());
        }
        return  wechatResult;
    }
    
    @Override
    public String createRQCode(String sceneId){
    
        String qrCode = WXUtil.createQRCode(WXUtil.getToken(), sceneId, null);
        return qrCode;
    }
    
    @Override
    public String wxMsg(String msg){
        String result = "<xml>\n" +
                "  <ToUserName><![CDATA[toUser]]></ToUserName>\n" +
                "  <FromUserName><![CDATA[fromUser]]></FromUserName>\n" +
                "  <CreateTime>12345678</CreateTime>\n" +
                "  <MsgType><![CDATA[text]]></MsgType>\n" +
                "  <Content><![CDATA[myMsg]]></Content>\n" +
                "</xml>";
        HashMap<String, String> map = new HashMap<>();
        SAXReader saxReader = new SAXReader();
        try {
            Document read = saxReader.read(new ByteArrayInputStream(msg.getBytes()));
            Element rootElement = read.getRootElement();
            List<Element> elements = rootElement.elements();
            for (Element element : elements) {
                map.put(element.getName(),element.getStringValue());
            }
            if(map.get("Ticket")!= null && !"".equals(map.get("Ticket"))){
                String[] split = map.get("EventKey").split("_");
                WxUser wxUser = new WxUser().setWxId(map.get("FromUserName")).setUserId(split[0]).setType(Integer.parseInt(split[1]));
                String key = null;
                switch (wxUser.getType()){
                    case 0: key = "admin";
                    case 1: key = "dean";
                    case 2: key = "headmaster";
                    default:key=null;
                    
                }
                if(key != null){
                    List<WxUser> wxUsers =( List<WxUser>) redisUtil.get(key);
                    if(wxUsers != null){
                        for (int i = 0; i < wxUsers.size(); i++) {
                            if(wxUser.getUserId().equals(wxUsers.get(i).getUserId())){
                                wxUsers.get(i).setWxId(wxUser.getWxId()).setType(wxUser.getType());
                            }
                        }
                        redisUtil.set(key,wxUsers,60*24*5);
                    }
                }
                
                wxUserMapper.insert(wxUser);
                result = result.replace("toUser",map.get("FromUserName"))
                        .replace("fromUser",map.get("ToUserName"))
                        .replace("myMsg","绑定成功");
                return result;
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        return result.replace("toUser",map.get("FromUserName"))
                .replace("fromUser",map.get("ToUserName"))
                .replace("myMsg","未知信息");
    }
    
    
    private String ChangePhotoPath(String origin,boolean flag){
        if(origin == null || "".equals(origin))
            return null;
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if(requestAttributes == null)
            return null;
        HttpServletRequest request = requestAttributes.getRequest();
        String localAddr = request.getLocalAddr();
        int serverPort = request.getServerPort();
        File file = new File(origin);
        String name = file.getName();
        if(flag){

            return  "http://"+localAddr +":"+ serverPort+appProperties.getStaticAccessPath()+"/"+name;
        }else{
            return "http://"+localAddr +":"+ serverPort+appProperties.getStaticAccessPath1()+"/"+name;
        }
    }
    private void groupUser(List<User> users,List<AccessRecord> accessRecords
    ,HashMap<String, List<String>> resByClass, HashMap<String, List<String>> resByCollege
    , HashMap<String, String> resAllUser){
        String strDateFormat = "yyyy-MM-dd HH:mm:ss";
        SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
        for (User user : users) {
            List<String> byClassOrDefault = resByClass.getOrDefault(user.getUserClass(), new ArrayList<String>());
            List<String> byCollegeOrDefault = resByCollege.getOrDefault(user.getUserCollege(), new ArrayList<String>());
            College college = collegeMapper.selectById(user.getUserCollege());
            Class aClass = classMapper.selectById(user.getUserClass());
            String s = user.getUserId() + "-"+user.getUsername() + "-" +college.getName() + "-" + aClass.getName();
            if(accessRecords!= null){
                for (AccessRecord accessRecord : accessRecords) {
                    if(accessRecord.getArUserId().equals(user.getUserId())){
                        if(accessRecord.getInTime() != null) {
                            s = s + "-" + "进入时间:"+ sdf.format(accessRecord.getInTime());
                        }
                        if(accessRecord.getOutTime() != null) {
                            s = s + "-" + "离开时间:" + sdf.format(accessRecord.getOutTime());
                        }
                    }
                }
            }
            byClassOrDefault.add(s);
            byCollegeOrDefault.add(s);
            resAllUser.put(user.getUserId(),s);
            resByClass.put(user.getUserClass(),byClassOrDefault);
            resByCollege.put(user.getUserCollege(),byCollegeOrDefault);
           
        }
    }
    
    
    private void sendWxMsg(String wxId,String params,String title){
        String token = WXUtil.getToken();
        String templateId = "BjwGGIc069JKizVuDJIBjtA1CJyExIN8cMvytiHjCOA";
        String toUrl = "https://www.baidu.com";
        HashMap<String, Object> map = new HashMap<>();
        HashMap<String, Object> map1 = new HashMap<>();
        map1.put("value",title);
        map1.put("color","#173177");
        map.put("first",map1);
        HashMap<String, Object> map2 = new HashMap<>();
        map2.put("value",params);
        map2.put("color","#173177");
        map.put("person",map2);
        HashMap<String, Object> map3 = new HashMap<>();
        map3.put("value","请及时联系上述同学了解情况");
        map3.put("color","#173177");
        map.put("remark",map3);
        WXUtil.SendWeChatMsg(token,wxId,templateId,toUrl,map);
    }
    
    private void sendWxMsg(List<User> users,List<AccessRecord> accessRecords,String title){
        HashMap<String, List<String>> resByClass = new HashMap<>();
        HashMap<String, List<String>> resByCollege = new HashMap<>();
        HashMap<String, String> resAllUser = new HashMap<>();
        groupUser(users,accessRecords,resByClass,resByCollege,resAllUser);
    
        List<WxUser> admin =( List<WxUser>) redisUtil.get("admin");
        if(admin == null){
            admin = wxUserMapper.selectList(new QueryWrapper<WxUser>().eq("type", 2));
            redisUtil.set("admin",admin,60*24);
        }
        List<WxUser> dean =( List<WxUser>) redisUtil.get("dean");
        if(dean == null){
            dean = wxUserMapper.selectList(new QueryWrapper<WxUser>().eq("type", 1));
            redisUtil.set("dean",dean,60*24);
        }
        List<WxUser> headmaster =( List<WxUser>) redisUtil.get("headmaster");
        if(headmaster == null){
            headmaster = wxUserMapper.selectList(new QueryWrapper<WxUser>().eq("type", 0));
            redisUtil.set("headmaster",headmaster,60*24);
        }
        Iterator<WxUser> iterator = admin.iterator();
        while(iterator.hasNext()){
            WxUser next = iterator.next();
            sendWxMsg(next.getWxId(),resAllUser.values().toString(),title);
        
        }
    
        iterator = dean.iterator();
        while(iterator.hasNext()){
            WxUser next = iterator.next();
            User user =(User) redisUtil.get(next.getUserId());
            if(user == null){
                user = userMapper.selectById(next.getUserId());
                redisUtil.set(user.getUserId(),user,60*24*5);
            }
            if(resByCollege.containsKey(user.getUserCollege()))
                sendWxMsg(next.getWxId(),resByCollege.get(user.getUserCollege()).toString(),title);
        }
    
        iterator = headmaster.iterator();
        while(iterator.hasNext()){
            WxUser next = iterator.next();
            User user =(User) redisUtil.get(next.getUserId());
            if(user == null){
                user = userMapper.selectById(next.getUserId());
                redisUtil.set(user.getUserId(),user,60*24*5);
            }
            if(resByClass.containsKey(user.getUserClass()))
                sendWxMsg(next.getWxId(),resByCollege.get(user.getUserClass()).toString(),title);
        }
    }
}

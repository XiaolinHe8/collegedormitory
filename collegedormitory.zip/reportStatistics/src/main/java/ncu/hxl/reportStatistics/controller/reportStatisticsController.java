package ncu.hxl.reportStatistics.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.google.errorprone.annotations.Var;
import lombok.AllArgsConstructor;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.reportStatistics.myHandler.FaceRecognitionFallback;
import ncu.hxl.reportStatistics.myHandler.FaceRecognitionHandler;
import ncu.hxl.reportStatistics.service.AccessRecordService;
import org.apache.commons.codec.digest.DigestUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

@RestController
@AllArgsConstructor
public class reportStatisticsController {
    
    private AccessRecordService accessRecordService;
    
    
    
    @PostMapping(value = "access/inAndOut",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @SentinelResource(value = "inAndOut",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "inAndOut",fallbackClass = FaceRecognitionFallback.class,fallback = "inAndOut")
    public CommonResult inAndOut(
            @RequestParam("userId") String userId,
            @RequestParam("equipmentId")String equipmentId,
            @RequestPart("file") MultipartFile file,
            @RequestParam("in")Boolean in,
            @RequestParam("type")Integer type){
        CommonResult commonResult = accessRecordService.inAndOutRecord(userId, equipmentId, file,in,type);
        return commonResult;
        
    }
    
    @GetMapping("access/selectRecord")
    @SentinelResource(value = "selectRecord",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectRecord",fallbackClass = FaceRecognitionFallback.class,fallback = "selectRecord")
    public CommonResult selectRecord(@RequestParam(value = "userId") String userId
            , @RequestParam(value = "type")Integer type,
                                     @RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        CommonResult commonResult = accessRecordService.selectRecord(userId,type,date);
        return commonResult;
    }
    
    @GetMapping("access/selectAccessAfter11")
    @SentinelResource(value = "selectAccessAfter11",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectAccessAfter11",fallbackClass = FaceRecognitionFallback.class,fallback = "selectAccessAfter11")
    public CommonResult selectAccessAfter11(@RequestParam(value = "date")  @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        CommonResult commonResult = accessRecordService.selectAccessAfter11(null,date);
        return commonResult;
    }
    
    @GetMapping("access/selectNoAccess")
    @SentinelResource(value = "selectNoAccess",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectNoAccess",fallbackClass = FaceRecognitionFallback.class,fallback = "selectNoAccess")
    public CommonResult selectNoAccess(@RequestParam(value = "date") @DateTimeFormat(pattern="yyyy-MM-dd") Date date){
        CommonResult commonResult = accessRecordService.selectNoAccess(date);
        return commonResult;
    }
    
    @GetMapping("access/getQrCode")
    @SentinelResource(value = "getQrCode",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "createRQCode",fallbackClass = FaceRecognitionFallback.class,fallback = "createRQCode")
    public CommonResult  createRQCode(@RequestParam("userId")String userId,@RequestParam("type") Integer type){
        if(userId == null )
            return CommonResult.error();
        
        CommonResult commonResult = CommonResult.ok();
        commonResult.data("qrCode",accessRecordService.createRQCode(userId+"_"+type));
        return commonResult;
    }
    
    @GetMapping("access/wx")
    public String  wx(@RequestParam("signature") String signature,
                      @RequestParam("timestamp") String timestamp,
                      @RequestParam("nonce") String nonce,
                      @RequestParam("echostr") String echostr){
        String token = "hxl";
        String[] strings = new String[]{token,timestamp,nonce};

        Arrays.sort(strings);
        String result = "";
        for (int i = 0; i < 3; i++) {
            result+=strings[i];
        }
        System.out.println(result);
        String s = DigestUtils.sha1Hex(result);
        if(s.equals(signature))
            return echostr;
        return null;
    }
    
    @PostMapping("access/wx")
    public String  wx(@RequestBody String msg){
        return accessRecordService.wxMsg(msg);
    }
}

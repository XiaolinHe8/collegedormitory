package ncu.hxl.reportStatistics.service;

import ncu.hxl.common.entity.CommonResult;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

public interface AccessRecordService {
    public CommonResult inAndOutRecord(String userId, String equipmentId, MultipartFile file,boolean in,Integer type);
    public CommonResult selectRecord(String userId,Integer type,Date date);
    public CommonResult selectAccessAfter11();
    public CommonResult selectNoAccess();
    public String createRQCode(String sceneId);
    public String wxMsg(String msg);
    public CommonResult selectNoAccess(Date endOfWeek);
    public CommonResult selectAccessAfter11(String userId,Date date);
}

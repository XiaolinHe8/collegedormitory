package ncu.hxl.reportStatistics.been;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)

public class WxUser {
    @TableField
    private String userId;
    private String wxId;
    private Integer type;
}

package ncu.hxl.reportStatistics.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "image-config")
@Data
public class AppProperties {
    private Long imageSize = 2097152L;
    private String photoPath = "F:/myImage";
    private String videoPath = "F:/myVideo";
    private String staticAccessPath = "/photo";
    private String staticAccessPath1 = "/video";
}

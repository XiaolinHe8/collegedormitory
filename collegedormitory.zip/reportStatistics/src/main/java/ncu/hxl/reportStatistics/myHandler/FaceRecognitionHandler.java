package ncu.hxl.reportStatistics.myHandler;


import com.alibaba.csp.sentinel.slots.block.BlockException;
import ncu.hxl.common.entity.CommonResult;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

public class FaceRecognitionHandler {
    
    public static CommonResult inAndOut(String userId, String equipmentId, MultipartFile file, Boolean in, Integer type,BlockException b){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    public static CommonResult selectRecord(String userId,Integer type, Date date,BlockException b){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectAccessAfter11(Date date,BlockException b){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectNoAccess(Date date,BlockException b){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
    
    public static CommonResult  createRQCode(String userId, Integer type,BlockException b){
        return CommonResult.error().message("服务器繁忙，请稍后再试").setCode(1000);
    }
}

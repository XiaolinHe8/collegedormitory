package ncu.hxl.reportStatistics.myHandler;

import ncu.hxl.common.entity.CommonResult;
import org.springframework.web.multipart.MultipartFile;
import java.util.Date;

public class FaceRecognitionFallback {
    public static CommonResult inAndOut(String userId, String equipmentId, MultipartFile file, Boolean in, Integer type){
        return CommonResult.error().message("服务器异常，请稍后再试").setCode(1000);
    }
    public static CommonResult selectRecord(String userId,Integer type, Date date){
        return CommonResult.error().message("服务器异常，请稍后再试").setCode(1000);
    }
    

    public static CommonResult selectAccessAfter11(Date date){
        return CommonResult.error().message("服务器异常，请稍后再试").setCode(1000);
    }
    

    public static CommonResult selectNoAccess(Date date){
        return CommonResult.error().message("服务器异常，请稍后再试").setCode(1000);
    }
    
    public static CommonResult  createRQCode(String userId, Integer type){
        return CommonResult.error().message("服务器异常，请稍后再试").setCode(1000);
    }
    
}

package ncu.hxl.reportStatistics.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.reportStatistics.been.College;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CollegeMapper extends BaseMapper<College> {
}

package ncu.hxl.reportStatistics.been;


import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("user")

public class User implements Serializable {
    public User() {
    }
    
    private static final long serialVersionUID = 1L;
    
    @TableId
    private String userId;
    private String username;
    private String password;
    private String userCollege;
    private String userClass;
    private String photoPath;
    private String photoPath1;
    private byte[] faceFeature;
    private Integer sex;
    private Integer type;
    private Date effectiveTime;
    
    @TableField(fill = FieldFill.INSERT)
    private Date createDate;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date modifiedDate;
    
}

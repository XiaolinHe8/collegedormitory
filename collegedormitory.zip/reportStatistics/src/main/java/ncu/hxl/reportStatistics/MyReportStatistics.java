package ncu.hxl.reportStatistics;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@MapperScan("ncu.hxl.reportStatistics.dao.mapper")
@SpringBootApplication(scanBasePackages = {"ncu.hxl"})
public class MyReportStatistics {
    public static void main(String[] args) {
        SpringApplication.run(MyReportStatistics.class,args);
    }
}

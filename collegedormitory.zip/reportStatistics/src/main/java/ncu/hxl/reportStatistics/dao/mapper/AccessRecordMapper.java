package ncu.hxl.reportStatistics.dao.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.reportStatistics.been.AccessRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

@Mapper
public interface AccessRecordMapper extends BaseMapper<AccessRecord> {
    //一周无数据
    @Select("select user_id as ar_user_id from user where user_id not in (select ar_user_id from access_record where in_time between #{begin} and #{end} or out_time between #{begin} and #{end}) ")
    public List<String> selectNoAccess(@Param("begin") Date begin,@Param("end") Date end);
    //一周未出
    @Select("select ar_user_id from access_record where in_time between #{begin} and #{end} group by ar_user_id having count(*) = 1 " +
            "and  ar_user_id in (select ar_user_id from access_record where in_time between #{begin} and #{end} and out_time is NULL)")
    public List<String> selectNoAccessOut(@Param("begin") Date begin,@Param("end") Date end);
    //一周未归
    @Select("select ar_user_id from access_record where out_time between #{begin} and #{end} group by ar_user_id having count(*) = 1 " +
            "and  ar_user_id in (select ar_user_id from access_record where out_time between #{begin} and #{end} and in_time is NULL)")
    public List<String> selectNoAccessIn(@Param("begin") Date begin,@Param("end") Date end);
}

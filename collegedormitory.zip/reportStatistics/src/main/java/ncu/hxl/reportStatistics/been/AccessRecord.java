package ncu.hxl.reportStatistics.been;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
public class AccessRecord {
    
    @TableId(type = IdType.ASSIGN_UUID)
    private String arId;
    private String arUserId;
    private Integer inRecord;
    private Integer outRecord;
    private Date inTime;
    private Date outTime;
    private String arQuipmentId;
    private Integer type;
    private String inPhotoPath;
    private String outPhotoPath;
}

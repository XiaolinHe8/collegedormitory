package ncu.hxl.equipment.myHandler;


import com.alibaba.csp.sentinel.slots.block.BlockException;
import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.equipment.been.Equipment;
import ncu.hxl.equipment.been.EquipmentUserInfo;
import ncu.hxl.equipment.been.InsertUser;


public class FaceRecognitionHandler {
    
    public static CommonResult insertEquipmentInfo(Equipment equipment, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult updateEquipmentInfo(Equipment equipment, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult deleteEquipmentInfo( String equipmentId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectEquipmentInfo( Long page,  Long limit,
                                                    String equipmentLocation, BlockException b){
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult insertEquipmentUserInfo(InsertUser insertUser, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult updateEquipmentUserInfo(EquipmentUserInfo equipmentUserInfo, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    
    public static CommonResult deleteEquipmentUserInfo( InsertUser insertUser, BlockException b){
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectEquipmentUserInfo( String equipmentId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectEquipmentUserInfoByUserId(String userId, BlockException b) {
        return  CommonResult.error().message("设备服务繁忙，请稍后再试").setCode(1000);
    }
}

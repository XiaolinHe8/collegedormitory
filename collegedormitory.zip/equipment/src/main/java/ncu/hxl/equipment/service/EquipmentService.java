package ncu.hxl.equipment.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import ncu.hxl.equipment.been.Equipment;
import ncu.hxl.equipment.been.EquipmentUserInfo;

import java.util.List;

public interface EquipmentService {
    public boolean insertEquipmentInfo(Equipment equipment);
    public boolean updateEquipmentInfo(Equipment equipment);
    public boolean deleteEquipmentInfo(String equipmentId);
    public Page<Equipment> selectEquipmentInfo(Long page, Long limit, String equipmentLocation);
    
    public boolean insertEquipmentUserInfo(String equipmentId,List<String> userIds);
    public boolean updateEquipmentUserInfo(EquipmentUserInfo equipmentUserInfo);
    public boolean deleteEquipmentUserInfo(String equipmentId,List<String> userIds);
    public List<EquipmentUserInfo> selectEquipmentUserInfo(String equipmentId);
    
    public List<EquipmentUserInfo> selectEquipmentUserInfoByUserId(String userId);
    
    
    public void heartbeatDetection(String equipmentId);
    
    public void heartbeatDetection();
    
}

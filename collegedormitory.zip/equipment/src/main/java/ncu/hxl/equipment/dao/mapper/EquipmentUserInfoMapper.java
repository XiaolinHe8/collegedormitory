package ncu.hxl.equipment.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import ncu.hxl.equipment.been.EquipmentUserInfo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EquipmentUserInfoMapper extends BaseMapper<EquipmentUserInfo> {
}

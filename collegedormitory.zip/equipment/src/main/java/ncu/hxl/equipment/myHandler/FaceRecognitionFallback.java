package ncu.hxl.equipment.myHandler;

import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.equipment.been.Equipment;
import ncu.hxl.equipment.been.EquipmentUserInfo;
import ncu.hxl.equipment.been.InsertUser;

public class FaceRecognitionFallback {

    public static CommonResult insertEquipmentInfo(Equipment equipment) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    public static CommonResult updateEquipmentInfo(Equipment equipment) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult deleteEquipmentInfo( String equipmentId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectEquipmentInfo( Long page,  Long limit,
                                             String equipmentLocation){
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    public static CommonResult insertEquipmentUserInfo(InsertUser insertUser) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    public static CommonResult updateEquipmentUserInfo(EquipmentUserInfo equipmentUserInfo) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    
    public static CommonResult deleteEquipmentUserInfo( InsertUser insertUser){
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
    
    public static CommonResult selectEquipmentUserInfo( String equipmentId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    

    public static CommonResult selectEquipmentUserInfoByUserId(String userId) {
        return  CommonResult.error().message("设备服务异常，请稍后再试").setCode(1000);
    }
    
}

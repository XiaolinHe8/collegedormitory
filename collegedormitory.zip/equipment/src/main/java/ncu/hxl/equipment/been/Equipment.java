package ncu.hxl.equipment.been;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class Equipment {
    
    @TableId(type = IdType.ASSIGN_UUID)
    private String equipmentId;
    private String equipmentLocation;
    private String equipmentIp;
    private String equipmentSoftwareVersion;
    private Integer equipmentStatus;
}

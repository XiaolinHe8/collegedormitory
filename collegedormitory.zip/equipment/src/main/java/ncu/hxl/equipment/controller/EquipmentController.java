package ncu.hxl.equipment.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;

import ncu.hxl.common.entity.CommonResult;
import ncu.hxl.equipment.been.Equipment;
import ncu.hxl.equipment.been.EquipmentUserInfo;
import ncu.hxl.equipment.been.InsertUser;
import ncu.hxl.equipment.myHandler.FaceRecognitionFallback;
import ncu.hxl.equipment.myHandler.FaceRecognitionHandler;
import ncu.hxl.equipment.service.EquipmentService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@AllArgsConstructor
public class EquipmentController {
    private EquipmentService equipmentService;
    
    @PostMapping("/equipment/insert")
    @SentinelResource(value = "insert",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "insert",fallbackClass = FaceRecognitionFallback.class,fallback = "insert")
    public CommonResult insertEquipmentInfo(@RequestBody Equipment equipment) {
        CommonResult commonResult = CommonResult.ok();
        if(!equipmentService.insertEquipmentInfo(equipment) )
            commonResult = CommonResult.error();
        commonResult.data("result",equipment);
        return commonResult;
    }
    
    @PostMapping("/equipment/update")
    @SentinelResource(value = "update",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "update",fallbackClass = FaceRecognitionFallback.class,fallback = "update")
    public CommonResult updateEquipmentInfo(@RequestBody Equipment equipment) {
        System.out.println("=======================equipment"+equipment);
        CommonResult commonResult = CommonResult.ok();
        if(!equipmentService.updateEquipmentInfo(equipment) )
            commonResult = CommonResult.error();
        return commonResult;
    }
    
    @GetMapping("/equipment/delete/{equipmentId}")
    @SentinelResource(value = "delete",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "deleteEquipmentInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "deleteEquipmentInfo")
    public CommonResult deleteEquipmentInfo(@PathVariable(value = "equipmentId") String equipmentId) {
        CommonResult commonResult = CommonResult.ok();
        if(!equipmentService.deleteEquipmentInfo(equipmentId) )
            commonResult = CommonResult.error();
    
        return commonResult;
    }
    
    @GetMapping("{page}/{limit}")
    @SentinelResource(value = "page",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectEquipmentInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "selectEquipmentInfo")
    public CommonResult selectEquipmentInfo(@PathVariable(value = "page") Long page, @PathVariable(value = "limit") Long limit,@RequestParam("equipmentLocation") String equipmentLocation) {
        System.out.println("=================page"+page+"=========limit"+limit+"========equipmentLocation"+equipmentLocation);
        CommonResult commonResult = CommonResult.ok();
        Page<Equipment> equipmentPage = equipmentService.selectEquipmentInfo(page, limit, equipmentLocation);
        return CommonResult.ok().data("content",equipmentPage.getRecords()).data("totalSize", equipmentPage.getTotal());
    }
    
    @PostMapping("/equipment/insertUser")
    @SentinelResource(value = "insertUser",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "insertEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "insertEquipmentUserInfo")
    public CommonResult insertEquipmentUserInfo(@RequestBody InsertUser insertUser) {
        System.out.println("================insertUser"+insertUser);
        CommonResult commonResult = CommonResult.ok();
        if(!equipmentService.insertEquipmentUserInfo( insertUser.getEquipmentId(),  insertUser.getUserIds()))
            commonResult = CommonResult.error();
        return commonResult;
    }
    
    @PostMapping("/equipment/updateUser")
    @SentinelResource(value = "updateUser",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "updateEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "updateEquipmentUserInfo")
    public CommonResult updateEquipmentUserInfo(@RequestBody EquipmentUserInfo equipmentUserInfo) {
        CommonResult commonResult = CommonResult.ok();
        if(!equipmentService.updateEquipmentUserInfo(equipmentUserInfo))
            commonResult = CommonResult.error();
        return commonResult;
    }
    
    @PostMapping("/equipment/deleteUser")
    @SentinelResource(value = "deleteUser",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "deleteEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "deleteEquipmentUserInfo")
    public CommonResult deleteEquipmentUserInfo(@RequestBody InsertUser insertUser) {
        CommonResult commonResult = CommonResult.ok();
        if(!equipmentService.deleteEquipmentUserInfo(insertUser.getEquipmentId(),insertUser.getUserIds()))
            commonResult = CommonResult.error();
        return commonResult;
    }
    
    @GetMapping("/equipment/selectUser/{equipmentId}")
    @SentinelResource(value = "selectUser",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectEquipmentUserInfo",fallbackClass = FaceRecognitionFallback.class,fallback = "selectEquipmentUserInfo")
    public CommonResult selectEquipmentUserInfo(@PathVariable(value = "equipmentId") String equipmentId) {
        CommonResult commonResult = CommonResult.ok();
        List<EquipmentUserInfo> equipmentUserInfos = equipmentService.selectEquipmentUserInfo(equipmentId);
        commonResult.data("equipmentUserInfos",equipmentUserInfos);
        return commonResult;
    }
    
    @GetMapping("/equipment/selectUser1")
    @SentinelResource(value = "selectUser1",blockHandlerClass = FaceRecognitionHandler.class
            ,blockHandler = "selectEquipmentUserInfoByUserId",fallbackClass = FaceRecognitionFallback.class,fallback = "selectEquipmentUserInfoByUserId")
    public CommonResult selectEquipmentUserInfoByUserId(String userId) {
        CommonResult commonResult = CommonResult.ok();
        List<EquipmentUserInfo> equipmentUserInfo = equipmentService.selectEquipmentUserInfoByUserId(userId);
        commonResult.data("equipmentUserInfo",equipmentUserInfo);
        return commonResult;
    }
    
    @GetMapping("/equipment/heartbeat")
    public void heartbeatDetection(@RequestParam("equipmentId")String equipmentId) {
        equipmentService.heartbeatDetection(equipmentId);
    }
    
    
}

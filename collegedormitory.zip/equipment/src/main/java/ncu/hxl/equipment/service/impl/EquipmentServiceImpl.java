package ncu.hxl.equipment.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import ncu.hxl.equipment.been.Equipment;
import ncu.hxl.equipment.been.EquipmentUserInfo;
import ncu.hxl.equipment.dao.mapper.EquipmentMapper;
import ncu.hxl.equipment.dao.mapper.EquipmentUserInfoMapper;
import ncu.hxl.equipment.service.EquipmentService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


@EnableScheduling
@Service
public class EquipmentServiceImpl implements EquipmentService {
    private EquipmentMapper equipmentMapper;
    private EquipmentUserInfoMapper equipmentUserInfoMapper;
    private static HashMap<String,Integer> hashMap = new HashMap<>();
    private static Integer max = 3;
    
    public EquipmentServiceImpl(EquipmentMapper equipmentMapper, EquipmentUserInfoMapper equipmentUserInfoMapper) {
        this.equipmentMapper = equipmentMapper;
        this.equipmentUserInfoMapper = equipmentUserInfoMapper;
    }
    
    @Override
    public boolean insertEquipmentInfo(Equipment equipment) {
        if(equipment != null)
         return   equipmentMapper.insert(equipment) > 0;
        return false;
    }
    
    @Override
    public boolean updateEquipmentInfo(Equipment equipment) {
        if(equipment != null && equipment.getEquipmentId() != null && !"".equals(equipment.getEquipmentId()))
            return   equipmentMapper.updateById(equipment) > 0;
        return false;
    }
    
    @Override
    public boolean deleteEquipmentInfo(String equipmentId) {
        if(equipmentId != null && !"".equals(equipmentId))
            return   equipmentMapper.deleteById(equipmentId) > 0;
        return false;
    }
    
    @Override
    public Page<Equipment> selectEquipmentInfo(Long page, Long limit,String equipmentLocation) {
        QueryWrapper<Equipment> wrapper = new QueryWrapper<>();
        if(!StringUtils.isEmpty(equipmentLocation)) {
            wrapper.like("equipment_location", equipmentLocation);
           
        }
        Page<Equipment> equipmentPage = equipmentMapper.selectPage(new Page<Equipment>(page, limit), wrapper);
        return equipmentPage;
    }
    
    @Override
    public boolean insertEquipmentUserInfo(String equipmentId, List<String> userIds) {
        if(userIds==null || userIds.size()==0)
            return false;
        try {
            for(String userId:userIds){
                if(!"".equals(userId))
                     equipmentUserInfoMapper.insert(new EquipmentUserInfo().setEquipmentId(equipmentId).setUserId(userId));
            }
        }catch (Exception e){
            return false;
        }
        
        return true;
    }
    
    @Override
    public boolean updateEquipmentUserInfo(EquipmentUserInfo equipmentUserInfo) {
        if(equipmentUserInfo.getEquipmentUserId() != null && !"".equals(equipmentUserInfo.getEquipmentUserId()))
            return  equipmentUserInfoMapper.updateById(equipmentUserInfo) > 0;
        return false;
    }
    
    @Override
    public boolean deleteEquipmentUserInfo(String equipmentId,List<String> userIds) {
        
        if(equipmentId != null && !"".equals(equipmentId) && userIds!=null && userIds.size() > 0){
            return equipmentUserInfoMapper.delete(new QueryWrapper<EquipmentUserInfo>().eq("equipment_id",equipmentId)
            .in("user_id",userIds)) > 0;
        }
        
        return false;
    }
    
    @Override
    public List<EquipmentUserInfo> selectEquipmentUserInfo(String equipmentId) {
        if(equipmentId != null && !"".equals(equipmentId))
            return equipmentUserInfoMapper.selectList(new QueryWrapper<EquipmentUserInfo>()
            .eq("equipment_id",equipmentId));
        return null;
    }
    
    @Override
    public List<EquipmentUserInfo> selectEquipmentUserInfoByUserId( String userId) {
        HashMap<String, String> hashMap = new HashMap<>();
        if(userId != null && !"".equals(userId))
            return equipmentUserInfoMapper.selectList(new QueryWrapper<EquipmentUserInfo>()
                    .eq("user_id",userId));
        return null;
    }
    
    @Override
    public void heartbeatDetection(String equipmentId) {
        if(!hashMap.containsKey(equipmentId)){
            Equipment equipment = new Equipment().setEquipmentStatus(1).setEquipmentId(equipmentId);
            equipmentMapper.updateById(equipment);
        }
        hashMap.put(equipmentId,max);
    }
    
    @Scheduled(fixedDelay = 30000)
    @Async
    @Override
    public void heartbeatDetection() {
        Iterator<String> iterator = hashMap.keySet().iterator();
        while(iterator.hasNext()){
            String key = iterator.next();
            Integer value = hashMap.get(key);
            if(value > 0)
                hashMap.put(key,value-1);
            else {
                hashMap.remove(key);
                Equipment equipment = new Equipment();
                equipment.setEquipmentId(key).setEquipmentStatus(0);
                equipmentMapper.updateById(equipment);
            }
        }
    }
    
    
}
